import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:lucide_icons/lucide_icons.dart';

import 'core/theme/app_theme.dart';
import 'features/settings/presentation/providers/theme_provider.dart';

// Import Screens
import 'features/dashboard/presentation/screens/dashboard_screen.dart';
import 'features/employees/presentation/screens/employees_screen.dart';
import 'features/archive/presentation/screens/daily_log_screen.dart';
import 'features/statements/presentation/screens/statement_screen.dart';
import 'features/settings/presentation/screens/settings_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize SharedPreferences
  final prefs = await SharedPreferences.getInstance();

  runApp(
    ProviderScope(
      overrides: [
        sharedPreferencesProvider.overrideWithValue(prefs),
      ],
      child: const MyApp(),
    ),
  );
}

// Global provider for shared preferences
final sharedPreferencesProvider = Provider<SharedPreferences>((ref) {
  throw UnimplementedError();
});

class MyApp extends ConsumerWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final themeMode = ref.watch(themeNotifierProvider);

    return MaterialApp(
      title: 'إدارة العمال والحسابات',
      debugShowCheckedModeBanner: false,
      
      // Theme Configuration
      themeMode: themeMode,
      theme: AppTheme.lightTheme,
      darkTheme: AppTheme.darkTheme,

      // Localization Configuration (Arabic RTL Default)
      locale: const Locale('ar', 'AE'),
      supportedLocales: const [
        Locale('ar', 'AE'), // Arabic
        Locale('en', 'US'), // English fallback
      ],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],

      home: const MainNavigationScreen(),
    );
  }
}

class MainNavigationScreen extends StatefulWidget {
  const MainNavigationScreen({super.key});

  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  int _currentIndex = 0;

  final List<Widget> _screens = [
    const DashboardScreen(),
    const EmployeesScreen(),
    const DailyLogScreen(),
    const StatementScreen(),
    const SettingsScreen(),
  ];

  final List<String> _titles = [
    'لوحة التحكم الإحصائية',
    'قائمة وإدارة العمال',
    'الترحيل والأرشفة اليومية',
    'كشوفات الحسابات والتقارير',
    'الإعدادات والتنبيهات المخصصة',
  ];

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          _titles[_currentIndex],
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 18,
            color: isDark ? Colors.white : const Color(0xFF0F172A),
          ),
        ),
        elevation: 0,
        backgroundColor: isDark ? const Color(0xFF0F172A) : Colors.white,
        centerTitle: true,
      ),
      body: _screens[_currentIndex],
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, -2),
            ),
          ],
        ),
        child: BottomNavigationBar(
          currentIndex: _currentIndex,
          onTap: (index) {
            setState(() {
              _currentIndex = index;
            });
          },
          type: BottomNavigationBarType.fixed,
          backgroundColor: isDark ? const Color(0xFF0F172A) : Colors.white,
          selectedItemColor: isDark ? Colors.blue[400] : const Color(0xFF3B82F6),
          unselectedItemColor: isDark ? Colors.grey[500] : Colors.grey[400],
          selectedLabelStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 11),
          unselectedLabelStyle: const TextStyle(fontSize: 10),
          items: const [
            BottomNavigationBarItem(
              icon: Icon(LucideIcons.layoutDashboard, size: 20),
              activeIcon: Icon(LucideIcons.layoutDashboard, size: 22),
              label: 'الرئيسية',
            ),
            BottomNavigationBarItem(
              icon: Icon(LucideIcons.users, size: 20),
              activeIcon: Icon(LucideIcons.users, size: 22),
              label: 'العمال',
            ),
            BottomNavigationBarItem(
              icon: Icon(LucideIcons.calendarCheck, size: 20),
              activeIcon: Icon(LucideIcons.calendarCheck, size: 22),
              label: 'الترحيل اليومي',
            ),
            BottomNavigationBarItem(
              icon: Icon(LucideIcons.fileSpreadsheet, size: 20),
              activeIcon: Icon(LucideIcons.fileSpreadsheet, size: 22),
              label: 'الكشوفات',
            ),
            BottomNavigationBarItem(
              icon: Icon(LucideIcons.settings, size: 20),
              activeIcon: Icon(LucideIcons.settings, size: 22),
              label: 'الإعدادات',
            ),
          ],
        ),
      ),
    );
  }
}
