import 'package:dio/dio.dart';
import '../../features/employees/data/models/employee_model.dart';
import '../../features/archive/data/models/archive_entry_model.dart';
import '../../features/dashboard/data/models/dashboard_stats_model.dart';
import '../../features/statements/data/models/statement_response_model.dart';

class ApiService {
  final Dio _dio;

  // Replace this with your production/development API Base URL
  static const String defaultBaseUrl = 'https://ais-dev-zrjsnmjadrcqfgezh6hewl-932835393930.europe-west2.run.app';

  ApiService({String baseUrl = defaultBaseUrl})
      : _dio = Dio(
          BaseOptions(
            baseUrl: baseUrl,
            connectTimeout: const Duration(seconds: 15),
            receiveTimeout: const Duration(seconds: 15),
            headers: {
              'Content-Type': 'application/json',
              'Accept': 'application/json',
            },
          ),
        ) {
    _dio.interceptors.add(
      InterceptorsWrapper(
        onRequest: (options, handler) {
          // If you have a Firebase auth token or session token, inject it here:
          // options.headers['Authorization'] = 'Bearer $token';
          return handler.next(options);
        },
        onError: (DioException e, handler) {
          // Log or handle centralized network errors (e.g. Refresh Token, session expiry)
          print('API SERVICE ERROR: ${e.message}');
          return handler.next(e);
        },
      ),
    );
  }

  // -----------------------------------------------------------------
  // 1. EMPLOYEES CRUD
  // -----------------------------------------------------------------

  /// GET /api/employees
  Future<List<EmployeeModel>> getAllEmployees() async {
    try {
      final response = await _dio.get('/api/employees');
      final data = response.data as List;
      return data.map((json) => EmployeeModel.fromJson(json)).toList();
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  /// GET /api/employees/:id
  Future<EmployeeModel> getEmployeeById(int id) async {
    try {
      final response = await _dio.get('/api/employees/$id');
      return EmployeeModel.fromJson(response.data as Map<String, dynamic>);
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  /// POST /api/employees
  Future<EmployeeModel> createEmployee(EmployeeModel employee) async {
    try {
      final response = await _dio.post('/api/employees', data: employee.toJson());
      return EmployeeModel.fromJson(response.data as Map<String, dynamic>);
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  /// PUT /api/employees/:id
  Future<EmployeeModel> updateEmployee(int id, EmployeeModel employee) async {
    try {
      final response = await _dio.put('/api/employees/$id', data: employee.toJson());
      return EmployeeModel.fromJson(response.data as Map<String, dynamic>);
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  /// DELETE /api/employees/:id
  Future<void> deleteEmployee(int id) async {
    try {
      await _dio.delete('/api/employees/$id');
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  // -----------------------------------------------------------------
  // 2. DASHBOARD & INITIAL DATA
  // -----------------------------------------------------------------

  /// GET /api/initial-data
  Future<Map<String, dynamic>> getInitialData() async {
    try {
      final response = await _dio.get('/api/initial-data');
      final data = response.data as Map<String, dynamic>;
      
      final employeesList = (data['employees'] as List)
          .map((json) => EmployeeModel.fromJson(json))
          .toList();
      final stats = DashboardStatsModel.fromJson(data['dashboardStats'] as Map<String, dynamic>);
      
      return {
        'employees': employeesList,
        'dashboardStats': stats,
      };
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  // -----------------------------------------------------------------
  // 3. DAILY & BATCH ARCHIVING
  // -----------------------------------------------------------------

  /// POST /api/archive
  /// Submits flat batch of archived entries mapped per employeeId
  Future<String> submitArchive(List<Map<String, dynamic>> payload) async {
    try {
      final response = await _dio.post('/api/archive', data: payload);
      return response.data['message'] as String? ?? 'تمت عملية الأرشفة بنجاح';
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  // -----------------------------------------------------------------
  // 4. ACCOUNT STATEMENTS
  // -----------------------------------------------------------------

  /// GET /api/statement?employeeId=<id>&startDate=<date>&endDate=<date>
  Future<StatementResponseModel> getStatement({
    required int employeeId,
    required String startDate,
    required String endDate,
  }) async {
    try {
      final response = await _dio.get(
        '/api/statement',
        queryParameters: {
          'employeeId': employeeId,
          'startDate': startDate,
          'endDate': endDate,
        },
      );
      return StatementResponseModel.fromJson(response.data as Map<String, dynamic>);
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  // Centralized Error Resolver
  Exception _handleError(DioException e) {
    String errorMsg = 'حدث خطأ غير متوقع في الاتصال بالخادم';
    if (e.response != null) {
      final responseData = e.response?.data;
      if (responseData is Map && responseData.containsKey('error')) {
        errorMsg = responseData['error'].toString();
      } else {
        errorMsg = 'الخادم أرجع خطأ (${e.response?.statusCode})';
      }
    } else {
      if (e.type == DioExceptionType.connectionTimeout) {
        errorMsg = 'انتهت مهلة الاتصال بالخادم، يرجى التحقق من اتصالك بالإنترنت';
      } else if (e.type == DioExceptionType.receiveTimeout) {
        errorMsg = 'انتهت مهلة استلام البيانات من الخادم';
      }
    }
    return Exception(errorMsg);
  }
}
