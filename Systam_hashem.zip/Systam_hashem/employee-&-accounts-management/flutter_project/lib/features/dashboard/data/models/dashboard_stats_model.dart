class DashboardStatsModel {
  final int totalEmployees;
  final int totalPresentToday;
  final int totalAbsentToday;
  final double totalWithdrawalsMonth;

  DashboardStatsModel({
    required this.totalEmployees,
    required this.totalPresentToday,
    required this.totalAbsentToday,
    required this.totalWithdrawalsMonth,
  });

  factory DashboardStatsModel.fromJson(Map<String, dynamic> json) {
    return DashboardStatsModel(
      totalEmployees: json['totalEmployees'] as int? ?? 0,
      totalPresentToday: json['totalPresentToday'] as int? ?? 0,
      totalAbsentToday: json['totalAbsentToday'] as int? ?? 0,
      totalWithdrawalsMonth: (json['totalWithdrawalsMonth'] as num? ?? 0.0).toDouble(),
    );
  }
}
