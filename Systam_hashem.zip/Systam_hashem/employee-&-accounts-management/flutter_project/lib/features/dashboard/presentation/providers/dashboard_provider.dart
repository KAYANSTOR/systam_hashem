import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/network/api_service_provider.dart';
import '../../data/models/dashboard_stats_model.dart';
import '../../../employees/data/models/employee_model.dart';

class DashboardData {
  final List<EmployeeModel> employees;
  final DashboardStatsModel stats;

  DashboardData({required this.employees, required this.stats});
}

class DashboardNotifier extends StateNotifier<AsyncValue<DashboardData>> {
  final Ref _ref;

  DashboardNotifier(this._ref) : super(const AsyncValue.loading()) {
    loadDashboardData();
  }

  Future<void> loadDashboardData() async {
    state = const AsyncValue.loading();
    try {
      final api = _ref.read(apiServiceProvider);
      final initialData = await api.getInitialData();
      final employees = initialData['employees'] as List<EmployeeModel>;
      final stats = initialData['dashboardStats'] as DashboardStatsModel;
      
      state = AsyncValue.data(DashboardData(employees: employees, stats: stats));
    } catch (e, stack) {
      state = AsyncValue.error(e, stack);
    }
  }
}

final dashboardProvider =
    StateNotifierProvider<DashboardNotifier, AsyncValue<DashboardData>>((ref) {
  return DashboardNotifier(ref);
});
