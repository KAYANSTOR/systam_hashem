import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/network/api_service_provider.dart';
import '../../data/models/statement_response_model.dart';

class StatementsNotifier extends StateNotifier<AsyncValue<StatementResponseModel?>> {
  final Ref _ref;

  StatementsNotifier(this._ref) : super(const AsyncValue.data(null));

  Future<void> loadStatement({
    required int employeeId,
    required String startDate,
    required String endDate,
  }) async {
    state = const AsyncValue.loading();
    try {
      final api = _ref.read(apiServiceProvider);
      final statement = await api.getStatement(
        employeeId: employeeId,
        startDate: startDate,
        endDate: endDate,
      );
      state = AsyncValue.data(statement);
    } catch (e, stack) {
      state = AsyncValue.error(e, stack);
    }
  }

  void clear() {
    state = const AsyncValue.data(null);
  }
}

final statementsProvider =
    StateNotifierProvider<StatementsNotifier, AsyncValue<StatementResponseModel?>>((ref) {
  return StatementsNotifier(ref);
});
