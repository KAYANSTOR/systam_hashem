import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:intl/intl.dart' as intl;
import '../../../employees/presentation/providers/employees_provider.dart';
import '../providers/statements_provider.dart';

class StatementScreen extends ConsumerStatefulWidget {
  const StatementScreen({super.key});

  @override
  ConsumerState<StatementScreen> createState() => _StatementScreenState();
}

class _StatementScreenState extends ConsumerState<StatementScreen> {
  int? _selectedEmployeeId;
  DateTime _startDate = DateTime(DateTime.now().year, DateTime.now().month, 1);
  DateTime _endDate = DateTime.now();

  @override
  Widget build(BuildContext context) {
    final employeesState = ref.watch(employeesProvider);
    final statementsState = ref.watch(statementsProvider);
    final formatter = intl.NumberFormat.currency(locale: 'ar_AE', symbol: 'د.إ');

    return Scaffold(
      body: Column(
        children: [
          // Filter Panel
          Card(
            margin: const EdgeInsets.all(16),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'تصفية كشف الحساب والتقرير المالي',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      // Employee Dropdown Selector
                      Expanded(
                        flex: 2,
                        child: employeesState.when(
                          loading: () => const Center(child: CircularProgressIndicator()),
                          error: (err, stack) => const Text('خطأ في تحميل الموظفين'),
                          data: (employees) {
                            return DropdownButtonFormField<int>(
                              value: _selectedEmployeeId,
                              decoration: const InputDecoration(
                                labelText: 'اختر الموظف',
                                contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                              ),
                              hint: const Text('حدد العامل المالي'),
                              items: employees.map((emp) {
                                return DropdownMenuItem<int>(
                                  value: emp.id,
                                  child: Text(emp.name),
                                );
                              }).toList(),
                              onChanged: (val) {
                                setState(() {
                                  _selectedEmployeeId = val;
                                });
                              },
                            );
                          },
                        ),
                      ),
                      const SizedBox(width: 8),

                      // Start Date Selector
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () async {
                            final picked = await showDatePicker(
                              context: context,
                              initialDate: _startDate,
                              firstDate: DateTime(2025),
                              lastDate: DateTime(2030),
                            );
                            if (picked != null) {
                              setState(() {
                                _startDate = picked;
                              });
                            }
                          },
                          child: Text(
                            'من: ${intl.DateFormat('MM-dd').format(_startDate)}',
                            style: const TextStyle(fontSize: 12),
                          ),
                        ),
                      ),
                      const SizedBox(width: 4),

                      // End Date Selector
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () async {
                            final picked = await showDatePicker(
                              context: context,
                              initialDate: _endDate,
                              firstDate: DateTime(2025),
                              lastDate: DateTime(2030),
                            );
                            if (picked != null) {
                              setState(() {
                                _endDate = picked;
                              });
                            }
                          },
                          child: Text(
                            'إلى: ${intl.DateFormat('MM-dd').format(_endDate)}',
                            style: const TextStyle(fontSize: 12),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),

                  // Generate Report Button
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blue,
                        foregroundColor: Colors.white,
                      ),
                      onPressed: _selectedEmployeeId == null
                          ? null
                          : () {
                              ref.read(statementsProvider.notifier).loadStatement(
                                    employeeId: _selectedEmployeeId!,
                                    startDate: intl.DateFormat('yyyy-MM-dd').format(_startDate),
                                    endDate: intl.DateFormat('yyyy-MM-dd').format(_endDate),
                                  );
                            },
                      icon: const Icon(LucideIcons.fileSearch),
                      label: const Text('عرض كشف الحساب التفصيلي'),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Report Result View
          Expanded(
            child: statementsState.when(
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (err, stack) => Center(child: Text('حدث خطأ في جلب كشف الحساب: $err')),
              data: (statement) {
                if (statement == null) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(LucideIcons.fileText, size: 64, color: Colors.grey[400]),
                        const SizedBox(height: 16),
                        const Text('يرجى تحديد موظف وفترة التقرير والضغط على عرض كشف الحساب'),
                      ],
                    ),
                  );
                }

                return SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Financial Summary Cards
                      Text(
                        'ملخص الحساب للموظف: ${statement.employeeName}',
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                      ),
                      const SizedBox(height: 12),

                      if (statement.monthlySummaries.isNotEmpty)
                        _buildMonthlySummaryCard(context, statement.monthlySummaries.first, formatter),

                      const SizedBox(height: 24),

                      // Detailed Log Entries Title
                      const Text(
                        'سجل الحضور والعمليات التفصيلي خلال الفترة',
                        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                      ),
                      const SizedBox(height: 12),

                      if (statement.entries.isEmpty)
                        const Padding(
                          padding: EdgeInsets.symmetric(vertical: 24.0),
                          child: Center(child: Text('لا توجد سجلات أرشفة لهذا العامل خلال الفترة المحددة.')),
                        )
                      else
                        ListView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: statement.entries.length,
                          itemBuilder: (context, index) {
                            final entry = statement.entries[index];
                            final attendanceColor = entry.attendance == 'حاضر'
                                ? Colors.green
                                : entry.attendance == 'غائب'
                                    ? Colors.red
                                    : Colors.orange;

                            return Card(
                              margin: const EdgeInsets.only(bottom: 10),
                              child: ExpansionTile(
                                leading: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                                  decoration: BoxDecoration(
                                    color: attendanceColor.withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  child: Text(
                                    entry.attendance,
                                    style: TextStyle(color: attendanceColor, fontWeight: FontWeight.bold, fontSize: 12),
                                  ),
                                ),
                                title: Text(
                                  'تاريخ: ${entry.date} (${entry.day})',
                                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                                ),
                                subtitle: Text(
                                  'تأخير: ${entry.delay} د | إضافي: ${entry.overtime} د.إ | صرفية: ${entry.advance} د.إ',
                                  style: const TextStyle(fontSize: 12, color: Colors.grey),
                                ),
                                children: [
                                  if (entry.note != null && entry.note!.isNotEmpty)
                                    Padding(
                                      padding: const EdgeInsets.all(12.0),
                                      child: Align(
                                        alignment: Alignment.centerRight,
                                        child: Text(
                                          '📝 ملاحظات اليوم: ${entry.note}',
                                          style: const TextStyle(fontStyle: FontStyle.italic),
                                        ),
                                      ),
                                    ),
                                ],
                              ),
                            );
                          },
                        ),
                      const SizedBox(height: 32),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMonthlySummaryCard(BuildContext context, dynamic summary, intl.NumberFormat formatter) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Card(
      color: Colors.green.withOpacity(0.05),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: Colors.green.withOpacity(0.2)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'ملخص الشهر الحالي (${summary.month}/${summary.year})',
                  style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.green),
                ),
                Text(
                  'الصافي المتبقي للراتب',
                  style: TextStyle(fontSize: 12, color: isDark ? Colors.grey[400] : Colors.grey[600]),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'أيام الحضور الفعلية: ${summary.totalAttendanceDays}',
                  style: const TextStyle(fontSize: 13),
                ),
                Text(
                  formatter.format(summary.remainingSalary),
                  style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.green),
                ),
              ],
            ),
            const Divider(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _buildSummaryStat('إجمالي التأخير', '${summary.totalDelayMinutes} دقيقة'),
                _buildSummaryStat('خصم التأخير', formatter.format(summary.delayDeduction)),
                _buildSummaryStat('إجمالي الإضافي', formatter.format(summary.totalOvertimeAmount)),
                _buildSummaryStat('إجمالي السلف/الصرفيات', formatter.format(summary.totalAdvanceAmount)),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSummaryStat(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontSize: 10, color: Colors.grey)),
        const SizedBox(height: 4),
        Text(value, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
      ],
    );
  }
}
