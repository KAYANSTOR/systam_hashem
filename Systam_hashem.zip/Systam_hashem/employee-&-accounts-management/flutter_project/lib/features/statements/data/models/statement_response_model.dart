import '../../archive/data/models/archive_entry_model.dart';

class MonthlySummaryModel {
  final int month;
  final int year;
  final double totalAttendanceDays;
  final int totalDelayMinutes;
  final double delayDeduction;
  final double totalDepartureAmount;
  final double totalOvertimeAmount;
  final double totalAdvanceAmount;
  final double remainingSalary;

  MonthlySummaryModel({
    required this.month,
    required this.year,
    required this.totalAttendanceDays,
    required this.totalDelayMinutes,
    required this.delayDeduction,
    required this.totalDepartureAmount,
    required this.totalOvertimeAmount,
    required this.totalAdvanceAmount,
    required this.remainingSalary,
  });

  factory MonthlySummaryModel.fromJson(Map<String, dynamic> json) {
    return MonthlySummaryModel(
      month: json['month'] as int,
      year: json['year'] as int,
      totalAttendanceDays: (json['totalAttendanceDays'] as num? ?? 0.0).toDouble(),
      totalDelayMinutes: json['totalDelayMinutes'] as int? ?? 0,
      delayDeduction: (json['delayDeduction'] as num? ?? 0.0).toDouble(),
      totalDepartureAmount: (json['totalDepartureAmount'] as num? ?? 0.0).toDouble(),
      totalOvertimeAmount: (json['totalOvertimeAmount'] as num? ?? 0.0).toDouble(),
      totalAdvanceAmount: (json['totalAdvanceAmount'] as num? ?? 0.0).toDouble(),
      remainingSalary: (json['remainingSalary'] as num? ?? 0.0).toDouble(),
    );
  }
}

class StatementResponseModel {
  final String employeeName;
  final double monthlySalary;
  final List<ArchiveEntryModel> entries;
  final List<MonthlySummaryModel> monthlySummaries;

  StatementResponseModel({
    required this.employeeName,
    required this.monthlySalary,
    required this.entries,
    required this.monthlySummaries,
  });

  factory StatementResponseModel.fromJson(Map<String, dynamic> json) {
    return StatementResponseModel(
      employeeName: json['employeeName'] as String? ?? '',
      monthlySalary: (json['monthlySalary'] as num? ?? 0.0).toDouble(),
      entries: (json['entries'] as List<dynamic>?)
              ?.map((e) => ArchiveEntryModel.fromJson(e as Map<String, dynamic>))
              .toList() ??
          [],
      monthlySummaries: (json['monthlySummaries'] as List<dynamic>?)
              ?.map((e) => MonthlySummaryModel.fromJson(e as Map<String, dynamic>))
              .toList() ??
          [],
    );
  }
}
