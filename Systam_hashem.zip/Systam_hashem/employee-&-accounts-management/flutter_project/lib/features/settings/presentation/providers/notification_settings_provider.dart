import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../../core/services/notification_service.dart';
import '../../../../main.dart';

class NotificationSettings {
  final bool isEnabled;
  final int hour;
  final int minute;

  NotificationSettings({
    required this.isEnabled,
    required this.hour,
    required this.minute,
  });

  NotificationSettings copyWith({
    bool? isEnabled,
    int? hour,
    int? minute,
  }) {
    return NotificationSettings(
      isEnabled: isEnabled ?? this.isEnabled,
      hour: hour ?? this.hour,
      minute: minute ?? this.minute,
    );
  }
}

class NotificationSettingsNotifier extends StateNotifier<NotificationSettings> {
  final SharedPreferences _prefs;
  final NotificationService _notificationService = NotificationService();

  static const _enabledKey = 'notif_enabled';
  static const _hourKey = 'notif_hour';
  static const _minuteKey = 'notif_minute';

  NotificationSettingsNotifier(this._prefs)
      : super(
          NotificationSettings(
            isEnabled: _prefs.getBool(_enabledKey) ?? false,
            hour: _prefs.getInt(_hourKey) ?? 17, // Default to 5 PM
            minute: _prefs.getInt(_minuteKey) ?? 0,
          ),
        ) {
    if (state.isEnabled) {
      _applyScheduling();
    }
  }

  Future<void> toggleNotifications(bool value) async {
    if (value) {
      final hasPermission = await _notificationService.requestPermissions();
      if (!hasPermission) {
        // Fallback: request permission and log/propagate.
      }
    }

    state = state.copyWith(isEnabled: value);
    await _prefs.setBool(_enabledKey, value);

    if (value) {
      await _applyScheduling();
    } else {
      await _notificationService.cancelAll();
    }
  }

  Future<void> updateTime(int hour, int minute) async {
    state = state.copyWith(hour: hour, minute: minute);
    await _prefs.setInt(_hourKey, hour);
    await _prefs.setInt(_minuteKey, minute);

    if (state.isEnabled) {
      await _applyScheduling();
    }
  }

  Future<void> _applyScheduling() async {
    try {
      await _notificationService.scheduleDailyNotification(
        id: 1001,
        title: 'تذكير يومي: تسجيل الحضور والمصروفات 📝',
        body: 'يرجى مراجعة وتسجيل حضور الموظفين ومصروفات اليوم (الصرفة) وتأكيده في النظام.',
        hour: state.hour,
        minute: state.minute,
      );
    } catch (e) {
      print('Failed to schedule daily notification: $e');
    }
  }
}

final notificationSettingsProvider =
    StateNotifierProvider<NotificationSettingsNotifier, NotificationSettings>((ref) {
  final prefs = ref.watch(sharedPreferencesProvider);
  return NotificationSettingsNotifier(prefs);
});
