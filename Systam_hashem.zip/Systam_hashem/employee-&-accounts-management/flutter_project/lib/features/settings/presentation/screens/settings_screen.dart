import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../../../core/services/notification_service.dart';
import '../providers/theme_provider.dart';
import '../providers/notification_settings_provider.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final themeMode = ref.watch(themeNotifierProvider);
    final notificationSettings = ref.watch(notificationSettingsProvider);

    return Scaffold(
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          Text(
            'الإعدادات والتنبيهات',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          const Text('تخصيص تفضيلات التطبيق وضبط تنبيهات الأرشفة اليومية للعمال'),
          const SizedBox(height: 24),

          // 1. Appearance / Theme Category
          _buildCategoryHeader('المظهر العام'),
          Card(
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(LucideIcons.moon, color: Colors.indigo),
                  title: const Text('الوضع الداكن (Dark Mode)'),
                  subtitle: const Text('تبديل مظهر واجهة التطبيق'),
                  trailing: Switch(
                    value: themeMode == ThemeMode.dark,
                    onChanged: (val) {
                      ref.read(themeNotifierProvider.notifier).toggleTheme();
                    },
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),

          // 2. Notifications Category
          _buildCategoryHeader('تنبيهات تسجيل الحضور والصرفة'),
          Card(
            child: Column(
              children: [
                // Toggle Switch
                ListTile(
                  leading: const Icon(LucideIcons.bellRing, color: Colors.blue),
                  title: const Text('تفعيل التذكير اليومي'),
                  subtitle: const Text('تلقي إشعار كل يوم لتذكيرك بتسجيل الحضور وصرفيات العمال'),
                  trailing: Switch(
                    value: notificationSettings.isEnabled,
                    onChanged: (val) async {
                      await ref.read(notificationSettingsProvider.notifier).toggleNotifications(val);
                    },
                  ),
                ),
                const Divider(),

                // Time picker row
                ListTile(
                  enabled: notificationSettings.isEnabled,
                  leading: const Icon(LucideIcons.alarmClock, color: Colors.orange),
                  title: const Text('وقت التنبيه اليومي'),
                  subtitle: Text(
                    'يتم إرسال التنبيه يومياً في الساعة: '
                    '${_formatTime(notificationSettings.hour, notificationSettings.minute)}',
                  ),
                  trailing: OutlinedButton(
                    onPressed: !notificationSettings.isEnabled
                        ? null
                        : () async {
                            final TimeOfDay? picked = await showTimePicker(
                              context: context,
                              initialTime: TimeOfDay(
                                hour: notificationSettings.hour,
                                minute: notificationSettings.minute,
                              ),
                            );
                            if (picked != null) {
                              await ref
                                  .read(notificationSettingsProvider.notifier)
                                  .updateTime(picked.hour, picked.minute);
                            }
                          },
                    child: const Text('تغيير الوقت'),
                  ),
                ),
                const Divider(),

                // Instant Test Notification Button
                ListTile(
                  enabled: notificationSettings.isEnabled,
                  leading: const Icon(LucideIcons.sparkles, color: Colors.green),
                  title: const Text('اختبار الإشعار الفوري 📱'),
                  subtitle: const Text('أرسل إشعاراً تجريبياً فوراً للتأكد من وصول التنبيهات على هاتفك'),
                  trailing: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green.withOpacity(0.1),
                      foregroundColor: Colors.green,
                      elevation: 0,
                    ),
                    onPressed: !notificationSettings.isEnabled
                        ? null
                        : () async {
                            try {
                              await NotificationService().scheduleDailyNotification(
                                id: 9999, // Test Notification ID
                                title: 'تجربة التنبيهات الناجحة! 🎉',
                                body: 'رائع! نظام التنبيهات في تطبيق إدارة العمال والحسابات يعمل الآن بشكل ممتاز.',
                                hour: DateTime.now().hour,
                                minute: DateTime.now().minute + 1, // trigger almost immediately/1 min from now or zoned test
                              );
                              if (context.mounted) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text('تم جدولة إشعار اختباري ليصلك خلال دقيقة واحدة! 🔔'),
                                  ),
                                );
                              }
                            } catch (e) {
                              if (context.mounted) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(content: Text('فشل جدولة إشعار الاختبار: $e')),
                                );
                              }
                            }
                          },
                    child: const Text('اختبار فوري'),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 32),

          // 3. Info Panel
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.blue.withOpacity(0.05),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.blue.withOpacity(0.15)),
            ),
            child: const Row(
              children: [
                Icon(LucideIcons.info, color: Colors.blue, size: 24),
                SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'ملاحظة: لضمان استلام التنبيهات بدقة، يرجى التأكد من منح التطبيق صلاحيات الإشعارات الكاملة وعدم تفعيل وضع توفير الطاقة للهاتف.',
                    style: TextStyle(fontSize: 12, height: 1.5, color: Colors.grey),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCategoryHeader(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0, left: 8.0, right: 8.0),
      child: Text(
        title,
        style: const TextStyle(
          fontWeight: FontWeight.bold,
          color: Colors.blue,
          fontSize: 14,
        ),
      ),
    );
  }

  String _formatTime(int hour, int minute) {
    final period = hour >= 12 ? 'مساءً' : 'صباحاً';
    var formatHour = hour > 12 ? hour - 12 : hour;
    if (formatHour == 0) formatHour = 12;
    final formatMinute = minute.toString().padLeft(2, '0');
    return '$formatHour:$formatMinute $period';
  }
}
