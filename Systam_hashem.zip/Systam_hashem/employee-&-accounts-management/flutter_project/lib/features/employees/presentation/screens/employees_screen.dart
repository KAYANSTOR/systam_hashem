import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:intl/intl.dart' as intl;
import '../../data/models/employee_model.dart';
import '../providers/employees_provider.dart';

class EmployeesScreen extends ConsumerWidget {
  const EmployeesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final employeesState = ref.watch(employeesProvider);
    final formatter = intl.NumberFormat.currency(locale: 'ar_AE', symbol: 'د.إ');

    return Scaffold(
      body: RefreshIndicator(
        onRefresh: () async {
          await ref.read(employeesProvider.notifier).loadEmployees();
        },
        child: employeesState.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (err, stack) => Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(LucideIcons.alertCircle, size: 50, color: Colors.red),
                const SizedBox(height: 16),
                const Text('حدث خطأ أثناء تحميل قائمة العمال'),
                const SizedBox(height: 8),
                Text(err.toString(), style: const TextStyle(color: Colors.grey)),
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: () => ref.read(employeesProvider.notifier).loadEmployees(),
                  child: const Text('إعادة المحاولة'),
                ),
              ],
            ),
          ),
          data: (employees) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'إدارة العمال',
                            style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'عدد الموظفين الإجمالي: ${employees.length}',
                            style: TextStyle(color: Colors.grey[600]),
                          ),
                        ],
                      ),
                      FloatingActionButton.extended(
                        onPressed: () => _showEmployeeDialog(context, ref),
                        icon: const Icon(LucideIcons.userPlus),
                        label: const Text('إضافة عامل'),
                        backgroundColor: Colors.blue,
                        foregroundColor: Colors.white,
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: employees.isEmpty
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(LucideIcons.users, size: 64, color: Colors.grey[400]),
                              const SizedBox(height: 16),
                              const Text('لا يوجد عمال مضافون حتى الآن', style: TextStyle(fontSize: 16)),
                              const SizedBox(height: 8),
                              ElevatedButton(
                                onPressed: () => _showEmployeeDialog(context, ref),
                                child: const Text('إضافة أول عامل'),
                              ),
                            ],
                          ),
                        )
                      : ListView.builder(
                          physics: const AlwaysScrollableScrollPhysics(),
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          itemCount: employees.length,
                          itemBuilder: (context, index) {
                            final emp = employees[index];
                            final salaryVal = double.tryParse(emp.salary) ?? 0.0;
                            return Card(
                              margin: const EdgeInsets.only(bottom: 12),
                              child: ListTile(
                                leading: CircleAvatar(
                                  backgroundColor: Colors.blue.withOpacity(0.1),
                                  child: Text(
                                    emp.name[0],
                                    style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.blue),
                                  ),
                                ),
                                title: Text(emp.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                                subtitle: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const SizedBox(height: 4),
                                    Text('تاريخ التعيين: ${emp.hireDate}'),
                                    Text('الصرفة الثابتة: ${emp.fixedDeparture} د.إ'),
                                  ],
                                ),
                                trailing: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Text(
                                      formatter.format(salaryVal),
                                      style: const TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: Colors.green,
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    PopupMenuButton<String>(
                                      onSelected: (val) {
                                        if (val == 'edit') {
                                          _showEmployeeDialog(context, ref, employee: emp);
                                        } else if (val == 'delete') {
                                          _confirmDelete(context, ref, emp);
                                        }
                                      },
                                      itemBuilder: (context) => [
                                        const PopupMenuItem(
                                          value: 'edit',
                                          child: Row(
                                            children: [
                                              Icon(LucideIcons.edit2, size: 16),
                                              SizedBox(width: 8),
                                              Text('تعديل البيانات'),
                                            ],
                                          ),
                                        ),
                                        const PopupMenuItem(
                                          value: 'delete',
                                          child: Row(
                                            children: [
                                              Icon(LucideIcons.trash2, size: 16, color: Colors.red),
                                              SizedBox(width: 8),
                                              Text('حذف العامل', style: TextStyle(color: Colors.red)),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  void _showEmployeeDialog(BuildContext context, WidgetRef ref, {EmployeeModel? employee}) {
    final formKey = GlobalKey<FormState>();
    final nameController = TextEditingController(text: employee?.name);
    final salaryController = TextEditingController(text: employee?.salary);
    final departureController = TextEditingController(text: employee?.fixedDeparture ?? '0.00');
    final hireDateController = TextEditingController(text: employee?.hireDate ?? intl.DateFormat('yyyy-MM-dd').format(DateTime.now()));

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(
            employee == null ? 'إضافة عامل جديد' : 'تعديل بيانات العامل',
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
          content: SingleChildScrollView(
            child: Form(
              key: formKey,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextFormField(
                    controller: nameController,
                    decoration: const InputDecoration(
                      labelText: 'اسم العامل',
                      prefixIcon: Icon(LucideIcons.user),
                    ),
                    validator: (val) => (val == null || val.trim().isEmpty) ? 'يرجى إدخال اسم العامل' : null,
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: salaryController,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(
                      labelText: 'الراتب الشهري الأساسي',
                      prefixIcon: Icon(LucideIcons.dollarSign),
                    ),
                    validator: (val) => (val == null || double.tryParse(val) == null) ? 'يرجى إدخال مبلغ الراتب بشكل صحيح' : null,
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: departureController,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(
                      labelText: 'الصرفة اليومية الثابتة (اختياري)',
                      prefixIcon: Icon(LucideIcons.wallet),
                    ),
                    validator: (val) {
                      if (val != null && val.isNotEmpty && double.tryParse(val) == null) {
                        return 'يرجى إدخال مبلغ صحيح';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: hireDateController,
                    readOnly: true,
                    decoration: const InputDecoration(
                      labelText: 'تاريخ التعيين',
                      prefixIcon: Icon(LucideIcons.calendar),
                    ),
                    onTap: () async {
                      final picked = await showDatePicker(
                        context: context,
                        initialDate: DateTime.tryParse(hireDateController.text) ?? DateTime.now(),
                        firstDate: DateTime(2020),
                        lastDate: DateTime(2030),
                      );
                      if (picked != null) {
                        hireDateController.text = intl.DateFormat('yyyy-MM-dd').format(picked);
                      }
                    },
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('إلغاء'),
            ),
            ElevatedButton(
              onPressed: () async {
                if (formKey.currentState!.validate()) {
                  final newEmp = EmployeeModel(
                    id: employee?.id,
                    name: nameController.text.trim(),
                    salary: double.parse(salaryController.text).toStringAsFixed(2),
                    fixedDeparture: departureController.text.isEmpty
                        ? '0.00'
                        : double.parse(departureController.text).toStringAsFixed(2),
                    hireDate: hireDateController.text,
                  );

                  try {
                    if (employee == null) {
                      await ref.read(employeesProvider.notifier).addEmployee(newEmp);
                    } else {
                      await ref.read(employeesProvider.notifier).editEmployee(employee.id!, newEmp);
                    }
                    if (context.mounted) {
                      Navigator.pop(context);
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('تم حفظ البيانات بنجاح 💾')),
                      );
                    }
                  } catch (e) {
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('فشل الحفظ: $e')),
                      );
                    }
                  }
                }
              },
              child: const Text('حفظ'),
            ),
          ],
        );
      },
    );
  }

  void _confirmDelete(BuildContext context, WidgetRef ref, EmployeeModel employee) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('تأكيد الحذف ⚠️'),
          content: Text('هل أنت متأكد من رغبتك في حذف العامل "${employee.name}"؟ سيتم حذف جميع بيانات الأرشفة والعمليات المرتبطة به بشكل نهائي لا يمكن التراجع عنه.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('إلغاء'),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white),
              onPressed: () async {
                try {
                  await ref.read(employeesProvider.notifier).removeEmployee(employee.id!);
                  if (context.mounted) {
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('تم حذف العامل بنجاح')),
                    );
                  }
                } catch (e) {
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('فشل الحذف: $e')),
                    );
                  }
                }
              },
              child: const Text('تأكيد الحذف'),
            ),
          ],
        );
      },
    );
  }
}
