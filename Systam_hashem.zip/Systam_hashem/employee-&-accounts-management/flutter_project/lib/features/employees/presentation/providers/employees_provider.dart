import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/network/api_service_provider.dart';
import '../../data/models/employee_model.dart';

class EmployeesNotifier extends StateNotifier<AsyncValue<List<EmployeeModel>>> {
  final Ref _ref;

  EmployeesNotifier(this._ref) : super(const AsyncValue.loading()) {
    loadEmployees();
  }

  Future<void> loadEmployees() async {
    state = const AsyncValue.loading();
    try {
      final api = _ref.read(apiServiceProvider);
      final employees = await api.getAllEmployees();
      state = AsyncValue.data(employees);
    } catch (e, stack) {
      state = AsyncValue.error(e, stack);
    }
  }

  Future<void> addEmployee(EmployeeModel employee) async {
    try {
      final api = _ref.read(apiServiceProvider);
      await api.createEmployee(employee);
      await loadEmployees();
    } catch (e) {
      rethrow;
    }
  }

  Future<void> editEmployee(int id, EmployeeModel employee) async {
    try {
      final api = _ref.read(apiServiceProvider);
      await api.updateEmployee(id, employee);
      await loadEmployees();
    } catch (e) {
      rethrow;
    }
  }

  Future<void> removeEmployee(int id) async {
    try {
      final api = _ref.read(apiServiceProvider);
      await api.deleteEmployee(id);
      await loadEmployees();
    } catch (e) {
      rethrow;
    }
  }
}

final employeesProvider =
    StateNotifierProvider<EmployeesNotifier, AsyncValue<List<EmployeeModel>>>((ref) {
  return EmployeesNotifier(ref);
});
