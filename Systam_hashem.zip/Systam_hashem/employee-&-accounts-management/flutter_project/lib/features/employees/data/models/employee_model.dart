class EmployeeModel {
  final int? id;
  final String name;
  final String salary;
  final String fixedDeparture;
  final String hireDate;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  EmployeeModel({
    this.id,
    required this.name,
    required this.salary,
    this.fixedDeparture = '0.00',
    required this.hireDate,
    this.createdAt,
    this.updatedAt,
  });

  factory EmployeeModel.fromJson(Map<String, dynamic> json) {
    return EmployeeModel(
      id: json['id'] as int?,
      name: json['name'] as String,
      salary: json['salary'].toString(),
      fixedDeparture: (json['fixedDeparture'] ?? json['fixed_departure'] ?? '0.00').toString(),
      hireDate: json['hireDate'] ?? json['hire_date'] as String,
      createdAt: json['created_at'] != null ? DateTime.parse(json['created_at']) : null,
      updatedAt: json['updated_at'] != null ? DateTime.parse(json['updated_at']) : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      if (id != null) 'id': id,
      'name': name,
      'salary': salary,
      'fixedDeparture': fixedDeparture,
      'hireDate': hireDate,
    };
  }
}
