import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/network/api_service_provider.dart';

class ArchiveNotifier extends StateNotifier<AsyncValue<void>> {
  final Ref _ref;

  ArchiveNotifier(this._ref) : super(const AsyncValue.data(null));

  Future<void> submitDailyLogs(List<Map<String, dynamic>> payload) async {
    state = const AsyncValue.loading();
    try {
      final api = _ref.read(apiServiceProvider);
      await api.submitArchive(payload);
      state = const AsyncValue.data(null);
    } catch (e, stack) {
      state = AsyncValue.error(e, stack);
      rethrow;
    }
  }
}

final archiveProvider =
    StateNotifierProvider<ArchiveNotifier, AsyncValue<void>>((ref) {
  return ArchiveNotifier(ref);
});
