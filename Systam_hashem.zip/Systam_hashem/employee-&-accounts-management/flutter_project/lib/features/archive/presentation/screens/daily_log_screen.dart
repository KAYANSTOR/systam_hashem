import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:intl/intl.dart' as intl;
import '../../../../main.dart';
import '../../../employees/presentation/providers/employees_provider.dart';
import '../providers/archive_provider.dart';

class DailyLogScreen extends ConsumerStatefulWidget {
  const DailyLogScreen({super.key});

  @override
  ConsumerState<DailyLogScreen> createState() => _DailyLogScreenState();
}

class _DailyLogScreenState extends ConsumerState<DailyLogScreen> {
  late DateTime _selectedDate;
  final Map<int, String> _attendanceMap = {}; // employeeId -> attendance state
  final Map<int, TextEditingController> _delayControllers = {};
  final Map<int, TextEditingController> _overtimeControllers = {};
  final Map<int, TextEditingController> _advanceControllers = {};
  final Map<int, TextEditingController> _noteControllers = {};

  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    _selectedDate = DateTime.now();
  }

  @override
  void dispose() {
    for (var controller in _delayControllers.values) {
      controller.dispose();
    }
    for (var controller in _overtimeControllers.values) {
      controller.dispose();
    }
    for (var controller in _advanceControllers.values) {
      controller.dispose();
    }
    for (var controller in _noteControllers.values) {
      controller.dispose();
    }
    super.dispose();
  }

  void _initializeControllers(List<dynamic> employees) {
    for (var emp in employees) {
      if (!_attendanceMap.containsKey(emp.id)) {
        _attendanceMap[emp.id!] = 'حاضر'; // default
      }
      if (!_delayControllers.containsKey(emp.id)) {
        _delayControllers[emp.id!] = TextEditingController(text: '0');
      }
      if (!_overtimeControllers.containsKey(emp.id)) {
        _overtimeControllers[emp.id!] = TextEditingController(text: '0.00');
      }
      if (!_advanceControllers.containsKey(emp.id)) {
        // Pre-fill with fixed departure if exists
        _advanceControllers[emp.id!] = TextEditingController(text: emp.fixedDeparture);
      }
      if (!_noteControllers.containsKey(emp.id)) {
        _noteControllers[emp.id!] = TextEditingController();
      }
    }
  }

  String _getArabicDayName(DateTime date) {
    final days = {
      'Monday': 'الاثنين',
      'Tuesday': 'الثلاثاء',
      'Wednesday': 'الأربعاء',
      'Thursday': 'الخميس',
      'Friday': 'الجمعة',
      'Saturday': 'السبت',
      'Sunday': 'الأحد',
    };
    final englishDay = intl.DateFormat('EEEE').format(date);
    return days[englishDay] ?? englishDay;
  }

  @override
  Widget build(BuildContext context) {
    final employeesState = ref.watch(employeesProvider);
    final archiveState = ref.watch(archiveProvider);

    return Scaffold(
      body: employeesState.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (err, stack) => Center(child: Text('خطأ في تحميل العمال: $err')),
        data: (employees) {
          if (employees.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(LucideIcons.users, size: 64, color: Colors.grey[400]),
                  const SizedBox(height: 16),
                  const Text('لا يوجد موظفون لتسجيل حضورهم. يرجى إضافة عمال أولاً.'),
                ],
              ),
            );
          }

          _initializeControllers(employees);

          return Form(
            key: _formKey,
            child: Column(
              children: [
                // Header Panel
                Card(
                  margin: const EdgeInsets.all(16),
                  color: Colors.blue.withOpacity(0.05),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'الترحيل اليومي والأرشفة',
                              style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'اليوم المحدد: ${_getArabicDayName(_selectedDate)}',
                              style: const TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ],
                        ),
                        OutlinedButton.icon(
                          onPressed: () async {
                            final picked = await showDatePicker(
                              context: context,
                              initialDate: _selectedDate,
                              firstDate: DateTime(2025),
                              lastDate: DateTime(2030),
                            );
                            if (picked != null) {
                              setState(() {
                                _selectedDate = picked;
                              });
                            }
                          },
                          icon: const Icon(LucideIcons.calendar),
                          label: Text(intl.DateFormat('yyyy-MM-dd').format(_selectedDate)),
                        ),
                      ],
                    ),
                  ),
                ),

                // Employee Batch Entry List
                Expanded(
                  child: ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: employees.length,
                    itemBuilder: (context, index) {
                      final emp = employees[index];
                      final empId = emp.id!;

                      return Card(
                        margin: const EdgeInsets.only(bottom: 16),
                        child: Padding(
                          padding: const EdgeInsets.all(16.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Employee Header Row
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    emp.name,
                                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                                  ),
                                  // Attendance Dropdown Segment
                                  SegmentedButton<String>(
                                    segments: const [
                                      ButtonSegment(value: 'حاضر', label: Text('حاضر')),
                                      ButtonSegment(value: 'غائب', label: Text('غائب')),
                                      ButtonSegment(value: 'إجازة', label: Text('إجازة')),
                                    ],
                                    selected: {_attendanceMap[empId] ?? 'حاضر'},
                                    onSelectionChanged: (newVal) {
                                      setState(() {
                                        _attendanceMap[empId] = newVal.first;
                                      });
                                    },
                                  ),
                                ],
                              ),
                              const Divider(height: 24),

                              // Log Options Inputs
                              Row(
                                children: [
                                  // Delay input
                                  Expanded(
                                    child: TextFormField(
                                      controller: _delayControllers[empId],
                                      keyboardType: TextInputType.number,
                                      decoration: const InputDecoration(
                                        labelText: 'التأخير (دقائق)',
                                        prefixIcon: Icon(LucideIcons.clock, size: 16),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  // Overtime input
                                  Expanded(
                                    child: TextFormField(
                                      controller: _overtimeControllers[empId],
                                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                                      decoration: const InputDecoration(
                                        labelText: 'إضافي (د.إ)',
                                        prefixIcon: Icon(LucideIcons.plusCircle, size: 16),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  // Advance/Departure input (الصرفة)
                                  Expanded(
                                    child: TextFormField(
                                      controller: _advanceControllers[empId],
                                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                                      decoration: const InputDecoration(
                                        labelText: 'الصرفة/السلفة (د.إ)',
                                        prefixIcon: Icon(LucideIcons.wallet, size: 16),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 12),

                              // Note Input
                              TextFormField(
                                controller: _noteControllers[empId],
                                decoration: const InputDecoration(
                                  labelText: 'ملاحظات وتفاصيل إضافية عن يوم العمل',
                                  prefixIcon: Icon(LucideIcons.fileText, size: 16),
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                ),

                // Submit Button Panel
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blue,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      onPressed: archiveState.isLoading
                          ? null
                          : () async {
                              if (_formKey.currentState!.validate()) {
                                final List<Map<String, dynamic>> payload = [];
                                final dateStr = intl.DateFormat('yyyy-MM-dd').format(_selectedDate);
                                final dayStr = _getArabicDayName(_selectedDate);

                                for (var emp in employees) {
                                  final empId = emp.id!;
                                  final attendance = _attendanceMap[empId] ?? 'حاضر';
                                  final delay = int.tryParse(_delayControllers[empId]?.text ?? '0') ?? 0;
                                  final overtime = double.tryParse(_overtimeControllers[empId]?.text ?? '0.00') ?? 0.00;
                                  final advance = double.tryParse(_advanceControllers[empId]?.text ?? '0.00') ?? 0.00;
                                  final noteStr = _noteControllers[empId]?.text.trim() ?? '';

                                  payload.add({
                                    'employeeId': empId,
                                    'date': dateStr,
                                    'day': dayStr,
                                    'attendance': attendance,
                                    'delay': delay,
                                    'departure': overtime.toStringAsFixed(2), // note: backend maps overtime/departure dynamically
                                    'overtime': overtime.toStringAsFixed(2),
                                    'advance': advance.toStringAsFixed(2),
                                    'note': noteStr.isEmpty ? null : noteStr,
                                  });
                                }

                                try {
                                  await ref.read(archiveProvider.notifier).submitDailyLogs(payload);
                                  if (mounted) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(content: Text('تم ترحيل البيانات اليومية وحفظ الأرشيف بنجاح! 🚀')),
                                    );
                                  }
                                } catch (e) {
                                  if (mounted) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(content: Text('فشل الترحيل: $e')),
                                    );
                                  }
                                }
                              }
                            },
                      icon: archiveState.isLoading
                          ? const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                            )
                          : const Icon(LucideIcons.checkCheck),
                      label: const Text(
                        'تأكيد ترحيل وحفظ الأرشيف اليومي',
                        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
