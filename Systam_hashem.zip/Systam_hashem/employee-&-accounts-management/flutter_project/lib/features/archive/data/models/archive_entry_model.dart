class ArchiveEntryModel {
  final int? id;
  final int employeeId;
  final String date;
  final String day;
  final String attendance;
  final int delay;
  final String departure;
  final String overtime;
  final String advance;
  final String? note;

  ArchiveEntryModel({
    this.id,
    required this.employeeId,
    required this.date,
    required this.day,
    required this.attendance,
    this.delay = 0,
    this.departure = '0.00',
    this.overtime = '0.00',
    this.advance = '0.00',
    this.note,
  });

  factory ArchiveEntryModel.fromJson(Map<String, dynamic> json) {
    return ArchiveEntryModel(
      id: json['id'] as int?,
      employeeId: json['employeeId'] ?? json['employee_id'] as int,
      date: json['date'] ?? json['entry_date'] as String,
      day: json['day'] ?? json['day_of_week'] as String,
      attendance: json['attendance'] as String,
      delay: json['delay'] ?? json['delay_minutes'] ?? 0,
      departure: (json['departure'] ?? json['departure_amount'] ?? '0.00').toString(),
      overtime: (json['overtime'] ?? json['overtime_amount'] ?? '0.00').toString(),
      advance: (json['advance'] ?? json['advance_amount'] ?? '0.00').toString(),
      note: json['note'] as String?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'date': date,
      'day': day,
      'attendance': attendance,
      'delay': delay,
      'departure': departure,
      'overtime': overtime,
      'advance': advance,
      'note': note,
    };
  }
}
