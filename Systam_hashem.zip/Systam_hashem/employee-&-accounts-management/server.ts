import 'dotenv/config';
import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';

// ── Routes ──────────────────────────────────────────────────
import authRoutes       from './src/server/routes/auth.routes.ts';
import employeeRoutes   from './src/server/routes/employee.routes.ts';
import archiveRoutes    from './src/server/routes/archive.routes.ts';
import inventoryRoutes  from './src/server/routes/inventory.routes.ts';
import productionRoutes from './src/server/routes/production.routes.ts';

// ── Middlewares ──────────────────────────────────────────────
import { authenticate }            from './src/server/middleware/authenticate.ts';
import { blockFinancialPaths }     from './src/server/middleware/roleGuard.ts';
import { globalErrorHandler, notFoundHandler } from './src/server/middleware/errorHandler.ts';

async function startServer() {
  const app  = express();
  const PORT = parseInt(process.env.PORT || '3000', 10);

  // ── Global Middlewares ──────────────────────────────────────
  app.use(express.json({ limit: '5mb' }));
  app.use(express.urlencoded({ extended: true }));

  // CORS للتطوير المحلي
  if (process.env.NODE_ENV !== 'production') {
    app.use((req, res, next) => {
      res.header('Access-Control-Allow-Origin', '*');
      res.header('Access-Control-Allow-Methods', 'GET,POST,PUT,PATCH,DELETE,OPTIONS');
      res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
      if (req.method === 'OPTIONS') return res.sendStatus(204);
      next();
    });
  }

  // ── Health Check ────────────────────────────────────────────
  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  // ── API Routes ──────────────────────────────────────────────

  // المصادقة — عام (لا يحتاج authenticate هنا)
  app.use('/api/auth', authRoutes);

  // الموظفون — يحتاج authenticate (مُضمَّن في الـ route)
  app.use('/api/employees', employeeRoutes);

  // الأرشيف (الحضور + الحسابات اليومية)
  app.use('/api', archiveRoutes);

  // المخزون — authenticate + roleGuard مُضمَّنان في الـ route
  app.use('/api/inventory', inventoryRoutes);

  // الإنتاج التشغيلي — authenticate + roleGuard مُضمَّنان
  app.use('/api/production', productionRoutes);

  // ── Finance Router (Protected — blockFinancialPaths) ────────
  // أي router يُضاف هنا سيُمنع تلقائياً عن materials_manager
  // app.use('/api/finance', authenticate, blockFinancialPaths, financeRoutes);
  // app.use('/api/sales',   authenticate, blockFinancialPaths, salesRoutes);

  // ── 404 Handler ─────────────────────────────────────────────
  // (يجب أن يكون قبل Vite middleware في development)

  // ── Vite / Static ───────────────────────────────────────────
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  // ── Global Error Handler (يجب أن يكون آخر middleware) ───────
  app.use(globalErrorHandler);

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`\n🚀 Embroidery ERP Server running on http://0.0.0.0:${PORT}`);
    console.log(`   Environment: ${process.env.NODE_ENV || 'development'}`);
    console.log(`   API Base:    http://0.0.0.0:${PORT}/api\n`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
