/**
 * ============================================================
 *  EMBROIDERY ERP — Shared TypeScript Types
 * ============================================================
 *  ملف الأنواع المشتركة بين Frontend و Backend
 *  هذا الملف مستقل تماماً عن Drizzle لاستخدامه في React
 * ============================================================
 */

// ============================================================
// ENUMS
// ============================================================

export type UserRole = 'admin' | 'accountant' | 'materials_manager' | 'production_supervisor' | 'viewer';
export type AttendanceStatus = 'present' | 'absent' | 'half_day' | 'holiday' | 'on_leave';
export type MovementType = 'IN' | 'OUT';
export type MaterialUnit = 'kg' | 'gram' | 'piece' | 'meter' | 'spool' | 'box' | 'liter';
export type EmployeeStatus = 'active' | 'inactive' | 'terminated';

// ============================================================
// USER / EMPLOYEE
// ============================================================

/** بيانات المستخدم الكاملة (للمدير والمحاسب فقط) */
export interface User {
  id:             number;
  fullName:       string;
  phone?:         string;
  hireDate:       string;
  status:         EmployeeStatus;
  monthlySalary:  string;
  fixedDeparture: string;
  username:       string;
  role:           UserRole;
  isActive:       boolean;
  createdAt?:     string;
  updatedAt?:     string;
}

/**
 * بيانات المستخدم العامة (لجميع الأدوار)
 * بدون البيانات المالية — آمن للإرجاع في الـ API العامة
 */
export interface PublicUser {
  id:       number;
  fullName: string;
  username: string;
  role:     UserRole;
  status:   EmployeeStatus;
  hireDate: string;
  phone?:   string;
}

/** بيانات الجلسة الحالية من JWT */
export interface AuthPayload {
  userId:   number;
  username: string;
  role:     UserRole;
  iat?:     number;
  exp?:     number;
}

// ============================================================
// ARCHIVE ENTRIES
// ============================================================

export interface ArchiveEntry {
  id:              number;
  employeeId:      number;
  entryDate:       string;
  dayOfWeek:       string;
  attendance:      AttendanceStatus;
  delayMinutes:    number;
  departureAmount: string;
  overtimeAmount:  string;
  advanceAmount:   string;
  note?:           string;
  recordedBy?:     number;
  createdAt?:      string;
  updatedAt?:      string;
}

/** ملخص شهري لحسابات راتب موظف */
export interface MonthlySalarySummary {
  month:              number;
  year:               number;
  totalDaysPresent:   number;
  totalHalfDays:      number;
  totalDelayMinutes:  number;
  delayDeduction:     number;
  totalDeparture:     number;
  totalOvertime:      number;
  totalAdvances:      number;
  grossSalary:        number;
  netSalary:          number;
}

/** استجابة كشف حساب الموظف */
export interface EmployeeStatementResponse {
  employeeId:       number;
  employeeName:     string;
  monthlySalary:    number;
  entries:          ArchiveEntry[];
  monthlySummaries: MonthlySalarySummary[];
}

// ============================================================
// MATERIALS
// ============================================================

export interface Material {
  id:           number;
  name:         string;
  description?: string;
  currentStock: string;
  minThreshold: string;
  unit:         MaterialUnit;
  isActive:     boolean;
  createdBy?:   number;
  createdAt?:   string;
  updatedAt?:   string;
}

/** مادة مع حالة المخزون */
export interface MaterialWithStatus extends Material {
  isLowStock: boolean;
}

// ============================================================
// MATERIAL MOVEMENTS
// ============================================================

export interface MaterialMovement {
  id:         number;
  materialId: number;
  type:       MovementType;
  quantity:   string;
  stockAfter: string;
  userId:     number;
  note?:      string;
  createdAt:  string;
}

/** حركة مخزون مع بيانات المادة والمستخدم (للتقارير) */
export interface MaterialMovementDetailed extends MaterialMovement {
  materialName: string;
  materialUnit: MaterialUnit;
  userName:     string;
}

// ────── Request / Response DTOs ──────────────────────────────

export interface DispenseMaterialRequest {
  materialId: number;
  quantity:   number;
  note?:      string;
}

export interface DispenseMaterialResponse {
  movement:   MaterialMovement;
  isLowStock: boolean;
  stockAfter: number;
  message:    string;
}

export interface ReceiveMaterialRequest {
  materialId: number;
  quantity:   number;
  note?:      string;
}

// ============================================================
// DAILY PRODUCTION LOGS
// ============================================================

/**
 * سجل إنتاج يومي — لا توجد حقول مالية هنا إطلاقاً
 * هدفه تتبع الأداء التشغيلي فقط (كم قطعة طُرِّزت)
 */
export interface DailyProductionLog {
  id:             number;
  employeeId:     number;
  productionDate: string;
  itemName:       string;
  quantity:       number;
  machineCode?:   string;
  shiftType?:     string;
  note?:          string;
  recordedBy?:    number;
  createdAt?:     string;
}

// ────── Request / Response DTOs ──────────────────────────────

export interface CreateProductionLogRequest {
  employeeId:     number;
  productionDate: string;
  itemName:       string;
  quantity:       number;
  machineCode?:   string;
  shiftType?:     string;
  note?:          string;
}

// ============================================================
// DAILY PERFORMANCE REPORT (تقرير الأداء اليومي)
// ============================================================

/**
 * بطاقة الأداء اليومي للموظف
 * تجمع: حالة الحضور + سجلات الإنتاج التشغيلية
 *
 * قاعدة صارمة: بدون أي معلومات عن الراتب أو المبالغ المالية
 */
export interface DailyPerformanceReport {
  date:       string;
  employee: {
    id:       number;
    fullName: string;
    role:     UserRole;
  };
  attendance: {
    status:          AttendanceStatus;
    delayMinutes:    number;
  } | null;
  production: {
    totalItems:    number;
    logs:          DailyProductionLog[];
  };
}

// ============================================================
// DASHBOARD STATS
// ============================================================

export interface DashboardStats {
  totalEmployees:       number;
  activeEmployees:      number;
  presentToday:         number;
  absentToday:          number;
  // مخزون
  totalMaterials:       number;
  lowStockCount:        number;
  // إنتاج
  totalProductionToday: number;
}

// ============================================================
// API RESPONSES
// ============================================================

export interface ApiSuccess<T> {
  success: true;
  data:    T;
  message?: string;
}

export interface ApiError {
  success: false;
  error:   string;
  code?:   string;
}

export type ApiResponse<T> = ApiSuccess<T> | ApiError;

// ============================================================
// ROLE PERMISSIONS — خريطة الصلاحيات
// ============================================================

export const ROLE_PERMISSIONS: Record<UserRole, {
  canAccessFinance:    boolean;
  canAccessSales:      boolean;
  canManageMaterials:  boolean;
  canRecordProduction: boolean;
  canManageUsers:      boolean;
  canViewReports:      boolean;
}> = {
  admin: {
    canAccessFinance:    true,
    canAccessSales:      true,
    canManageMaterials:  true,
    canRecordProduction: true,
    canManageUsers:      true,
    canViewReports:      true,
  },
  accountant: {
    canAccessFinance:    true,
    canAccessSales:      true,
    canManageMaterials:  false,
    canRecordProduction: false,
    canManageUsers:      false,
    canViewReports:      true,
  },
  materials_manager: {
    canAccessFinance:    false,  // ← ممنوع صراحةً
    canAccessSales:      false,  // ← ممنوع صراحةً
    canManageMaterials:  true,
    canRecordProduction: false,
    canManageUsers:      false,
    canViewReports:      false,
  },
  production_supervisor: {
    canAccessFinance:    false,
    canAccessSales:      false,
    canManageMaterials:  false,
    canRecordProduction: true,
    canManageUsers:      false,
    canViewReports:      false,
  },
  viewer: {
    canAccessFinance:    false,
    canAccessSales:      false,
    canManageMaterials:  false,
    canRecordProduction: false,
    canManageUsers:      false,
    canViewReports:      true,
  },
};
