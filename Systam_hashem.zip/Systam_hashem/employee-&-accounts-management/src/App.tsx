import React, { useState } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import Navigation from './components/Navigation';
import LoginPage from './pages/LoginPage';
import InventoryDispenseForm from './components/InventoryDispenseForm';
import EmployeeDailyReportCard from './components/EmployeeDailyReportCard';
import { ROLE_PERMISSIONS } from './types';

// ── Loading Screen ────────────────────────────────────────────
const LoadingScreen = () => (
  <div className="min-h-screen bg-slate-950 flex items-center justify-center">
    <div className="text-center">
      <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-blue-500 to-violet-600 flex items-center justify-center mx-auto mb-4 animate-pulse">
        <svg className="w-7 h-7 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
        </svg>
      </div>
      <p className="text-slate-400 text-sm">جارٍ التحميل...</p>
    </div>
  </div>
);

// ── Dashboard Page (placeholder) ──────────────────────────────
const DashboardPage = () => {
  const { user } = useAuth();
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">لوحة التحكم</h1>
        <p className="text-slate-500 mt-1">مرحباً، <span className="text-blue-400 font-medium">{user?.fullName}</span></p>
      </div>
      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {[
          { label: 'إجمالي الموظفين', value: '—', color: 'from-blue-500 to-blue-600', icon: '👥' },
          { label: 'حاضرون اليوم',    value: '—', color: 'from-green-500 to-green-600', icon: '✅' },
          { label: 'إنتاج اليوم',     value: '—', color: 'from-violet-500 to-violet-600', icon: '🧵' },
        ].map((stat) => (
          <div key={stat.label} className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
            <div className="flex items-center justify-between mb-3">
              <span className="text-2xl">{stat.icon}</span>
              <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${stat.color} opacity-20`} />
            </div>
            <p className="text-2xl font-bold text-white">{stat.value}</p>
            <p className="text-sm text-slate-500 mt-1">{stat.label}</p>
          </div>
        ))}
      </div>

      <div className="bg-slate-900 border border-dashed border-slate-700 rounded-2xl p-8 text-center">
        <p className="text-slate-500 text-sm">استخدم القائمة الجانبية للتنقل بين الأقسام</p>
      </div>
    </div>
  );
};

// ── Generic Page Wrapper ──────────────────────────────────────
const PageWrapper: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className="space-y-6">
    <h1 className="text-2xl font-bold text-white">{title}</h1>
    {children}
  </div>
);

// ── Forbidden Page ────────────────────────────────────────────
const ForbiddenPage = () => (
  <div className="flex flex-col items-center justify-center py-20 text-center">
    <div className="text-6xl mb-4">🔒</div>
    <h2 className="text-xl font-bold text-white mb-2">ممنوع الوصول</h2>
    <p className="text-slate-500 text-sm">ليس لديك صلاحية لرؤية هذه الصفحة</p>
  </div>
);

// ============================================================
// Main App Shell (بعد تسجيل الدخول)
// ============================================================
const AppShell: React.FC = () => {
  const { user } = useAuth();
  const [activePage, setActivePage] = useState('dashboard');

  if (!user) return null;
  const perms = ROLE_PERMISSIONS[user.role];

  const renderPage = () => {
    switch (activePage) {
      case 'dashboard':
        return <DashboardPage />;

      case 'inventory':
        if (!perms.canManageMaterials) return <ForbiddenPage />;
        return (
          <PageWrapper title="إدارة المخزون">
            <InventoryDispenseForm />
          </PageWrapper>
        );

      case 'production':
        if (!perms.canRecordProduction && !perms.canManageUsers) return <ForbiddenPage />;
        return (
          <PageWrapper title="الإنتاج التشغيلي">
            <EmployeeDailyReportCard />
          </PageWrapper>
        );

      case 'employees':
        if (!perms.canManageUsers && !perms.canAccessFinance) return <ForbiddenPage />;
        return (
          <PageWrapper title="الموظفون">
            <EmployeeDailyReportCard />
          </PageWrapper>
        );

      case 'finance':
        if (!perms.canAccessFinance) return <ForbiddenPage />;
        return (
          <PageWrapper title="الحسابات المالية">
            <div className="bg-slate-900 border border-dashed border-slate-700 rounded-2xl p-8 text-center">
              <p className="text-slate-500 text-sm">وحدة الحسابات المالية — قيد التطوير</p>
            </div>
          </PageWrapper>
        );

      case 'sales':
        if (!perms.canAccessSales) return <ForbiddenPage />;
        return (
          <PageWrapper title="المبيعات">
            <div className="bg-slate-900 border border-dashed border-slate-700 rounded-2xl p-8 text-center">
              <p className="text-slate-500 text-sm">وحدة المبيعات — قيد التطوير</p>
            </div>
          </PageWrapper>
        );

      case 'reports':
        if (!perms.canViewReports) return <ForbiddenPage />;
        return (
          <PageWrapper title="التقارير">
            <div className="bg-slate-900 border border-dashed border-slate-700 rounded-2xl p-8 text-center">
              <p className="text-slate-500 text-sm">وحدة التقارير — قيد التطوير</p>
            </div>
          </PageWrapper>
        );

      default:
        return <DashboardPage />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-row-reverse" dir="rtl">
      {/* Sidebar (Desktop) */}
      <Navigation activePage={activePage} onNavigate={setActivePage} />

      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        {/* Mobile top bar offset */}
        <div className="lg:hidden h-16" />
        <div className="p-6 max-w-5xl mx-auto">
          {renderPage()}
        </div>
      </main>
    </div>
  );
};

// ============================================================
// Root App — AuthProvider + Route Guard
// ============================================================
const AuthGuard: React.FC = () => {
  const { isLoading, isLoggedIn } = useAuth();

  if (isLoading)   return <LoadingScreen />;
  if (!isLoggedIn) return <LoginPage />;
  return <AppShell />;
};

const App: React.FC = () => (
  <AuthProvider>
    <AuthGuard />
  </AuthProvider>
);

export default App;
