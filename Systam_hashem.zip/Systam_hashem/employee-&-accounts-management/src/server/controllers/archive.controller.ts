import { Request, Response } from 'express';
import { ArchiveModel } from '../models/archive.model.ts';
import { EmployeeModel } from '../models/employee.model.ts';

export class ArchiveController {
  static async getInitialData(req: Request, res: Response) {
    try {
      const employees = await EmployeeModel.getAll();
      const today = new Date().toISOString().split('T')[0];
      
      const todayEntries = await ArchiveModel.getByDate(today);
      
      const totalEmployees = employees.length;
      const totalPresentToday = todayEntries.filter(e => e.attendance === 'Present' || e.attendance === 'حاضر').length;
      const totalAbsentToday = todayEntries.filter(e => e.attendance === 'Absent' || e.attendance === 'غائب').length;
      
      // Calculate total withdrawals (advances + departures) for the current month
      const startOfMonth = new Date();
      startOfMonth.setDate(1);
      const startOfMonthStr = startOfMonth.toISOString().split('T')[0];
      
      let totalWithdrawalsMonth = 0;
      for (const emp of employees) {
        const empEntries = await ArchiveModel.getByEmployeeId(emp.id, startOfMonthStr, today);
        for (const entry of empEntries) {
          totalWithdrawalsMonth += parseFloat(entry.departureAmount || '0') + parseFloat(entry.advanceAmount || '0');
        }
      }

      res.json({
        employees,
        dashboardStats: {
          totalEmployees,
          totalPresentToday,
          totalAbsentToday,
          totalWithdrawalsMonth,
        }
      });
    } catch (error: any) {
      console.error('Error in ArchiveController.getInitialData:', error);
      res.status(500).json({ error: error.message || 'Internal server error' });
    }
  }

  static async archiveEntries(req: Request, res: Response) {
    try {
      const payload = req.body; // Array of { employeeId, entries: [{ date, day, attendance, delay, departure, overtime, advance, note }] }
      
      if (!Array.isArray(payload)) {
        return res.status(400).json({ error: 'Payload must be an array of employee entries' });
      }

      const flatEntries: any[] = [];
      for (const item of payload) {
        const { employeeId, entries } = item;
        if (!employeeId || !Array.isArray(entries)) continue;

        for (const entry of entries) {
          flatEntries.push({
            employeeId,
            entryDate: entry.date,
            dayOfWeek: entry.day,
            attendance: entry.attendance,
            delayMinutes: entry.delay || 0,
            departureAmount: entry.departure || '0.00',
            overtimeAmount: entry.overtime || '0.00',
            advanceAmount: entry.advance || '0.00',
            note: entry.note || null,
          });
        }
      }

      if (flatEntries.length > 0) {
        await ArchiveModel.createBatch(flatEntries);
      }

      res.json({ message: 'Entries archived successfully' });
    } catch (error: any) {
      console.error('Error in ArchiveController.archiveEntries:', error);
      res.status(500).json({ error: error.message || 'Internal server error' });
    }
  }

  static async getStatement(req: Request, res: Response) {
    try {
      const employeeId = parseInt(req.query.employeeId as string, 10);
      const startDate = req.query.startDate as string;
      const endDate = req.query.endDate as string;

      if (isNaN(employeeId) || !startDate || !endDate) {
        return res.status(400).json({ error: 'Missing or invalid parameters: employeeId, startDate, and endDate are required.' });
      }

      const employee = await EmployeeModel.getById(employeeId);
      if (!employee) {
        return res.status(404).json({ error: 'Employee not found' });
      }

      const entries = await ArchiveModel.getByEmployeeId(employeeId, startDate, endDate);

      // Group entries by Month/Year to calculate Monthly Summaries
      const monthlyGroups: { [key: string]: any[] } = {};
      
      for (const entry of entries) {
        const dateObj = new Date(entry.entryDate);
        const key = `${dateObj.getMonth() + 1}-${dateObj.getFullYear()}`;
        if (!monthlyGroups[key]) {
          monthlyGroups[key] = [];
        }
        monthlyGroups[key].push(entry);
      }

      const monthlySalary = parseFloat(employee.salary);
      const dailyWage = monthlySalary / 30;
      const hourlyWage = dailyWage / 12;

      const monthlySummaries = Object.keys(monthlyGroups).map(key => {
        const [month, year] = key.split('-').map(Number);
        const groupEntries = monthlyGroups[key];

        let totalAttendanceDays = 0;
        let totalDelayMinutes = 0;
        let totalDepartureAmount = 0;
        let totalOvertimeAmount = 0;
        let totalAdvanceAmount = 0;

        for (const entry of groupEntries) {
          const attendance = entry.attendance.toLowerCase();
          
          if (attendance === 'present' || attendance === 'حاضر') {
            totalAttendanceDays += 1;
          } else if (attendance === 'half day' || attendance === 'نصف يوم') {
            totalAttendanceDays += 0.5;
          } // Absent / Holiday gets 0

          totalDelayMinutes += entry.delayMinutes || 0;
          totalDepartureAmount += parseFloat(entry.departureAmount || '0');
          totalOvertimeAmount += parseFloat(entry.overtimeAmount || '0');
          totalAdvanceAmount += parseFloat(entry.advanceAmount || '0');
        }

        const delayDeduction = (totalDelayMinutes / 60) * hourlyWage;
        const remainingSalary = (dailyWage * totalAttendanceDays) + totalOvertimeAmount - totalDepartureAmount - totalAdvanceAmount - delayDeduction;

        return {
          month,
          year,
          totalAttendanceDays,
          totalDelayMinutes,
          delayDeduction: parseFloat(delayDeduction.toFixed(2)),
          totalDepartureAmount: parseFloat(totalDepartureAmount.toFixed(2)),
          totalOvertimeAmount: parseFloat(totalOvertimeAmount.toFixed(2)),
          totalAdvanceAmount: parseFloat(totalAdvanceAmount.toFixed(2)),
          remainingSalary: parseFloat(remainingSalary.toFixed(2)),
        };
      });

      res.json({
        employeeName: employee.name,
        monthlySalary,
        entries: entries.map(e => ({
          date: e.entryDate,
          day: e.dayOfWeek,
          attendance: e.attendance,
          delay: e.delayMinutes,
          departure: parseFloat(e.departureAmount || '0'),
          overtime: parseFloat(e.overtimeAmount || '0'),
          advance: parseFloat(e.advanceAmount || '0'),
          note: e.note,
        })),
        monthlySummaries,
      });
    } catch (error: any) {
      console.error('Error in ArchiveController.getStatement:', error);
      res.status(500).json({ error: error.message || 'Internal server error' });
    }
  }
}
