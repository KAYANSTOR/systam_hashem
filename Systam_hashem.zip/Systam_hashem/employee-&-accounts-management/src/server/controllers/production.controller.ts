import { Response } from 'express';
import { eq, and } from 'drizzle-orm';
import { db } from '../../db/index.ts';
import { users, archiveEntries, dailyProductionLogs } from '../../db/schema.ts';
import { asyncHandler } from '../middleware/asyncHandler.ts';
import { AppError } from '../middleware/errorHandler.ts';
import type { AuthRequest } from '../middleware/authenticate.ts';
import type { DailyPerformanceReport } from '../../types.ts';

// ============================================================
// GET /api/production/report/daily
// ============================================================
/**
 * getDailyPerformanceReport
 *
 * يُرجع "بطاقة الأداء اليومي" للموظف:
 *   - حالة الحضور + دقائق التأخير (من archive_entries)
 *   - قائمة القطع المطرّزة + إجمالي القطع (من daily_production_logs)
 *
 * ─── قاعدة صارمة ────────────────────────────────────────
 * لا تُعاد أي بيانات مالية (لا راتب، لا مكافأة، لا خصم).
 * هذا تقرير "تشغيلي بحت" فقط.
 * ─────────────────────────────────────────────────────────
 *
 * Query params: ?employeeId=<id>&date=<YYYY-MM-DD>
 */
export const getDailyPerformanceReport = asyncHandler(
  async (req: AuthRequest, res: Response) => {
    const { employeeId, date } = req.query as {
      employeeId?: string;
      date?:       string;
    };

    // ─── Validation ───────────────────────────────────────
    if (!employeeId || isNaN(parseInt(employeeId, 10))) {
      throw new AppError('employeeId query param is required and must be a number.', 400, 'INVALID_EMPLOYEE_ID');
    }
    if (!date || !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      throw new AppError('date query param is required in format YYYY-MM-DD.', 400, 'INVALID_DATE');
    }

    const empId = parseInt(employeeId, 10);

    // ─── 1. جلب بيانات الموظف (بدون حقول مالية) ──────────
    const empResult = await db
      .select({
        id:       users.id,
        fullName: users.fullName,
        role:     users.role,
      })
      .from(users)
      .where(eq(users.id, empId))
      .limit(1);

    const employee = empResult[0];
    if (!employee) {
      throw new AppError(`Employee with ID ${empId} not found.`, 404, 'EMPLOYEE_NOT_FOUND');
    }

    // ─── 2. جلب سجل الحضور لهذا اليوم ────────────────────
    const attendanceResult = await db
      .select({
        attendance:   archiveEntries.attendance,
        delayMinutes: archiveEntries.delayMinutes,
      })
      .from(archiveEntries)
      .where(
        and(
          eq(archiveEntries.employeeId, empId),
          eq(archiveEntries.entryDate, date)
        )
      )
      .limit(1);

    const attendanceRecord = attendanceResult[0] ?? null;

    // ─── 3. جلب سجلات الإنتاج لهذا اليوم ─────────────────
    const productionResult = await db
      .select({
        id:             dailyProductionLogs.id,
        employeeId:     dailyProductionLogs.employeeId,
        productionDate: dailyProductionLogs.productionDate,
        itemName:       dailyProductionLogs.itemName,
        quantity:       dailyProductionLogs.quantity,
        machineCode:    dailyProductionLogs.machineCode,
        shiftType:      dailyProductionLogs.shiftType,
        note:           dailyProductionLogs.note,
        recordedBy:     dailyProductionLogs.recordedBy,
        createdAt:      dailyProductionLogs.createdAt,
      })
      .from(dailyProductionLogs)
      .where(
        and(
          eq(dailyProductionLogs.employeeId, empId),
          eq(dailyProductionLogs.productionDate, date)
        )
      )
      .orderBy(dailyProductionLogs.createdAt);

    // ─── 4. تجميع إجمالي القطع ────────────────────────────
    const totalItems = productionResult.reduce((sum, log) => sum + log.quantity, 0);

    // ─── 5. بناء الاستجابة (بدون أي بيانات مالية) ─────────
    const report: DailyPerformanceReport = {
      date,
      employee: {
        id:       employee.id,
        fullName: employee.fullName,
        role:     employee.role,
      },
      attendance: attendanceRecord
        ? {
            status:       attendanceRecord.attendance,
            delayMinutes: attendanceRecord.delayMinutes,
          }
        : null,
      production: {
        totalItems,
        logs: productionResult.map((log) => ({
          id:             log.id,
          employeeId:     log.employeeId,
          productionDate: log.productionDate ?? date,
          itemName:       log.itemName,
          quantity:       log.quantity,
          machineCode:    log.machineCode ?? undefined,
          shiftType:      log.shiftType ?? undefined,
          note:           log.note ?? undefined,
          recordedBy:     log.recordedBy ?? undefined,
          createdAt:      log.createdAt?.toISOString(),
        })),
      },
    };

    res.json({ success: true, data: report });
  }
);

// ============================================================
// POST /api/production/logs
// ============================================================
/**
 * تسجيل سجل إنتاج يومي جديد
 * الصلاحية: admin, production_supervisor
 *
 * قاعدة صارمة: لا توجد أي حقول مالية في الـ body المقبول
 */
export const createProductionLog = asyncHandler(
  async (req: AuthRequest, res: Response) => {
    const {
      employeeId,
      productionDate,
      itemName,
      quantity,
      machineCode,
      shiftType,
      note,
    } = req.body as {
      employeeId:      number;
      productionDate:  string;
      itemName:        string;
      quantity:        number;
      machineCode?:    string;
      shiftType?:      string;
      note?:           string;
    };

    // ─── Validation ───────────────────────────────────────
    if (!employeeId)    throw new AppError('employeeId is required.', 400, 'MISSING_EMPLOYEE_ID');
    if (!productionDate) throw new AppError('productionDate is required.', 400, 'MISSING_DATE');
    if (!itemName?.trim()) throw new AppError('itemName is required.', 400, 'MISSING_ITEM_NAME');
    if (!quantity || quantity <= 0) throw new AppError('quantity must be a positive integer.', 400, 'INVALID_QUANTITY');

    // التحقق من وجود الموظف
    const empResult = await db
      .select({ id: users.id })
      .from(users)
      .where(eq(users.id, employeeId))
      .limit(1);

    if (!empResult[0]) {
      throw new AppError(`Employee ${employeeId} not found.`, 404, 'EMPLOYEE_NOT_FOUND');
    }

    const result = await db
      .insert(dailyProductionLogs)
      .values({
        employeeId,
        productionDate,
        itemName:    itemName.trim(),
        quantity:    Math.floor(quantity),
        machineCode: machineCode?.trim() || null,
        shiftType:   shiftType?.trim()   || null,
        note:        note?.trim()         || null,
        recordedBy:  req.user!.userId,
      })
      .returning();

    res.status(201).json({
      success: true,
      data:    result[0],
      message: 'Production log created successfully.',
    });
  }
);

// ============================================================
// GET /api/production/logs/employee/:id
// ============================================================
/**
 * جلب سجلات إنتاج موظف بفترة زمنية
 * Query: ?from=YYYY-MM-DD&to=YYYY-MM-DD
 */
export const getEmployeeProductionLogs = asyncHandler(
  async (req: AuthRequest, res: Response) => {
    const employeeId = parseInt(req.params.id, 10);
    if (isNaN(employeeId)) throw new AppError('Invalid employee ID.', 400, 'INVALID_ID');

    const rows = await db
      .select()
      .from(dailyProductionLogs)
      .where(eq(dailyProductionLogs.employeeId, employeeId))
      .orderBy(dailyProductionLogs.productionDate);

    res.json({ success: true, data: rows, total: rows.length });
  }
);
