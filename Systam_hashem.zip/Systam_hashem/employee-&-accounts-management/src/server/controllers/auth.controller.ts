import { Request, Response } from 'express';
import { eq } from 'drizzle-orm';
import bcrypt from 'bcrypt';
import { db } from '../../db/index.ts';
import { users } from '../../db/schema.ts';
import { asyncHandler } from '../middleware/asyncHandler.ts';
import { generateToken } from '../middleware/authenticate.ts';
import { AppError } from '../middleware/errorHandler.ts';

/**
 * POST /api/auth/login
 * تسجيل الدخول وإرجاع JWT Token + بيانات المستخدم الآمنة
 */
export const login = asyncHandler(async (req: Request, res: Response) => {
  const { username, password } = req.body as { username?: string; password?: string };

  if (!username || !password) {
    throw new AppError('Username and password are required.', 400, 'MISSING_CREDENTIALS');
  }

  // البحث عن المستخدم بالـ username
  const result = await db
    .select()
    .from(users)
    .where(eq(users.username, username.trim().toLowerCase()))
    .limit(1);

  const user = result[0];

  if (!user) {
    throw new AppError('Invalid username or password.', 401, 'INVALID_CREDENTIALS');
  }

  if (!user.isActive) {
    throw new AppError('Account is deactivated. Contact admin.', 403, 'ACCOUNT_INACTIVE');
  }

  // التحقق من كلمة المرور
  const isPasswordValid = await bcrypt.compare(password, user.passwordHash);
  if (!isPasswordValid) {
    throw new AppError('Invalid username or password.', 401, 'INVALID_CREDENTIALS');
  }

  // توليد JWT
  const token = generateToken({
    userId:   user.id,
    username: user.username,
    role:     user.role,
  });

  res.json({
    success: true,
    data: {
      token,
      user: {
        id:       user.id,
        fullName: user.fullName,
        username: user.username,
        role:     user.role,
        status:   user.status,
      },
    },
    message: 'Login successful.',
  });
});

/**
 * GET /api/auth/me
 * يُرجع بيانات المستخدم الحالي من الـ Token
 */
export const getMe = asyncHandler(async (req: Request & { user?: any }, res: Response) => {
  const userId = req.user?.userId;

  const result = await db
    .select({
      id:       users.id,
      fullName: users.fullName,
      username: users.username,
      role:     users.role,
      status:   users.status,
      hireDate: users.hireDate,
      phone:    users.phone,
    })
    .from(users)
    .where(eq(users.id, userId))
    .limit(1);

  const user = result[0];
  if (!user) {
    throw new AppError('User not found.', 404, 'USER_NOT_FOUND');
  }

  res.json({ success: true, data: user });
});
