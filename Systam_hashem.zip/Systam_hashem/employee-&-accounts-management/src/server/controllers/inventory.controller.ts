import { Response } from 'express';
import { eq, desc, and, gte, lte } from 'drizzle-orm';
import { db } from '../../db/index.ts';
import { materials, materialMovements } from '../../db/schema.ts';
import { asyncHandler } from '../middleware/asyncHandler.ts';
import { AppError } from '../middleware/errorHandler.ts';
import type { AuthRequest } from '../middleware/authenticate.ts';

// ============================================================
// GET /api/inventory/materials
// ============================================================
/**
 * جلب قائمة كل المواد مع حالة المخزون (isLowStock)
 * الصلاحية: admin, materials_manager, accountant
 */
export const getAllMaterials = asyncHandler(async (req: AuthRequest, res: Response) => {
  const rows = await db
    .select()
    .from(materials)
    .where(eq(materials.isActive, true))
    .orderBy(materials.name);

  const data = rows.map((m) => ({
    ...m,
    isLowStock: parseFloat(m.currentStock) <= parseFloat(m.minThreshold),
  }));

  res.json({ success: true, data });
});

// ============================================================
// GET /api/inventory/materials/:id
// ============================================================
export const getMaterialById = asyncHandler(async (req: AuthRequest, res: Response) => {
  const id = parseInt(req.params.id, 10);
  if (isNaN(id)) throw new AppError('Invalid material ID.', 400, 'INVALID_ID');

  const result = await db.select().from(materials).where(eq(materials.id, id)).limit(1);
  const material = result[0];

  if (!material) throw new AppError('Material not found.', 404, 'NOT_FOUND');

  res.json({
    success: true,
    data: {
      ...material,
      isLowStock: parseFloat(material.currentStock) <= parseFloat(material.minThreshold),
    },
  });
});

// ============================================================
// POST /api/inventory/materials
// ============================================================
/**
 * إضافة مادة جديدة للمخزون
 * الصلاحية: admin فقط
 */
export const createMaterial = asyncHandler(async (req: AuthRequest, res: Response) => {
  const { name, description, minThreshold, unit, initialStock } = req.body as {
    name:          string;
    description?:  string;
    minThreshold?: number;
    unit:          string;
    initialStock?: number;
  };

  if (!name?.trim()) throw new AppError('Material name is required.', 400, 'MISSING_NAME');
  if (!unit)         throw new AppError('Unit is required.', 400, 'MISSING_UNIT');

  const result = await db
    .insert(materials)
    .values({
      name:         name.trim(),
      description:  description?.trim(),
      minThreshold: String(minThreshold ?? 0),
      currentStock: String(initialStock ?? 0),
      unit:         unit as any,
      createdBy:    req.user!.userId,
    })
    .returning();

  res.status(201).json({ success: true, data: result[0], message: 'Material created successfully.' });
});

// ============================================================
// POST /api/inventory/dispense
// ============================================================
/**
 * صرف مادة من المخزون — Drizzle Transaction
 *
 * القواعد المُطبَّقة:
 * 1. user_id مُستخرج من JWT Token فقط (لا من Request Body).
 * 2. التحقق من الرصيد قبل الصرف (current_stock >= quantity).
 * 3. كل شيء داخل Transaction لمنع Race Conditions.
 * 4. يُعيد is_low_stock إذا وصل الرصيد للحد الأدنى.
 */
export const dispenseMaterial = asyncHandler(async (req: AuthRequest, res: Response) => {
  const { materialId, quantity, note } = req.body as {
    materialId: number;
    quantity:   number;
    note?:      string;
  };

  // ─── Validation ───────────────────────────────────────────
  if (!materialId || isNaN(materialId)) {
    throw new AppError('materialId is required and must be a valid number.', 400, 'INVALID_MATERIAL_ID');
  }
  if (!quantity || quantity <= 0) {
    throw new AppError('quantity must be a positive number.', 400, 'INVALID_QUANTITY');
  }

  // user_id من JWT Token — لا يُقبل من الـ Request Body أبداً
  const userId = req.user!.userId;

  // ─── Drizzle Transaction ─────────────────────────────────
  const result = await db.transaction(async (tx) => {
    // 1. قفل وقراءة بيانات المادة
    const matRows = await tx
      .select()
      .from(materials)
      .where(eq(materials.id, materialId))
      .limit(1)
      // Drizzle لا يدعم FOR UPDATE مباشرة — نستخدم sql`` عند الحاجة الحرجة
      // للبيئات ذات التزامن العالي يُستخدم: .for('update')

    const material = matRows[0];

    if (!material) {
      throw new AppError(`Material with ID ${materialId} not found.`, 404, 'MATERIAL_NOT_FOUND');
    }

    if (!material.isActive) {
      throw new AppError('Cannot dispense from an inactive material.', 400, 'MATERIAL_INACTIVE');
    }

    const currentStockNum = parseFloat(material.currentStock);
    const minThresholdNum = parseFloat(material.minThreshold);

    // 2. التحقق من الرصيد المتاح
    if (quantity > currentStockNum) {
      throw new AppError(
        `Insufficient stock. Requested: ${quantity} ${material.unit}, Available: ${currentStockNum} ${material.unit}.`,
        400,
        'INSUFFICIENT_STOCK'
      );
    }

    // 3. حساب الرصيد الجديد
    const newStock = parseFloat((currentStockNum - quantity).toFixed(3));

    // 4. تحديث رصيد المادة
    await tx
      .update(materials)
      .set({
        currentStock: String(newStock),
        updatedAt:    new Date(),
      })
      .where(eq(materials.id, materialId));

    // 5. تسجيل حركة الصرف مع user_id + stock_after
    const movementRows = await tx
      .insert(materialMovements)
      .values({
        materialId,
        type:       'OUT',
        quantity:   String(quantity),
        stockAfter: String(newStock),
        userId,
        note:       note?.trim() || null,
      })
      .returning();

    const movement   = movementRows[0];
    const isLowStock = newStock <= minThresholdNum;

    return { movement, isLowStock, newStock, material };
  });

  // ─── Response ────────────────────────────────────────────
  res.json({
    success: true,
    data: {
      movement:   result.movement,
      isLowStock: result.isLowStock,
      stockAfter: result.newStock,
      ...(result.isLowStock && {
        warning: `⚠️ Low stock alert: ${result.material.name} is at or below minimum threshold (${result.material.minThreshold} ${result.material.unit}).`,
      }),
    },
    message: `Successfully dispensed ${quantity} ${result.material.unit} of "${result.material.name}".`,
  });
});

// ============================================================
// POST /api/inventory/receive
// ============================================================
/**
 * توريد مادة للمخزون
 * الصلاحية: admin, materials_manager
 */
export const receiveMaterial = asyncHandler(async (req: AuthRequest, res: Response) => {
  const { materialId, quantity, note } = req.body as {
    materialId: number;
    quantity:   number;
    note?:      string;
  };

  if (!materialId || isNaN(materialId)) {
    throw new AppError('materialId is required.', 400, 'INVALID_MATERIAL_ID');
  }
  if (!quantity || quantity <= 0) {
    throw new AppError('quantity must be a positive number.', 400, 'INVALID_QUANTITY');
  }

  const userId = req.user!.userId;

  const result = await db.transaction(async (tx) => {
    const matRows = await tx.select().from(materials).where(eq(materials.id, materialId)).limit(1);
    const material = matRows[0];

    if (!material) throw new AppError(`Material ${materialId} not found.`, 404, 'MATERIAL_NOT_FOUND');

    const newStock = parseFloat((parseFloat(material.currentStock) + quantity).toFixed(3));

    await tx
      .update(materials)
      .set({ currentStock: String(newStock), updatedAt: new Date() })
      .where(eq(materials.id, materialId));

    const movementRows = await tx
      .insert(materialMovements)
      .values({
        materialId,
        type:       'IN',
        quantity:   String(quantity),
        stockAfter: String(newStock),
        userId,
        note:       note?.trim() || null,
      })
      .returning();

    return { movement: movementRows[0], newStock, material };
  });

  res.json({
    success: true,
    data: {
      movement:   result.movement,
      stockAfter: result.newStock,
    },
    message: `Successfully received ${quantity} ${result.material.unit} of "${result.material.name}".`,
  });
});

// ============================================================
// GET /api/inventory/movements
// ============================================================
/**
 * سجل حركات المخزون (Audit Trail) — للمدير فقط
 * فلاتر اختيارية: ?materialId=&from=&to=&type=IN|OUT
 */
export const getMovements = asyncHandler(async (req: AuthRequest, res: Response) => {
  const { materialId, from, to, type } = req.query as {
    materialId?: string;
    from?:       string;
    to?:         string;
    type?:       'IN' | 'OUT';
  };

  // بناء الشروط ديناميكياً
  const conditions = [];
  if (materialId) conditions.push(eq(materialMovements.materialId, parseInt(materialId, 10)));
  if (type)       conditions.push(eq(materialMovements.type, type));
  if (from)       conditions.push(gte(materialMovements.createdAt, new Date(from)));
  if (to)         conditions.push(lte(materialMovements.createdAt, new Date(to)));

  const rows = await db
    .select({
      id:           materialMovements.id,
      type:         materialMovements.type,
      quantity:     materialMovements.quantity,
      stockAfter:   materialMovements.stockAfter,
      note:         materialMovements.note,
      createdAt:    materialMovements.createdAt,
      materialId:   materialMovements.materialId,
      materialName: materials.name,
      materialUnit: materials.unit,
      userId:       materialMovements.userId,
    })
    .from(materialMovements)
    .leftJoin(materials, eq(materialMovements.materialId, materials.id))
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(desc(materialMovements.createdAt))
    .limit(500);

  res.json({ success: true, data: rows, total: rows.length });
});
