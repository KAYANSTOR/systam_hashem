import { Request, Response } from 'express';
import { EmployeeModel } from '../models/employee.model.ts';

export class EmployeeController {
  static async getAllEmployees(req: Request, res: Response) {
    try {
      const employees = await EmployeeModel.getAll();
      res.json(employees);
    } catch (error: any) {
      console.error('Error in EmployeeController.getAllEmployees:', error);
      res.status(500).json({ error: error.message || 'Internal server error' });
    }
  }

  static async getEmployeeById(req: Request, res: Response) {
    try {
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        return res.status(400).json({ error: 'Invalid employee ID' });
      }

      const employee = await EmployeeModel.getById(id);
      if (!employee) {
        return res.status(404).json({ error: 'Employee not found' });
      }

      res.json(employee);
    } catch (error: any) {
      console.error('Error in EmployeeController.getEmployeeById:', error);
      res.status(500).json({ error: error.message || 'Internal server error' });
    }
  }

  static async createEmployee(req: Request, res: Response) {
    try {
      const { name, salary, fixedDeparture, hireDate } = req.body;
      
      if (!name || !salary || !hireDate) {
        return res.status(400).json({ error: 'Missing required fields: name, salary, and hireDate are required.' });
      }

      const newEmployee = await EmployeeModel.create({
        name,
        salary,
        fixedDeparture,
        hireDate,
      });

      res.status(201).json(newEmployee);
    } catch (error: any) {
      console.error('Error in EmployeeController.createEmployee:', error);
      res.status(500).json({ error: error.message || 'Internal server error' });
    }
  }

  static async updateEmployee(req: Request, res: Response) {
    try {
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        return res.status(400).json({ error: 'Invalid employee ID' });
      }

      const { name, salary, fixedDeparture, hireDate } = req.body;
      const updatedEmployee = await EmployeeModel.update(id, {
        name,
        salary,
        fixedDeparture,
        hireDate,
      });

      if (!updatedEmployee) {
        return res.status(404).json({ error: 'Employee not found' });
      }

      res.json(updatedEmployee);
    } catch (error: any) {
      console.error('Error in EmployeeController.updateEmployee:', error);
      res.status(500).json({ error: error.message || 'Internal server error' });
    }
  }

  static async deleteEmployee(req: Request, res: Response) {
    try {
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        return res.status(400).json({ error: 'Invalid employee ID' });
      }

      const success = await EmployeeModel.delete(id);
      if (!success) {
        return res.status(404).json({ error: 'Employee not found' });
      }

      res.json({ message: 'Employee deleted successfully' });
    } catch (error: any) {
      console.error('Error in EmployeeController.deleteEmployee:', error);
      res.status(500).json({ error: error.message || 'Internal server error' });
    }
  }
}
