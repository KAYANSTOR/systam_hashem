import { eq, and, gte, lte } from 'drizzle-orm';
import { db } from '../../db/index.ts';
import { archiveEntries } from '../../db/schema.ts';

export interface CreateArchiveEntryInput {
  employeeId: number;
  entryDate: string;
  dayOfWeek: string;
  attendance: string;
  delayMinutes?: number;
  departureAmount?: string;
  overtimeAmount?: string;
  advanceAmount?: string;
  note?: string;
}

export class ArchiveModel {
  static async getByEmployeeId(employeeId: number, startDate?: string, endDate?: string) {
    try {
      let query = db.select().from(archiveEntries).where(eq(archiveEntries.employeeId, employeeId));
      
      if (startDate && endDate) {
        query = db.select()
          .from(archiveEntries)
          .where(
            and(
              eq(archiveEntries.employeeId, employeeId),
              gte(archiveEntries.entryDate, startDate),
              lte(archiveEntries.entryDate, endDate)
            )
          );
      }
      
      return await query.orderBy(archiveEntries.entryDate);
    } catch (error) {
      console.error(`Database query failed in ArchiveModel.getByEmployeeId for employee ${employeeId}:`, error);
      throw new Error('Database query failed. Please try again later.', { cause: error });
    }
  }

  static async getByDate(date: string) {
    try {
      return await db.select()
        .from(archiveEntries)
        .where(eq(archiveEntries.entryDate, date));
    } catch (error) {
      console.error(`Database query failed in ArchiveModel.getByDate for date ${date}:`, error);
      throw new Error('Database query failed. Please try again later.', { cause: error });
    }
  }

  static async createBatch(entries: CreateArchiveEntryInput[]) {
    try {
      const results = [];
      // We can insert inside a transaction or insert in a single batch
      if (entries.length === 0) return [];
      
      return await db.insert(archiveEntries)
        .values(entries.map(e => ({
          employeeId: e.employeeId,
          entryDate: e.entryDate,
          dayOfWeek: e.dayOfWeek,
          attendance: e.attendance,
          delayMinutes: e.delayMinutes ?? 0,
          departureAmount: e.departureAmount ?? '0.00',
          overtimeAmount: e.overtimeAmount ?? '0.00',
          advanceAmount: e.advanceAmount ?? '0.00',
          note: e.note ?? null,
        })))
        .returning();
    } catch (error) {
      console.error('Database batch insertion failed in ArchiveModel.createBatch:', error);
      throw new Error('Database query failed. Please try again later.', { cause: error });
    }
  }
}
