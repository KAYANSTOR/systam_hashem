import { eq } from 'drizzle-orm';
import { db } from '../../db/index.ts';
import { employees } from '../../db/schema.ts';

export interface CreateEmployeeInput {
  name: string;
  salary: string; // numeric in DB is returned/passed as string to preserve precision
  fixedDeparture?: string;
  hireDate: string;
}

export interface UpdateEmployeeInput {
  name?: string;
  salary?: string;
  fixedDeparture?: string;
  hireDate?: string;
}

export class EmployeeModel {
  static async getAll() {
    try {
      return await db.select().from(employees).orderBy(employees.name);
    } catch (error) {
      console.error('Database query failed in EmployeeModel.getAll:', error);
      throw new Error('Database query failed. Please try again later.', { cause: error });
    }
  }

  static async getById(id: number) {
    try {
      const results = await db.select().from(employees).where(eq(employees.id, id));
      return results[0] || null;
    } catch (error) {
      console.error(`Database query failed in EmployeeModel.getById for ID ${id}:`, error);
      throw new Error('Database query failed. Please try again later.', { cause: error });
    }
  }

  static async create(data: CreateEmployeeInput) {
    try {
      const results = await db.insert(employees)
        .values({
          name: data.name,
          salary: data.salary,
          fixedDeparture: data.fixedDeparture || '0.00',
          hireDate: data.hireDate,
        })
        .returning();
      return results[0];
    } catch (error) {
      console.error('Database insertion failed in EmployeeModel.create:', error);
      throw new Error('Database query failed. Please try again later.', { cause: error });
    }
  }

  static async update(id: number, data: UpdateEmployeeInput) {
    try {
      const results = await db.update(employees)
        .set({
          ...data,
          updatedAt: new Date(),
        })
        .where(eq(employees.id, id))
        .returning();
      return results[0] || null;
    } catch (error) {
      console.error(`Database update failed in EmployeeModel.update for ID ${id}:`, error);
      throw new Error('Database query failed. Please try again later.', { cause: error });
    }
  }

  static async delete(id: number) {
    try {
      const results = await db.delete(employees).where(eq(employees.id, id)).returning();
      return results.length > 0;
    } catch (error) {
      console.error(`Database deletion failed in EmployeeModel.delete for ID ${id}:`, error);
      throw new Error('Database query failed. Please try again later.', { cause: error });
    }
  }
}
