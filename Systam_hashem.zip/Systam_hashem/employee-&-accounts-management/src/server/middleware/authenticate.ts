import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import type { AuthPayload, UserRole } from '../../types.ts';

/** تمديد Request لإضافة بيانات المستخدم المصادق */
export interface AuthRequest extends Request {
  user?: AuthPayload;
}

const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  throw new Error('[authenticate] JWT_SECRET is not defined in environment variables.');
}

/**
 * authenticate — Middleware للتحقق من JWT Token
 *
 * يستخرج التوكن من Header: Authorization: Bearer <token>
 * ويضع بيانات المستخدم في req.user
 *
 * البيانات المُستخرجة: { userId, username, role }
 */
export const authenticate = (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): void => {
  const authHeader = req.headers.authorization;

  if (!authHeader?.startsWith('Bearer ')) {
    res.status(401).json({
      success: false,
      error: 'Unauthorized: Missing or malformed Authorization header.',
      code: 'MISSING_TOKEN',
    });
    return;
  }

  const token = authHeader.split('Bearer ')[1];

  try {
    const decoded = jwt.verify(token, JWT_SECRET!) as AuthPayload;
    req.user = decoded;
    next();
  } catch (error) {
    if (error instanceof jwt.TokenExpiredError) {
      res.status(401).json({
        success: false,
        error: 'Unauthorized: Token has expired.',
        code: 'TOKEN_EXPIRED',
      });
      return;
    }
    res.status(401).json({
      success: false,
      error: 'Unauthorized: Invalid token.',
      code: 'INVALID_TOKEN',
    });
  }
};

/**
 * generateToken — توليد JWT Token عند تسجيل الدخول
 */
export const generateToken = (payload: AuthPayload): string => {
  return jwt.sign(payload, JWT_SECRET!, { expiresIn: '24h' });
};
