import { Request, Response, NextFunction, RequestHandler } from 'express';

/**
 * asyncHandler — Wrapper لدوال Express الـ async
 *
 * يلتقط الـ Promises المرفوضة ويمررها لـ Express error handler
 * بدلاً من: try/catch في كل controller
 *
 * @example
 * router.get('/items', asyncHandler(async (req, res) => {
 *   const data = await someAsyncOperation();
 *   res.json(data);
 * }));
 */
export const asyncHandler = (
  fn: (req: Request, res: Response, next: NextFunction) => Promise<unknown>
): RequestHandler => {
  return (req: Request, res: Response, next: NextFunction) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
};
