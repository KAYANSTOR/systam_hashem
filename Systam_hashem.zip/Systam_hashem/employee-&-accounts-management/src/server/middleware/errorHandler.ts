import { Request, Response, NextFunction } from 'express';

/**
 * globalErrorHandler — معالج الأخطاء العام لـ Express
 *
 * يجب تسجيله آخر middleware في app.ts
 * يلتقط كل الأخطاء من asyncHandler والـ throw العادية
 */
export const globalErrorHandler = (
  err: Error & { statusCode?: number; code?: string },
  req: Request,
  res: Response,
  _next: NextFunction
): void => {
  console.error(`[Error] ${req.method} ${req.path}:`, err.message);
  if (process.env.NODE_ENV !== 'production') {
    console.error(err.stack);
  }

  const statusCode = err.statusCode || 500;

  res.status(statusCode).json({
    success: false,
    error:   err.message || 'Internal Server Error',
    code:    err.code    || 'SERVER_ERROR',
    ...(process.env.NODE_ENV !== 'production' && { stack: err.stack }),
  });
};

/**
 * notFoundHandler — معالج المسارات غير الموجودة (404)
 */
export const notFoundHandler = (req: Request, res: Response): void => {
  res.status(404).json({
    success: false,
    error: `Route not found: ${req.method} ${req.path}`,
    code: 'NOT_FOUND',
  });
};

/**
 * AppError — خطأ مخصص مع statusCode و code
 * @example throw new AppError('Insufficient stock', 400, 'INSUFFICIENT_STOCK');
 */
export class AppError extends Error {
  constructor(
    message: string,
    public statusCode: number = 500,
    public code: string = 'APP_ERROR'
  ) {
    super(message);
    this.name = 'AppError';
  }
}
