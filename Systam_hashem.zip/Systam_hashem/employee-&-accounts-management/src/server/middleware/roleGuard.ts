import { Response, NextFunction } from 'express';
import type { AuthRequest } from './authenticate.ts';
import type { UserRole } from '../../types.ts';
import { ROLE_PERMISSIONS } from '../../types.ts';

/**
 * roleGuard — Middleware لحماية المسارات بناءً على الدور
 *
 * ─── القواعد الصارمة ─────────────────────────────────────
 * 1. materials_manager يُمنع تماماً من أي مسار يحتوي على:
 *    /finance  /sales  /customers  /reports/finance
 * 2. الحماية مزدوجة: فحص الدور + فحص المسار (Defense in Depth)
 * ─────────────────────────────────────────────────────────
 *
 * @example
 * // يسمح فقط لـ admin و accountant
 * router.get('/finance/summary', roleGuard(['admin', 'accountant']), handler);
 *
 * @example
 * // يسمح لأي مستخدم مصادق عليه
 * router.get('/materials', roleGuard(['admin', 'materials_manager', 'accountant']), handler);
 */
export const roleGuard = (allowedRoles: UserRole[]) => {
  return (req: AuthRequest, res: Response, next: NextFunction): void => {
    const user = req.user;

    // 1. التأكد من وجود بيانات المستخدم (authenticate يجب أن يُنفَّذ قبله)
    if (!user) {
      res.status(401).json({
        success: false,
        error: 'Unauthorized: No authenticated user found.',
        code: 'NO_USER',
      });
      return;
    }

    // 2. قاعدة صارمة: materials_manager ممنوع من المسارات المالية/المبيعات
    if (user.role === 'materials_manager') {
      const blockedPaths = ['/finance', '/sales', '/customers', '/reports/finance', '/payroll'];
      const currentPath  = req.path.toLowerCase();

      const isBlocked = blockedPaths.some((blocked) => currentPath.includes(blocked));
      if (isBlocked) {
        res.status(403).json({
          success: false,
          error: 'Forbidden: Materials manager does not have access to financial or sales routes.',
          code: 'ROLE_FORBIDDEN_PATH',
        });
        return;
      }
    }

    // 3. التحقق من الدور المسموح به
    if (!allowedRoles.includes(user.role)) {
      res.status(403).json({
        success: false,
        error: `Forbidden: Role '${user.role}' is not allowed to access this resource.`,
        code: 'INSUFFICIENT_ROLE',
        required: allowedRoles,
      });
      return;
    }

    next();
  };
};

/**
 * blockFinancialPaths — Middleware مستقل يُطبَّق على المسارات المالية
 *
 * يُستخدم كـ Global Guard على Router المالي بالكامل:
 * @example
 * financeRouter.use(blockFinancialPaths);
 */
export const blockFinancialPaths = (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): void => {
  const user = req.user;

  if (!user) {
    res.status(401).json({ success: false, error: 'Unauthorized', code: 'NO_USER' });
    return;
  }

  const financiallyBlocked: UserRole[] = ['materials_manager', 'production_supervisor', 'viewer'];

  if (financiallyBlocked.includes(user.role)) {
    res.status(403).json({
      success: false,
      error: `Forbidden: Role '${user.role}' cannot access financial data.`,
      code: 'FINANCIAL_ACCESS_DENIED',
    });
    return;
  }

  next();
};

/**
 * requirePermission — Guard بناءً على صلاحية محددة من ROLE_PERMISSIONS
 *
 * @example
 * router.post('/materials/dispense', requirePermission('canManageMaterials'), handler);
 */
export const requirePermission = (
  permission: keyof typeof ROLE_PERMISSIONS[UserRole]
) => {
  return (req: AuthRequest, res: Response, next: NextFunction): void => {
    const user = req.user;

    if (!user) {
      res.status(401).json({ success: false, error: 'Unauthorized', code: 'NO_USER' });
      return;
    }

    const userPermissions = ROLE_PERMISSIONS[user.role];
    if (!userPermissions || !userPermissions[permission]) {
      res.status(403).json({
        success: false,
        error: `Forbidden: Missing permission '${permission}'.`,
        code: 'MISSING_PERMISSION',
        role: user.role,
      });
      return;
    }

    next();
  };
};
