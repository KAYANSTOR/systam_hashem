import { Router } from 'express';
import {
  getDailyPerformanceReport,
  createProductionLog,
  getEmployeeProductionLogs,
} from '../controllers/production.controller.ts';
import { authenticate }  from '../middleware/authenticate.ts';
import { roleGuard }     from '../middleware/roleGuard.ts';

const router = Router();

router.use(authenticate);

/**
 * GET /api/production/report/daily
 * Query: ?employeeId=<id>&date=<YYYY-MM-DD>
 * يُرجع: حالة الحضور + سجلات الإنتاج (بدون بيانات مالية)
 * الصلاحية: admin, production_supervisor, accountant (للاطلاع)
 */
router.get(
  '/report/daily',
  roleGuard(['admin', 'production_supervisor', 'accountant']),
  getDailyPerformanceReport
);

/**
 * POST /api/production/logs  — تسجيل إنتاج يومي
 * الصلاحية: admin, production_supervisor
 */
router.post(
  '/logs',
  roleGuard(['admin', 'production_supervisor']),
  createProductionLog
);

/**
 * GET /api/production/logs/employee/:id — سجلات إنتاج موظف
 * الصلاحية: admin, production_supervisor
 */
router.get(
  '/logs/employee/:id',
  roleGuard(['admin', 'production_supervisor', 'accountant']),
  getEmployeeProductionLogs
);

export default router;
