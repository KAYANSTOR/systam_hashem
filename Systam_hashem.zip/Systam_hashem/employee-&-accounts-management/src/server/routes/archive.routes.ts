import { Router } from 'express';
import { ArchiveController } from '../controllers/archive.controller.ts';

const router = Router();

router.get('/initial-data', ArchiveController.getInitialData);
router.post('/archive', ArchiveController.archiveEntries);
router.get('/statement', ArchiveController.getStatement);

export default router;
