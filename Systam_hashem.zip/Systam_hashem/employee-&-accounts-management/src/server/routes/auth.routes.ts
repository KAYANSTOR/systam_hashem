import { Router } from 'express';
import { login, getMe } from '../controllers/auth.controller.ts';
import { authenticate } from '../middleware/authenticate.ts';

const router = Router();

// POST /api/auth/login  — عام (بدون authenticate)
router.post('/login', login);

// GET /api/auth/me — يحتاج token صالح
router.get('/me', authenticate, getMe);

export default router;
