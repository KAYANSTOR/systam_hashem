import { Router } from 'express';
import {
  getAllMaterials,
  getMaterialById,
  createMaterial,
  dispenseMaterial,
  receiveMaterial,
  getMovements,
} from '../controllers/inventory.controller.ts';
import { authenticate }        from '../middleware/authenticate.ts';
import { roleGuard }           from '../middleware/roleGuard.ts';

const router = Router();

// جميع مسارات المخزون تتطلب مصادقة
router.use(authenticate);

/**
 * GET /api/inventory/materials
 * الصلاحية: admin, materials_manager, accountant
 */
router.get(
  '/materials',
  roleGuard(['admin', 'materials_manager', 'accountant']),
  getAllMaterials
);

/**
 * GET /api/inventory/materials/:id
 */
router.get(
  '/materials/:id',
  roleGuard(['admin', 'materials_manager', 'accountant']),
  getMaterialById
);

/**
 * POST /api/inventory/materials  — إضافة مادة جديدة
 * الصلاحية: admin فقط
 */
router.post(
  '/materials',
  roleGuard(['admin']),
  createMaterial
);

/**
 * POST /api/inventory/dispense — صرف مادة (Transaction)
 * الصلاحية: admin, materials_manager
 */
router.post(
  '/dispense',
  roleGuard(['admin', 'materials_manager']),
  dispenseMaterial
);

/**
 * POST /api/inventory/receive — توريد مادة (Transaction)
 * الصلاحية: admin, materials_manager
 */
router.post(
  '/receive',
  roleGuard(['admin', 'materials_manager']),
  receiveMaterial
);

/**
 * GET /api/inventory/movements — سجل الحركات (Audit Trail)
 * الصلاحية: admin فقط
 */
router.get(
  '/movements',
  roleGuard(['admin']),
  getMovements
);

export default router;
