/**
 * ============================================================
 *  EMBROIDERY ERP — Unified Database Schema (Drizzle ORM)
 * ============================================================
 *  النظام الموحّد: إدارة الموظفين + المخزون + الإنتاج التشغيلي
 *
 *  القواعد الصارمة المُطبَّقة في هذا الـ Schema:
 *  1. materials_manager لا يملك أي صلاحية على الجداول المالية.
 *  2. daily_production_logs لا تحتوي على أي حقول مالية.
 *  3. كل حركة مخزون مرتبطة بـ user_id المنفّذ (Audit Trail).
 *  4. Drizzle Transactions تُستخدم عند الصرف لمنع Race Conditions.
 * ============================================================
 */

import { relations, sql } from 'drizzle-orm';
import {
  boolean,
  date,
  decimal,
  index,
  integer,
  pgEnum,
  pgTable,
  serial,
  text,
  timestamp,
  varchar,
} from 'drizzle-orm/pg-core';

// ============================================================
// ENUMS — القيم الثابتة لحقول الاختيار
// ============================================================

/**
 * أدوار المستخدمين في النظام
 * - admin: كامل الصلاحيات
 * - accountant: حسابات + مبيعات + عملاء
 * - materials_manager: مخزن المواد فقط (يُمنع /finance و /sales)
 * - production_supervisor: تسجيل الإنتاج التشغيلي فقط
 * - viewer: قراءة فقط للتقارير
 */
export const userRoleEnum = pgEnum('user_role', [
  'admin',
  'accountant',
  'materials_manager',
  'production_supervisor',
  'viewer',
]);

/**
 * حالة الحضور اليومي
 */
export const attendanceStatusEnum = pgEnum('attendance_status', [
  'present',    // حاضر
  'absent',     // غائب
  'half_day',   // نصف يوم
  'holiday',    // إجازة
  'on_leave',   // إجازة رسمية مدفوعة
]);

/**
 * نوع حركة المخزون
 */
export const movementTypeEnum = pgEnum('movement_type', [
  'IN',   // توريد / دخول
  'OUT',  // صرف / خروج
]);

/**
 * وحدة قياس المواد
 */
export const materialUnitEnum = pgEnum('material_unit', [
  'kg',     // كيلوغرام
  'gram',   // غرام
  'piece',  // حبة / قطعة
  'meter',  // متر
  'spool',  // بكرة خيط
  'box',    // كرتون / علبة
  'liter',  // لتر
]);

/**
 * حالة العامل
 */
export const employeeStatusEnum = pgEnum('employee_status', [
  'active',      // نشط
  'inactive',    // متوقف مؤقتاً
  'terminated',  // مُنهي الخدمة
]);

// ============================================================
// TABLE 1: users
// ============================================================
/**
 * جدول المستخدمين/الموظفين الموحّد
 *
 * يجمع بين:
 * - بيانات الموظف (الاسم، الراتب، تاريخ التعيين)
 * - بيانات الحساب (username، password، الدور)
 *
 * ملاحظة: salary و fixed_departure حقول مالية حساسة،
 * materials_manager لا يمكنه الوصول لهذه البيانات عبر الـ API.
 */
export const users = pgTable(
  'users',
  {
    id: serial('id').primaryKey(),

    // ─── بيانات الموظف ───────────────────────────────────────
    fullName:      varchar('full_name', { length: 200 }).notNull(),
    phone:         varchar('phone', { length: 30 }),
    hireDate:      date('hire_date').notNull(),
    status:        employeeStatusEnum('status').default('active').notNull(),

    // ─── بيانات الراتب (حساسة — للمدير والمحاسب فقط) ─────────
    monthlySalary:   decimal('monthly_salary', { precision: 10, scale: 2 }).notNull().default('0.00'),
    fixedDeparture:  decimal('fixed_departure', { precision: 10, scale: 2 }).notNull().default('0.00'),

    // ─── بيانات الحساب/تسجيل الدخول ──────────────────────────
    username:     varchar('username', { length: 80 }).notNull().unique(),
    passwordHash: text('password_hash').notNull(),
    role:         userRoleEnum('role').notNull().default('viewer'),
    isActive:     boolean('is_active').notNull().default(true),

    // ─── Timestamps ───────────────────────────────────────────
    createdAt: timestamp('created_at').notNull().defaultNow(),
    updatedAt: timestamp('updated_at').notNull().defaultNow(),
  },
  (table) => ({
    usernameIdx: index('idx_users_username').on(table.username),
    roleIdx:     index('idx_users_role').on(table.role),
    statusIdx:   index('idx_users_status').on(table.status),
  })
);

// ============================================================
// TABLE 2: archive_entries
// ============================================================
/**
 * سجلات الحضور والمعاملات المالية اليومية لكل موظف
 *
 * تُسجَّل يومياً وتشمل:
 * - حالة الحضور (present/absent/half_day/...)
 * - دقائق التأخير (لحساب الخصم)
 * - المبالغ المالية: استقطاع / إضافي / سلف
 *
 * حساب الراتب الشهري:
 *   daily_wage    = monthly_salary / 30
 *   hourly_wage   = daily_wage / 12
 *   delay_deduct  = (total_delay_min / 60) × hourly_wage
 *   net_salary    = (daily_wage × days_present)
 *                   + total_overtime
 *                   - total_departure
 *                   - total_advances
 *                   - delay_deduct
 */
export const archiveEntries = pgTable(
  'archive_entries',
  {
    id:         serial('id').primaryKey(),
    employeeId: integer('employee_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),

    // ─── التاريخ ───────────────────────────────────────────────
    entryDate:  date('entry_date').notNull(),
    dayOfWeek:  varchar('day_of_week', { length: 20 }).notNull(),

    // ─── الحضور ───────────────────────────────────────────────
    attendance:   attendanceStatusEnum('attendance').notNull().default('present'),
    delayMinutes: integer('delay_minutes').notNull().default(0),

    // ─── المعاملات المالية اليومية ─────────────────────────────
    departureAmount: decimal('departure_amount', { precision: 10, scale: 2 }).notNull().default('0.00'),
    overtimeAmount:  decimal('overtime_amount',  { precision: 10, scale: 2 }).notNull().default('0.00'),
    advanceAmount:   decimal('advance_amount',   { precision: 10, scale: 2 }).notNull().default('0.00'),

    // ─── Metadata ─────────────────────────────────────────────
    note:        text('note'),
    recordedBy:  integer('recorded_by').references(() => users.id, { onDelete: 'set null' }),
    createdAt:   timestamp('created_at').notNull().defaultNow(),
    updatedAt:   timestamp('updated_at').notNull().defaultNow(),
  },
  (table) => ({
    employeeDateIdx:  index('idx_archive_employee_date').on(table.employeeId, table.entryDate),
    entryDateIdx:     index('idx_archive_entry_date').on(table.entryDate),
    attendanceIdx:    index('idx_archive_attendance').on(table.attendance),
  })
);

// ============================================================
// TABLE 3: materials
// ============================================================
/**
 * جدول مواد المخزون
 *
 * يحتوي على الرصيد الحالي (current_stock) والحد الأدنى (min_threshold).
 * عند وصول current_stock <= min_threshold يُطلق تنبيه LOW_STOCK.
 *
 * صلاحيات الوصول:
 *   - admin:             قراءة + كتابة + حذف
 *   - materials_manager: قراءة + تسجيل حركات
 *   - غيرهم:            ممنوع
 */
export const materials = pgTable(
  'materials',
  {
    id:           serial('id').primaryKey(),
    name:         varchar('name', { length: 200 }).notNull(),
    description:  text('description'),

    // ─── المخزون ──────────────────────────────────────────────
    currentStock: decimal('current_stock', { precision: 12, scale: 3 }).notNull().default('0.000'),
    minThreshold: decimal('min_threshold', { precision: 12, scale: 3 }).notNull().default('0.000'),
    unit:         materialUnitEnum('unit').notNull(),

    // ─── Metadata ─────────────────────────────────────────────
    isActive:  boolean('is_active').notNull().default(true),
    createdBy: integer('created_by').references(() => users.id, { onDelete: 'set null' }),
    createdAt: timestamp('created_at').notNull().defaultNow(),
    updatedAt: timestamp('updated_at').notNull().defaultNow(),
  },
  (table) => ({
    nameIdx:     index('idx_materials_name').on(table.name),
    isActiveIdx: index('idx_materials_active').on(table.isActive),
  })
);

// ============================================================
// TABLE 4: material_movements
// ============================================================
/**
 * جدول حركات المخزون — Audit Trail كامل
 *
 * قواعد صارمة:
 * 1. كل عملية OUT تتحقق أولاً أن current_stock >= quantity.
 * 2. user_id مُستخرج من JWT Token (لا يُقبل من الـ Request Body).
 * 3. تُنفَّذ عمليات OUT داخل Drizzle Transaction لمنع Race Conditions.
 * 4. لا يمكن حذف سجل حركة (append-only).
 */
export const materialMovements = pgTable(
  'material_movements',
  {
    id:         serial('id').primaryKey(),
    materialId: integer('material_id')
      .notNull()
      .references(() => materials.id, { onDelete: 'restrict' }),

    // ─── تفاصيل الحركة ─────────────────────────────────────────
    type:     movementTypeEnum('type').notNull(),       // IN أو OUT
    quantity: decimal('quantity', { precision: 12, scale: 3 }).notNull(),

    // ─── الرصيد بعد العملية (Snapshot) ───────────────────────
    stockAfter: decimal('stock_after', { precision: 12, scale: 3 }).notNull(),

    // ─── من نفّذ العملية (من JWT Token — Audit) ───────────────
    userId: integer('user_id')
      .notNull()
      .references(() => users.id, { onDelete: 'restrict' }),

    // ─── Metadata ─────────────────────────────────────────────
    note:      text('note'),
    createdAt: timestamp('created_at').notNull().defaultNow(),
  },
  (table) => ({
    materialIdx:    index('idx_movements_material').on(table.materialId),
    userIdx:        index('idx_movements_user').on(table.userId),
    typeIdx:        index('idx_movements_type').on(table.type),
    createdAtIdx:   index('idx_movements_created_at').on(table.createdAt),
  })
);

// ============================================================
// TABLE 5: daily_production_logs
// ============================================================
/**
 * سجلات الإنتاج التشغيلية (بدون أي حقول مالية)
 *
 * الهدف: تتبع "الأداء التشغيلي" فقط.
 *   - كم قطعة طرّزها العامل في يوم معين.
 *   - ما اسم المنتج/القطعة.
 *
 * قاعدة صارمة: لا توجد هنا أي حقول مالية (لا bonus، لا commission،
 * لا wage). الربط بالراتب ممنوع من هذا الجدول تماماً.
 *
 * الاستخدام: تُجمَّع مع archive_entries في تقرير الأداء اليومي
 * لعرض (الحضور + القطع المنجزة) في بطاقة واحدة.
 */
export const dailyProductionLogs = pgTable(
  'daily_production_logs',
  {
    id:         serial('id').primaryKey(),
    employeeId: integer('employee_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),

    // ─── تفاصيل الإنتاج (تشغيلي بحت) ─────────────────────────
    productionDate: date('production_date').notNull(),
    itemName:       varchar('item_name', { length: 200 }).notNull(),
    quantity:       integer('quantity').notNull().default(0),

    // ─── بيانات المكينة (اختيارية) ────────────────────────────
    machineCode: varchar('machine_code', { length: 50 }),
    shiftType:   varchar('shift_type',   { length: 20 }), // morning / evening / night

    // ─── Metadata ─────────────────────────────────────────────
    note:       text('note'),
    recordedBy: integer('recorded_by').references(() => users.id, { onDelete: 'set null' }),
    createdAt:  timestamp('created_at').notNull().defaultNow(),
  },
  (table) => ({
    employeeDateIdx:   index('idx_prod_employee_date').on(table.employeeId, table.productionDate),
    productionDateIdx: index('idx_prod_date').on(table.productionDate),
    machineCodeIdx:    index('idx_prod_machine').on(table.machineCode),
  })
);

// ============================================================
// RELATIONS — العلاقات بين الجداول
// ============================================================

export const usersRelations = relations(users, ({ many }) => ({
  // موظف → سجلات حضوره
  archiveEntries: many(archiveEntries, { relationName: 'employee_archive' }),

  // موظف → سجلات إنتاجه
  productionLogs: many(dailyProductionLogs, { relationName: 'employee_production' }),

  // مستخدم → الحركات التي نفّذها في المخزون
  materialMovements: many(materialMovements, { relationName: 'user_movements' }),

  // مستخدم → المواد التي أضافها
  createdMaterials: many(materials, { relationName: 'creator_materials' }),
}));

export const archiveEntriesRelations = relations(archiveEntries, ({ one }) => ({
  employee:   one(users, { fields: [archiveEntries.employeeId], references: [users.id], relationName: 'employee_archive' }),
  recordedBy: one(users, { fields: [archiveEntries.recordedBy], references: [users.id] }),
}));

export const materialsRelations = relations(materials, ({ one, many }) => ({
  createdBy: one(users, { fields: [materials.createdBy], references: [users.id], relationName: 'creator_materials' }),
  movements: many(materialMovements, { relationName: 'material_movements' }),
}));

export const materialMovementsRelations = relations(materialMovements, ({ one }) => ({
  material: one(materials, { fields: [materialMovements.materialId], references: [materials.id], relationName: 'material_movements' }),
  user:     one(users,     { fields: [materialMovements.userId],     references: [users.id],     relationName: 'user_movements' }),
}));

export const dailyProductionLogsRelations = relations(dailyProductionLogs, ({ one }) => ({
  employee:   one(users, { fields: [dailyProductionLogs.employeeId], references: [users.id], relationName: 'employee_production' }),
  recordedBy: one(users, { fields: [dailyProductionLogs.recordedBy], references: [users.id] }),
}));

// ============================================================
// TYPE EXPORTS — أنواع TypeScript المُستخرجة تلقائياً
// ============================================================

// Users / Employees
export type User              = typeof users.$inferSelect;
export type NewUser           = typeof users.$inferInsert;
export type UserRole          = typeof userRoleEnum.enumValues[number];
export type EmployeeStatus    = typeof employeeStatusEnum.enumValues[number];

// Archive Entries
export type ArchiveEntry      = typeof archiveEntries.$inferSelect;
export type NewArchiveEntry   = typeof archiveEntries.$inferInsert;
export type AttendanceStatus  = typeof attendanceStatusEnum.enumValues[number];

// Materials
export type Material          = typeof materials.$inferSelect;
export type NewMaterial       = typeof materials.$inferInsert;
export type MaterialUnit      = typeof materialUnitEnum.enumValues[number];

// Material Movements
export type MaterialMovement    = typeof materialMovements.$inferSelect;
export type NewMaterialMovement = typeof materialMovements.$inferInsert;
export type MovementType        = typeof movementTypeEnum.enumValues[number];

// Daily Production Logs
export type DailyProductionLog    = typeof dailyProductionLogs.$inferSelect;
export type NewDailyProductionLog = typeof dailyProductionLogs.$inferInsert;
