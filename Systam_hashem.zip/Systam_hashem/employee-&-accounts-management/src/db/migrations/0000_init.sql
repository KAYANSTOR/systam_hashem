-- Migration script for creating employees and archive_entries tables in PostgreSQL

-- Create employees table
CREATE TABLE IF NOT EXISTS employees (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  salary NUMERIC(10, 2) NOT NULL,
  fixed_departure NUMERIC(10, 2) DEFAULT 0.00,
  hire_date DATE NOT NULL,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Create archive_entries table with foreign key constraint and cascade deletion
CREATE TABLE IF NOT EXISTS archive_entries (
  id SERIAL PRIMARY KEY,
  employee_id INTEGER NOT NULL,
  entry_date DATE NOT NULL,
  day_of_week VARCHAR(20) NOT NULL,
  attendance VARCHAR(50) NOT NULL,
  delay_minutes INTEGER DEFAULT 0,
  departure_amount NUMERIC(10, 2) DEFAULT 0.00,
  overtime_amount NUMERIC(10, 2) DEFAULT 0.00,
  advance_amount NUMERIC(10, 2) DEFAULT 0.00,
  note TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  CONSTRAINT fk_employee
    FOREIGN KEY (employee_id)
    REFERENCES employees(id)
    ON DELETE CASCADE
);
