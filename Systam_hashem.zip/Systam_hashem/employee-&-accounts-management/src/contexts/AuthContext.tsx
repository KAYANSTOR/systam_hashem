import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import type { PublicUser } from '../types';
import { authApi, ApiClientError } from '../lib/apiClient';

// ── Types ─────────────────────────────────────────────────────
interface AuthState {
  user:       PublicUser | null;
  token:      string | null;
  isLoading:  boolean;
  isLoggedIn: boolean;
}

interface AuthContextValue extends AuthState {
  login:  (username: string, password: string) => Promise<void>;
  logout: () => void;
}

// ── Context ───────────────────────────────────────────────────
const AuthContext = createContext<AuthContextValue | null>(null);

// ── Provider ──────────────────────────────────────────────────
export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user,      setUser]      = useState<PublicUser | null>(null);
  const [token,     setToken]     = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // استعادة الجلسة من localStorage عند تحميل التطبيق
  useEffect(() => {
    const savedToken = localStorage.getItem('erp_token');
    if (savedToken) {
      setToken(savedToken);
      authApi.getMe()
        .then((userData) => setUser(userData))
        .catch(() => {
          // التوكن منتهي أو غير صالح
          localStorage.removeItem('erp_token');
          setToken(null);
        })
        .finally(() => setIsLoading(false));
    } else {
      setIsLoading(false);
    }
  }, []);

  const login = useCallback(async (username: string, password: string) => {
    const response = await authApi.login(username, password);
    localStorage.setItem('erp_token', response.token);
    setToken(response.token);
    setUser(response.user);
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem('erp_token');
    setToken(null);
    setUser(null);
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isLoading,
        isLoggedIn: !!user,
        login,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

// ── Hook ──────────────────────────────────────────────────────
export const useAuth = (): AuthContextValue => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within <AuthProvider>');
  return ctx;
};
