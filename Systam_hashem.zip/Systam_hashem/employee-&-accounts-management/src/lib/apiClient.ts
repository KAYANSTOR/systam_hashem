/**
 * ============================================================
 *  API Client — Centralized HTTP Layer
 * ============================================================
 *  كل طلبات الـ API تمر من هنا
 *  - يُضيف Authorization header تلقائياً
 *  - يُعالج أخطاء الشبكة بشكل موحّد
 *  - يدعم TypeScript Generics
 * ============================================================
 */

const API_BASE = '/api';

/** جلب التوكن من localStorage */
const getToken = (): string | null => localStorage.getItem('erp_token');

/** خيارات الـ Fetch الافتراضية */
const buildHeaders = (extra?: HeadersInit): HeadersInit => {
  const token = getToken();
  return {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...extra,
  };
};

/** خطأ API مخصص */
export class ApiClientError extends Error {
  constructor(
    message: string,
    public status: number,
    public code?: string
  ) {
    super(message);
    this.name = 'ApiClientError';
  }
}

/** دالة الطلب المركزية */
async function request<T>(
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE',
  path: string,
  body?: unknown
): Promise<T> {
  const response = await fetch(`${API_BASE}${path}`, {
    method,
    headers: buildHeaders(),
    ...(body ? { body: JSON.stringify(body) } : {}),
  });

  const json = await response.json().catch(() => ({ success: false, error: 'Invalid JSON response' }));

  if (!response.ok || !json.success) {
    throw new ApiClientError(
      json.error || `HTTP ${response.status}`,
      response.status,
      json.code
    );
  }

  return json.data as T;
}

// ── Convenience Methods ──────────────────────────────────────
export const api = {
  get:    <T>(path: string)                  => request<T>('GET',    path),
  post:   <T>(path: string, body: unknown)   => request<T>('POST',   path, body),
  put:    <T>(path: string, body: unknown)   => request<T>('PUT',    path, body),
  patch:  <T>(path: string, body: unknown)   => request<T>('PATCH',  path, body),
  delete: <T>(path: string)                  => request<T>('DELETE', path),
};

// ── Auth API ─────────────────────────────────────────────────
export const authApi = {
  login: (username: string, password: string) =>
    api.post<{ token: string; user: import('../types').PublicUser }>('/auth/login', { username, password }),

  getMe: () =>
    api.get<import('../types').PublicUser>('/auth/me'),
};

// ── Inventory API ─────────────────────────────────────────────
export const inventoryApi = {
  getMaterials: () =>
    api.get<import('../types').MaterialWithStatus[]>('/inventory/materials'),

  getMaterial: (id: number) =>
    api.get<import('../types').MaterialWithStatus>(`/inventory/materials/${id}`),

  dispense: (data: import('../types').DispenseMaterialRequest) =>
    api.post<import('../types').DispenseMaterialResponse>('/inventory/dispense', data),

  receive: (data: import('../types').ReceiveMaterialRequest) =>
    api.post<import('../types').DispenseMaterialResponse>('/inventory/receive', data),

  getMovements: (params?: { materialId?: number; from?: string; to?: string; type?: 'IN' | 'OUT' }) => {
    const q = new URLSearchParams();
    if (params?.materialId) q.set('materialId', String(params.materialId));
    if (params?.from)        q.set('from', params.from);
    if (params?.to)          q.set('to', params.to);
    if (params?.type)        q.set('type', params.type);
    return api.get<import('../types').MaterialMovementDetailed[]>(`/inventory/movements?${q}`);
  },
};

// ── Production API ────────────────────────────────────────────
export const productionApi = {
  getDailyReport: (employeeId: number, date: string) =>
    api.get<import('../types').DailyPerformanceReport>(
      `/production/report/daily?employeeId=${employeeId}&date=${date}`
    ),

  createLog: (data: import('../types').CreateProductionLogRequest) =>
    api.post<import('../types').DailyProductionLog>('/production/logs', data),

  getEmployeeLogs: (employeeId: number) =>
    api.get<import('../types').DailyProductionLog[]>(`/production/logs/employee/${employeeId}`),
};
