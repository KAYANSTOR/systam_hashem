import React, { useState, useCallback } from 'react';
import { productionApi, ApiClientError } from '../lib/apiClient';
import type { DailyPerformanceReport, AttendanceStatus } from '../types';

// ── Icons ─────────────────────────────────────────────────────
const SearchIcon     = () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>;
const LoaderIcon     = () => <svg className="w-5 h-5 animate-spin" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/></svg>;
const UserIcon       = () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>;
const CalendarIcon   = () => <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>;
const ScissorsIcon   = () => <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.121 14.121L19 19m-7-7l7-7m-7 7l-2.879 2.879M12 12L9.121 9.121m0 5.758a3 3 0 10-4.243 4.243 3 3 0 004.243-4.243zm0-5.758a3 3 0 10-4.243-4.243 3 3 0 004.243 4.243z" /></svg>;
const ClockIcon      = () => <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>;
const EmptyBoxIcon   = () => <svg className="w-12 h-12" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}><path strokeLinecap="round" strokeLinejoin="round" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" /></svg>;

// ── Attendance Config ─────────────────────────────────────────
const ATTENDANCE_CONFIG: Record<AttendanceStatus, {
  label:  string;
  color:  string;
  bg:     string;
  border: string;
}> = {
  present:  { label: 'حاضر',       color: 'text-green-400',  bg: 'bg-green-500/10',  border: 'border-green-500/20' },
  absent:   { label: 'غائب',       color: 'text-red-400',    bg: 'bg-red-500/10',    border: 'border-red-500/20' },
  half_day: { label: 'نصف يوم',    color: 'text-amber-400',  bg: 'bg-amber-500/10',  border: 'border-amber-500/20' },
  holiday:  { label: 'إجازة',      color: 'text-blue-400',   bg: 'bg-blue-500/10',   border: 'border-blue-500/20' },
  on_leave: { label: 'إجازة رسمية', color: 'text-violet-400', bg: 'bg-violet-500/10', border: 'border-violet-500/20' },
};

// ── Today's date helper ───────────────────────────────────────
const todayISO = () => new Date().toISOString().split('T')[0];

// ============================================================
// EmployeeDailyReportCard Component
// ============================================================
/**
 * بطاقة الأداء اليومي للموظف
 *
 * قاعدة صارمة: لا تعرض أي بيانات مالية (راتب، مكافأة، خصم).
 * تعرض فقط: حالة الحضور + دقائق التأخير + قائمة القطع المطرّزة.
 */
const EmployeeDailyReportCard: React.FC = () => {
  const [employeeId, setEmployeeId] = useState('');
  const [date,       setDate]       = useState(todayISO());
  const [isLoading,  setIsLoading]  = useState(false);
  const [error,      setError]      = useState<string | null>(null);
  const [report,     setReport]     = useState<DailyPerformanceReport | null>(null);

  const handleFetch = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    const id = parseInt(employeeId, 10);
    if (isNaN(id) || !date) return;

    setIsLoading(true);
    setError(null);
    setReport(null);

    try {
      const data = await productionApi.getDailyReport(id, date);
      setReport(data);
    } catch (err) {
      const apiErr = err as ApiClientError;
      if (apiErr.code === 'EMPLOYEE_NOT_FOUND') {
        setError(`لم يُعثر على موظف برقم ${id}.`);
      } else {
        setError(apiErr.message || 'حدث خطأ في جلب بيانات الأداء.');
      }
    } finally {
      setIsLoading(false);
    }
  }, [employeeId, date]);

  const attendanceCfg = report?.attendance
    ? ATTENDANCE_CONFIG[report.attendance.status]
    : null;

  return (
    <div className="max-w-2xl mx-auto space-y-5">
      {/* ── Header ─────────────────────────────────────────── */}
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-green-500/15 flex items-center justify-center text-green-400">
          <UserIcon />
        </div>
        <div>
          <h2 className="text-lg font-bold text-white">بطاقة الأداء اليومي</h2>
          <p className="text-sm text-slate-500">الحضور + الإنتاج التشغيلي — بدون بيانات مالية</p>
        </div>
      </div>

      {/* ── Search Form ────────────────────────────────────── */}
      <form
        onSubmit={handleFetch}
        className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col sm:flex-row gap-3"
      >
        <div className="flex-1">
          <label className="block text-xs font-medium text-slate-400 mb-1.5">رقم الموظف</label>
          <input
            type="number"
            value={employeeId}
            onChange={(e) => setEmployeeId(e.target.value)}
            min="1"
            required
            placeholder="أدخل رقم الموظف..."
            className="w-full bg-slate-800 border border-slate-700 text-white rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all placeholder:text-slate-600"
          />
        </div>
        <div className="flex-1">
          <label className="block text-xs font-medium text-slate-400 mb-1.5">التاريخ</label>
          <input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            required
            max={todayISO()}
            className="w-full bg-slate-800 border border-slate-700 text-white rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
          />
        </div>
        <div className="flex items-end">
          <button
            type="submit"
            disabled={isLoading || !employeeId}
            className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-500 disabled:bg-slate-700 disabled:text-slate-500 text-white font-semibold rounded-xl transition-all whitespace-nowrap"
          >
            {isLoading ? <LoaderIcon /> : <SearchIcon />}
            <span>عرض</span>
          </button>
        </div>
      </form>

      {/* ── Error ──────────────────────────────────────────── */}
      {error && (
        <div className="flex items-center gap-3 p-4 bg-red-500/10 border border-red-500/20 rounded-xl text-red-400 text-sm">
          <svg className="w-5 h-5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
          <span>{error}</span>
        </div>
      )}

      {/* ── Report Card ────────────────────────────────────── */}
      {report && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
          {/* Card Header */}
          <div className="p-5 border-b border-slate-800 bg-gradient-to-l from-blue-600/5 to-transparent">
            <div className="flex items-center justify-between flex-wrap gap-3">
              {/* معلومات الموظف */}
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-slate-600 to-slate-700 flex items-center justify-center text-white font-bold text-lg">
                  {report.employee.fullName.charAt(0)}
                </div>
                <div>
                  <p className="font-bold text-white">{report.employee.fullName}</p>
                  <p className="text-xs text-slate-500">#{report.employee.id}</p>
                </div>
              </div>

              {/* التاريخ */}
              <div className="flex items-center gap-1.5 text-slate-400 text-sm">
                <CalendarIcon />
                <span>{new Date(report.date).toLocaleDateString('ar-SA', {
                  weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
                })}</span>
              </div>
            </div>
          </div>

          {/* الجسم */}
          <div className="p-5 space-y-5">

            {/* ── قسم الحضور ─────────────────────────────────── */}
            <section>
              <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3">
                الحضور والانضباط
              </h3>

              {report.attendance ? (
                <div className={`flex items-center justify-between p-4 rounded-xl border ${attendanceCfg!.bg} ${attendanceCfg!.border}`}>
                  <div className="flex items-center gap-3">
                    <span className={`text-2xl font-bold ${attendanceCfg!.color}`}>
                      {attendanceCfg!.label}
                    </span>
                  </div>

                  {/* دقائق التأخير */}
                  {report.attendance.delayMinutes > 0 && (
                    <div className="flex items-center gap-2 bg-amber-500/10 border border-amber-500/20 rounded-lg px-3 py-1.5">
                      <ClockIcon />
                      <span className="text-amber-400 text-sm font-medium">
                        تأخير {report.attendance.delayMinutes} دقيقة
                      </span>
                    </div>
                  )}
                  {report.attendance.delayMinutes === 0 && report.attendance.status === 'present' && (
                    <span className="text-xs text-green-400 bg-green-500/10 px-3 py-1 rounded-lg">في الوقت ✓</span>
                  )}
                </div>
              ) : (
                <div className="p-4 bg-slate-800 rounded-xl text-slate-500 text-sm text-center">
                  لا يوجد سجل حضور لهذا اليوم
                </div>
              )}
            </section>

            {/* ── قسم الإنتاج (بدون أي بيانات مالية) ─────────── */}
            <section>
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                  الإنتاج التشغيلي
                </h3>
                {report.production.totalItems > 0 && (
                  <span className="text-xs font-bold text-blue-400 bg-blue-500/10 border border-blue-500/20 px-3 py-1 rounded-full">
                    الإجمالي: {report.production.totalItems} قطعة
                  </span>
                )}
              </div>

              {report.production.logs.length > 0 ? (
                <div className="space-y-2">
                  {report.production.logs.map((log) => (
                    <div
                      key={log.id}
                      className="flex items-center gap-3 p-3.5 bg-slate-800 hover:bg-slate-800/80 rounded-xl transition-colors"
                    >
                      <div className="w-8 h-8 rounded-lg bg-blue-500/10 flex items-center justify-center text-blue-400 flex-shrink-0">
                        <ScissorsIcon />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-white truncate">{log.itemName}</p>
                        <div className="flex items-center gap-2 mt-0.5">
                          {log.machineCode && (
                            <span className="text-xs text-slate-500">مكينة: {log.machineCode}</span>
                          )}
                          {log.shiftType && (
                            <span className="text-xs text-slate-600">• {log.shiftType}</span>
                          )}
                          {log.note && (
                            <span className="text-xs text-slate-600">• {log.note}</span>
                          )}
                        </div>
                      </div>
                      {/* الكمية فقط — بدون أي قيمة مالية */}
                      <div className="text-right flex-shrink-0">
                        <span className="text-lg font-bold text-white">{log.quantity}</span>
                        <p className="text-xs text-slate-500">قطعة</p>
                      </div>
                    </div>
                  ))}

                  {/* ملخص الإجمالي */}
                  <div className="flex items-center justify-between p-3 bg-blue-600/10 border border-blue-500/20 rounded-xl mt-3">
                    <span className="text-sm font-medium text-blue-300">إجمالي الإنتاج اليوم</span>
                    <span className="text-xl font-bold text-white">{report.production.totalItems} قطعة</span>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-8 text-slate-600">
                  <EmptyBoxIcon />
                  <p className="mt-2 text-sm">لا توجد سجلات إنتاج لهذا اليوم</p>
                </div>
              )}
            </section>

            {/* ── تذييل: ملاحظة عدم وجود بيانات مالية ────────── */}
            <div className="pt-3 border-t border-slate-800">
              <p className="text-xs text-slate-600 text-center">
                🔒 هذه البطاقة تعرض بيانات الأداء التشغيلي فقط — لا تحتوي على بيانات مالية
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default EmployeeDailyReportCard;
