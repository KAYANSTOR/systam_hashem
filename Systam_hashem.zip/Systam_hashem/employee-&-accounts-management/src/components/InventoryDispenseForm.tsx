import React, { useState, useEffect } from 'react';
import { inventoryApi, ApiClientError } from '../lib/apiClient';
import type { MaterialWithStatus, DispenseMaterialResponse } from '../types';

// ── Icons ─────────────────────────────────────────────────────
const AlertIcon   = () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>;
const SuccessIcon = () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>;
const BoxIcon     = () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" /></svg>;
const LoaderIcon  = () => <svg className="w-5 h-5 animate-spin" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/></svg>;

// ── Toast Notification ────────────────────────────────────────
interface ToastProps {
  type:    'success' | 'error' | 'warning';
  message: string;
  onClose: () => void;
}

const Toast: React.FC<ToastProps> = ({ type, message, onClose }) => {
  useEffect(() => {
    const timer = setTimeout(onClose, 5000);
    return () => clearTimeout(timer);
  }, [onClose]);

  const styles = {
    success: 'bg-green-500/15 border-green-500/30 text-green-300',
    error:   'bg-red-500/15 border-red-500/30 text-red-300',
    warning: 'bg-amber-500/15 border-amber-500/30 text-amber-300',
  };

  return (
    <div className={`flex items-start gap-3 p-4 rounded-xl border ${styles[type]} animate-fade-in`}>
      <span className="mt-0.5 flex-shrink-0">
        {type === 'success' ? <SuccessIcon /> : <AlertIcon />}
      </span>
      <p className="text-sm font-medium flex-1">{message}</p>
      <button onClick={onClose} className="text-current opacity-60 hover:opacity-100 transition-opacity ml-2">✕</button>
    </div>
  );
};

// ── Stock Badge ───────────────────────────────────────────────
const StockBadge: React.FC<{ material: MaterialWithStatus }> = ({ material }) => {
  const pct = Math.min(
    100,
    Math.round((parseFloat(material.currentStock) / Math.max(parseFloat(material.minThreshold) * 3, 1)) * 100)
  );

  return (
    <div className="mt-1">
      <div className="flex justify-between text-xs text-slate-500 mb-1">
        <span>المخزون الحالي</span>
        <span className={material.isLowStock ? 'text-red-400 font-semibold' : 'text-slate-400'}>
          {parseFloat(material.currentStock).toFixed(2)} {material.unit}
        </span>
      </div>
      <div className="h-1.5 bg-slate-700 rounded-full overflow-hidden">
        <div
          className={`h-full rounded-full transition-all duration-500 ${
            material.isLowStock ? 'bg-red-500' : pct < 50 ? 'bg-amber-500' : 'bg-green-500'
          }`}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
};

// ============================================================
// InventoryDispenseForm Component
// ============================================================
const InventoryDispenseForm: React.FC = () => {
  const [materials,        setMaterials]        = useState<MaterialWithStatus[]>([]);
  const [isLoadingMats,    setIsLoadingMats]    = useState(true);
  const [selectedMaterial, setSelectedMaterial] = useState<MaterialWithStatus | null>(null);
  const [quantity,         setQuantity]         = useState('');
  const [note,             setNote]             = useState('');
  const [isSubmitting,     setIsSubmitting]     = useState(false);
  const [toast,            setToast]            = useState<{ type: 'success' | 'error' | 'warning'; message: string } | null>(null);
  const [lastResult,       setLastResult]       = useState<DispenseMaterialResponse | null>(null);

  // جلب قائمة المواد
  useEffect(() => {
    inventoryApi.getMaterials()
      .then(setMaterials)
      .catch((err) => setToast({ type: 'error', message: `فشل تحميل المواد: ${err.message}` }))
      .finally(() => setIsLoadingMats(false));
  }, []);

  // تحديث المادة المختارة بعد كل تحديث للقائمة
  useEffect(() => {
    if (selectedMaterial) {
      const updated = materials.find((m) => m.id === selectedMaterial.id);
      if (updated) setSelectedMaterial(updated);
    }
  }, [materials]);

  const handleMaterialChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const id = parseInt(e.target.value, 10);
    setSelectedMaterial(materials.find((m) => m.id === id) ?? null);
    setQuantity('');
    setLastResult(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMaterial) return;

    const qty = parseFloat(quantity);

    // ── Client-side Validation ───────────────────────────
    if (isNaN(qty) || qty <= 0) {
      setToast({ type: 'error', message: 'الكمية يجب أن تكون رقماً موجباً.' });
      return;
    }
    if (qty > parseFloat(selectedMaterial.currentStock)) {
      setToast({
        type:    'error',
        message: `الكمية المطلوبة (${qty}) تتجاوز الرصيد المتاح (${parseFloat(selectedMaterial.currentStock).toFixed(2)} ${selectedMaterial.unit}).`,
      });
      return;
    }

    setIsSubmitting(true);
    setLastResult(null);

    try {
      const result = await inventoryApi.dispense({
        materialId: selectedMaterial.id,
        quantity:   qty,
        note:       note.trim() || undefined,
      });

      setLastResult(result);

      // تحديث المادة في القائمة محلياً
      setMaterials((prev) =>
        prev.map((m) =>
          m.id === selectedMaterial.id
            ? {
                ...m,
                currentStock: String(result.stockAfter),
                isLowStock:   result.isLowStock,
              }
            : m
        )
      );

      setToast({
        type:    result.isLowStock ? 'warning' : 'success',
        message: result.isLowStock
          ? `✅ تم الصرف بنجاح. ⚠️ تحذير: المخزون وصل للحد الأدنى!`
          : `✅ تم صرف ${qty} ${selectedMaterial.unit} من "${selectedMaterial.name}" بنجاح.`,
      });

      // إعادة تعيين النموذج
      setQuantity('');
      setNote('');
    } catch (err) {
      const error = err as ApiClientError;

      // ── معالجة أخطاء API المحددة ──────────────────────
      if (error.code === 'INSUFFICIENT_STOCK') {
        setToast({
          type:    'error',
          message: `❌ الرصيد غير كافٍ. الرصيد الحالي: ${parseFloat(selectedMaterial.currentStock).toFixed(2)} ${selectedMaterial.unit}.`,
        });
      } else if (error.code === 'MATERIAL_NOT_FOUND') {
        setToast({ type: 'error', message: '❌ المادة غير موجودة. يرجى تحديث الصفحة.' });
      } else {
        setToast({ type: 'error', message: `❌ فشل الصرف: ${error.message}` });
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-xl mx-auto space-y-5">
      {/* ── Header ─────────────────────────────────────────── */}
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-amber-500/15 flex items-center justify-center text-amber-400">
          <BoxIcon />
        </div>
        <div>
          <h2 className="text-lg font-bold text-white">صرف مواد</h2>
          <p className="text-sm text-slate-500">إخراج مواد من مخزون المعمل</p>
        </div>
      </div>

      {/* ── Toast ──────────────────────────────────────────── */}
      {toast && (
        <Toast
          type={toast.type}
          message={toast.message}
          onClose={() => setToast(null)}
        />
      )}

      {/* ── Form Card ──────────────────────────────────────── */}
      <form
        onSubmit={handleSubmit}
        className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-5"
      >
        {/* اختيار المادة */}
        <div>
          <label className="block text-sm font-medium text-slate-300 mb-2">
            المادة <span className="text-red-400">*</span>
          </label>
          {isLoadingMats ? (
            <div className="h-11 bg-slate-800 rounded-xl animate-pulse" />
          ) : (
            <select
              value={selectedMaterial?.id ?? ''}
              onChange={handleMaterialChange}
              required
              className="w-full bg-slate-800 border border-slate-700 text-white rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
            >
              <option value="" disabled>اختر مادة...</option>
              {materials.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name}
                  {m.isLowStock ? ' ⚠️ مخزون منخفض' : ''}
                  {' '}— {parseFloat(m.currentStock).toFixed(2)} {m.unit}
                </option>
              ))}
            </select>
          )}

          {/* شريط المخزون */}
          {selectedMaterial && <StockBadge material={selectedMaterial} />}

          {/* تحذير مخزون منخفض */}
          {selectedMaterial?.isLowStock && (
            <div className="mt-2 flex items-center gap-2 text-xs text-amber-400 bg-amber-500/10 border border-amber-500/20 rounded-lg px-3 py-2">
              <AlertIcon />
              <span>تحذير: هذه المادة وصلت للحد الأدنى ({parseFloat(selectedMaterial.minThreshold).toFixed(2)} {selectedMaterial.unit})</span>
            </div>
          )}
        </div>

        {/* الكمية */}
        <div>
          <label className="block text-sm font-medium text-slate-300 mb-2">
            الكمية {selectedMaterial ? `(${selectedMaterial.unit})` : ''} <span className="text-red-400">*</span>
          </label>
          <input
            type="number"
            value={quantity}
            onChange={(e) => setQuantity(e.target.value)}
            min="0.001"
            step="0.001"
            max={selectedMaterial ? parseFloat(selectedMaterial.currentStock) : undefined}
            required
            placeholder="0.000"
            className="w-full bg-slate-800 border border-slate-700 text-white rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all placeholder:text-slate-600"
          />
          {selectedMaterial && quantity && (
            <p className="mt-1 text-xs text-slate-500">
              المتبقي بعد الصرف:{' '}
              <span className={
                parseFloat(selectedMaterial.currentStock) - parseFloat(quantity || '0') <= parseFloat(selectedMaterial.minThreshold)
                  ? 'text-red-400 font-semibold'
                  : 'text-slate-300'
              }>
                {Math.max(0, parseFloat(selectedMaterial.currentStock) - parseFloat(quantity || '0')).toFixed(3)} {selectedMaterial.unit}
              </span>
            </p>
          )}
        </div>

        {/* ملاحظة */}
        <div>
          <label className="block text-sm font-medium text-slate-300 mb-2">ملاحظة (اختياري)</label>
          <textarea
            value={note}
            onChange={(e) => setNote(e.target.value)}
            rows={2}
            placeholder="سبب الصرف..."
            className="w-full bg-slate-800 border border-slate-700 text-white rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all resize-none placeholder:text-slate-600"
          />
        </div>

        {/* زر الإرسال */}
        <button
          type="submit"
          disabled={isSubmitting || !selectedMaterial || !quantity}
          className="w-full flex items-center justify-center gap-2 py-3 px-6 bg-blue-600 hover:bg-blue-500 disabled:bg-slate-700 disabled:text-slate-500 text-white font-semibold rounded-xl transition-all duration-200 shadow-lg shadow-blue-600/25 disabled:shadow-none"
        >
          {isSubmitting ? (
            <>
              <LoaderIcon />
              <span>جارٍ الصرف...</span>
            </>
          ) : (
            <>
              <BoxIcon />
              <span>تأكيد الصرف</span>
            </>
          )}
        </button>
      </form>

      {/* ── نتيجة الصرف ────────────────────────────────────── */}
      {lastResult && (
        <div className="bg-slate-900 border border-green-500/20 rounded-2xl p-5 space-y-3">
          <div className="flex items-center gap-2 text-green-400 font-semibold text-sm">
            <SuccessIcon />
            <span>تم الصرف بنجاح</span>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-slate-800 rounded-xl p-3 text-center">
              <p className="text-xs text-slate-500 mb-1">الكمية المصروفة</p>
              <p className="text-lg font-bold text-white">{lastResult.movement.quantity}</p>
            </div>
            <div className="bg-slate-800 rounded-xl p-3 text-center">
              <p className="text-xs text-slate-500 mb-1">الرصيد الحالي</p>
              <p className={`text-lg font-bold ${lastResult.isLowStock ? 'text-red-400' : 'text-white'}`}>
                {lastResult.stockAfter}
              </p>
            </div>
          </div>
          {lastResult.isLowStock && (
            <div className="flex items-center gap-2 text-xs text-amber-400 bg-amber-500/10 border border-amber-500/20 rounded-lg px-3 py-2">
              <AlertIcon />
              <span>⚠️ المخزون وصل للحد الأدنى — يُنصح بإعادة التوريد</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default InventoryDispenseForm;
