import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { ROLE_PERMISSIONS } from '../types';
import type { UserRole } from '../types';

// ── Icons (SVG Inline) ────────────────────────────────────────
const DashboardIcon  = () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>;
const EmployeesIcon  = () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" /></svg>;
const InventoryIcon  = () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" /></svg>;
const ProductionIcon = () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>;
const FinanceIcon    = () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>;
const SalesIcon      = () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" /></svg>;
const ReportsIcon    = () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>;
const LogoutIcon     = () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>;
const MenuIcon       = () => <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" /></svg>;
const CloseIcon      = () => <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>;

// ── Role Badge Colors ─────────────────────────────────────────
const ROLE_CONFIG: Record<UserRole, { label: string; color: string }> = {
  admin:                 { label: 'مدير',             color: 'bg-violet-500/20 text-violet-300 border-violet-500/30' },
  accountant:            { label: 'محاسب',            color: 'bg-blue-500/20 text-blue-300 border-blue-500/30' },
  materials_manager:     { label: 'مسؤول مخزن',       color: 'bg-amber-500/20 text-amber-300 border-amber-500/30' },
  production_supervisor: { label: 'مشرف إنتاج',       color: 'bg-green-500/20 text-green-300 border-green-500/30' },
  viewer:                { label: 'مشاهد',            color: 'bg-slate-500/20 text-slate-300 border-slate-500/30' },
};

// ── Nav Item Type ─────────────────────────────────────────────
interface NavItem {
  id:        string;
  label:     string;
  icon:      React.ReactNode;
  /** إذا كانت true فالعنصر مرئي فقط لمن لديه هذه الصلاحية */
  permission?: keyof typeof ROLE_PERMISSIONS[UserRole];
  /** أدوار محددة تُخفي هذا العنصر */
  hiddenFor?: UserRole[];
}

const NAV_ITEMS: NavItem[] = [
  {
    id:    'dashboard',
    label: 'لوحة التحكم',
    icon:  <DashboardIcon />,
  },
  {
    id:        'employees',
    label:     'الموظفون',
    icon:      <EmployeesIcon />,
    hiddenFor: ['materials_manager', 'production_supervisor'],
  },
  {
    id:         'inventory',
    label:      'المخزون',
    icon:       <InventoryIcon />,
    permission: 'canManageMaterials',
  },
  {
    id:         'production',
    label:      'الإنتاج',
    icon:       <ProductionIcon />,
    permission: 'canRecordProduction',
  },
  {
    // ── مخفي تماماً عن materials_manager و production_supervisor ──
    id:         'finance',
    label:      'الحسابات',
    icon:       <FinanceIcon />,
    permission: 'canAccessFinance',
  },
  {
    // ── مخفي تماماً عن materials_manager و production_supervisor ──
    id:         'sales',
    label:      'المبيعات',
    icon:       <SalesIcon />,
    permission: 'canAccessSales',
  },
  {
    id:         'reports',
    label:      'التقارير',
    icon:       <ReportsIcon />,
    permission: 'canViewReports',
  },
];

// ── Props ─────────────────────────────────────────────────────
interface NavigationProps {
  activePage: string;
  onNavigate: (page: string) => void;
}

// ============================================================
// Navigation Component
// ============================================================
const Navigation: React.FC<NavigationProps> = ({ activePage, onNavigate }) => {
  const { user, logout } = useAuth();
  const [isMobileOpen, setIsMobileOpen] = useState(false);

  if (!user) return null;

  const permissions  = ROLE_PERMISSIONS[user.role];
  const roleConfig   = ROLE_CONFIG[user.role];

  /**
   * فلترة عناصر التنقل بناءً على دور المستخدم
   *
   * القاعدة الصارمة:
   * - materials_manager لا يرى "الحسابات" ولا "المبيعات" أبداً
   * - يُفحص كل عنصر مقابل ROLE_PERMISSIONS
   */
  const visibleItems = NAV_ITEMS.filter((item) => {
    // إذا كان العنصر محظوراً لهذا الدور
    if (item.hiddenFor?.includes(user.role)) return false;

    // إذا كان العنصر يتطلب صلاحية محددة
    if (item.permission) {
      return permissions[item.permission];
    }

    return true;
  });

  const handleNavigate = (page: string) => {
    onNavigate(page);
    setIsMobileOpen(false);
  };

  const NavLink = ({ item }: { item: NavItem }) => (
    <button
      onClick={() => handleNavigate(item.id)}
      className={`
        w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium
        transition-all duration-200 group text-right
        ${activePage === item.id
          ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/25'
          : 'text-slate-400 hover:bg-slate-800 hover:text-slate-100'
        }
      `}
    >
      <span className={`transition-transform duration-200 ${activePage === item.id ? 'scale-110' : 'group-hover:scale-105'}`}>
        {item.icon}
      </span>
      <span>{item.label}</span>
    </button>
  );

  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      {/* ── Logo ───────────────────────────────────────────── */}
      <div className="p-6 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-500 to-violet-600 flex items-center justify-center shadow-lg">
            <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
          </div>
          <div>
            <p className="text-sm font-bold text-white">Embroidery ERP</p>
            <p className="text-xs text-slate-500">نظام إدارة المشغل</p>
          </div>
        </div>
      </div>

      {/* ── Nav Items ──────────────────────────────────────── */}
      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        {visibleItems.map((item) => (
          <NavLink key={item.id} item={item} />
        ))}
      </nav>

      {/* ── User Info + Logout ─────────────────────────────── */}
      <div className="p-4 border-t border-slate-800">
        {/* بطاقة المستخدم */}
        <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-800/50 mb-3">
          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-slate-600 to-slate-700 flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
            {user.fullName.charAt(0)}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-white truncate">{user.fullName}</p>
            <span className={`inline-block text-xs px-2 py-0.5 rounded-full border ${roleConfig.color}`}>
              {roleConfig.label}
            </span>
          </div>
        </div>

        {/* زر تسجيل الخروج */}
        <button
          onClick={logout}
          className="w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium text-red-400 hover:bg-red-500/10 hover:text-red-300 transition-all duration-200"
        >
          <LogoutIcon />
          <span>تسجيل الخروج</span>
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* ── Desktop Sidebar ──────────────────────────────────── */}
      <aside className="hidden lg:flex flex-col w-64 bg-slate-900 border-l border-slate-800 h-screen sticky top-0">
        <SidebarContent />
      </aside>

      {/* ── Mobile Top Bar ────────────────────────────────────── */}
      <div className="lg:hidden fixed top-0 right-0 left-0 z-40 bg-slate-900 border-b border-slate-800 px-4 py-3 flex items-center justify-between">
        <button
          onClick={() => setIsMobileOpen(true)}
          className="p-2 rounded-lg text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
        >
          <MenuIcon />
        </button>
        <p className="text-sm font-bold text-white">Embroidery ERP</p>
        <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-blue-500 to-violet-600 flex items-center justify-center text-white font-bold text-sm">
          {user.fullName.charAt(0)}
        </div>
      </div>

      {/* ── Mobile Drawer ─────────────────────────────────────── */}
      {isMobileOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          {/* Backdrop */}
          <div
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setIsMobileOpen(false)}
          />
          {/* Drawer Panel */}
          <aside className="relative mr-auto w-72 bg-slate-900 h-full shadow-2xl flex flex-col">
            {/* Close Button */}
            <button
              onClick={() => setIsMobileOpen(false)}
              className="absolute top-4 left-4 p-2 rounded-lg text-slate-400 hover:bg-slate-800 hover:text-white transition-colors z-10"
            >
              <CloseIcon />
            </button>
            <SidebarContent />
          </aside>
        </div>
      )}
    </>
  );
};

export default Navigation;
