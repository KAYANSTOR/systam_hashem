# نظام إدارة معمل التطريز - Backend

## المرحلة 1 (منجزة): قاعدة البيانات + المصادقة + إدارة المستخدمين والصلاحيات

### المحتوى
- جدول `users` بالأدوار الخمسة: admin, sales, materials_manager, fabric_manager, production_supervisor
- جدول `user_activity_log` لسجل التدقيق
- تسجيل دخول عبر JWT (`POST /auth/login`)
- إدارة المستخدمين (إضافة/عرض/تفعيل-تعطيل) — للمدير فقط
- Middlewares: `authenticate` (التحقق من الجلسة) و `roleGuard` (التحقق من الصلاحية)

### خطوات التشغيل
```bash
npm install
cp .env.example .env      # عدّل DATABASE_URL و JWT_SECRET
npm run migrate           # ينشئ الجداول في قاعدة البيانات
npm run dev                # تشغيل محلي مع nodemon
```

### إنشاء أول مستخدم مدير (يدويًا عبر SQL لأول مرة فقط)
```sql
-- شغّل هذا الكود في Node لتوليد الهاش:
-- node -e "console.log(require('bcrypt').hashSync('كلمة_المرور', 10))"

INSERT INTO users (full_name, username, password_hash, role)
VALUES ('اسم المدير', 'admin', '<الهاش الناتج>', 'admin');
```

### اختبار سريع (بعد التشغيل)
```bash
# تسجيل الدخول
curl -X POST http://localhost:4000/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"كلمة_المرور"}'

# إنشاء مستخدم جديد (باستخدام التوكن الناتج)
curl -X POST http://localhost:4000/users \
  -H "Authorization: Bearer <TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{"full_name":"محمد المخزن","username":"materials1","password":"123456","role":"materials_manager"}'
```

---

## المرحلة 2 (منجزة): العملاء + مخزون أقمشة الزبائن + إشعارات البيع + سندات القبض

### المحتوى
- جداول: `customers`, `customer_fabrics`, `sales_invoices`, `receipts`, `customer_transactions`
- منطق "الفارغة": عند بيع كمية أقل من رصيد دفعة القماش، ينشئ النظام تلقائيًا سجل قماش جديد بالفرق بحالة `is_leftover = true` مرتبط بالدفعة الأصلية عبر `parent_fabric_id`
- كل عملية بيع/قبض تُنفَّذ ضمن **Database Transaction** واحدة مع قفل الصفوف (`FOR UPDATE`) لمنع تعارض العمليات المتزامنة وضمان دقة الأرصدة
- تحديث رصيد العميل تلقائيًا + تسجيل كل حركة في `customer_transactions` (كشف الحساب)

### تشغيل مايجريشن المرحلة 2
```bash
npm run migrate
```

### نقاط النهاية (Endpoints) الجديدة
```
GET  /customers                      قائمة العملاء
POST /customers                      إضافة عميل { name, phone, address, notes }
GET  /customers/top-debtors          أعلى العملاء مديونية
GET  /customers/:id                  بيانات عميل
GET  /customers/:id/statement        كشف حساب العميل

POST /fabrics/receive                استلام قماش من عميل
     { customer_id, fabric_type, rolls_count, total_yards, received_date, notes }
GET  /fabrics/customer/:customerId   دفعات القماش المتاحة لعميل (رصيد > 0)

POST /sales/invoice                  إشعار بيع (يخصم تلقائيًا وينشئ "فارغة" عند الحاجة)
     { customer_id, fabric_id, yards_sold, price_per_yard,
       payment_type: "cash"|"credit"|"partial", paid_amount, invoice_date, notes }

POST /receipts                       سند قبض { customer_id, amount, receipt_date, notes }
```

### مثال اختبار سريع (سيناريو "الفارغة")
```bash
# 1) استلام 300 وار من عميل
curl -X POST http://localhost:4000/fabrics/receive \
  -H "Authorization: Bearer <TOKEN>" -H "Content-Type: application/json" \
  -d '{"customer_id":1,"fabric_type":"قطن مطرز","rolls_count":3,"total_yards":300}'

# 2) بيع 298 وار فقط -> يبقى 2 وار في سجل جديد "فارغة"
curl -X POST http://localhost:4000/sales/invoice \
  -H "Authorization: Bearer <TOKEN>" -H "Content-Type: application/json" \
  -d '{"customer_id":1,"fabric_id":1,"yards_sold":298,"price_per_yard":500,"payment_type":"partial","paid_amount":100000}'
```

---

## المرحلة 3 (منجزة): مخزن مواد المعمل

### المحتوى
- جداول: `materials` (الرصيد الحالي لكل مادة)، `material_transactions` (سجل كل حركة دخول/خروج)
- **فصل الصلاحيات كما طلبت بالضبط**: `materials_manager` يملك فقط صلاحية الدخول/الخروج وعرض قائمة المواد لاختيارها — لا يرى أي بيانات مالية أو حسابات عملاء (تلك في وحدات منفصلة تمامًا لا يصل إليها دوره).
- كل عملية دخول/خروج تُسجَّل **باسم المستخدم تلقائيًا** (`user_id` من التوكن)، وتظهر للمدير في `GET /materials/movements` باسم المستخدم الكامل.
- منع الخروج بكمية أكبر من الرصيد المتاح (ضمن Transaction مع قفل الصف).
- حقل `min_alert_qty` + `low_stock` في الاستجابة لتنبيه وصول مادة للحد الأدنى.

### تشغيل مايجريشن المرحلة 3
```bash
npm run migrate
```

### نقاط النهاية (Endpoints) الجديدة
```
GET  /materials                 قائمة المواد وأرصدتها (admin + materials_manager)
POST /materials                 تعريف مادة جديدة { name, unit: "kg"|"piece", min_alert_qty }  (admin فقط)

POST /materials/in              تسجيل توريد { material_id, quantity, transaction_date, notes }
POST /materials/out             تسجيل صرف   { material_id, quantity, transaction_date, notes }
     (admin + materials_manager)

GET  /materials/movements       سجل كل الحركات مع اسم المستخدم والتاريخ (admin فقط)
     فلاتر اختيارية: ?material_id=&from_date=&to_date=
```

### مثال اختبار سريع
```bash
# تعريف مادة (مرة واحدة، من المدير)
curl -X POST http://localhost:4000/materials \
  -H "Authorization: Bearer <ADMIN_TOKEN>" -H "Content-Type: application/json" \
  -d '{"name":"قصب ذهبي","unit":"kg","min_alert_qty":5}'

# مسؤول المخزن يسجل توريد كرتون قصب ذهبي 20 كيلو
curl -X POST http://localhost:4000/materials/in \
  -H "Authorization: Bearer <MATERIALS_MANAGER_TOKEN>" -H "Content-Type: application/json" \
  -d '{"material_id":1,"quantity":20,"notes":"كرتون توريد جديد"}'

# المدير يشاهد الحركة كاملة مع اسم من قام بالتوريد
curl http://localhost:4000/materials/movements -H "Authorization: Bearer <ADMIN_TOKEN>"
```

---

## المرحلة 4 (منجزة): الإنتاج + الترحيل التلقائي لنظام الموظفين

### المحتوى
- جداول: `machines`، `machine_assignments` (من يملك صلاحية تسجيل إنتاج أي مكينة)، `production_records`، `hr_production_entries`
- المدير يضيف مكائن ويمنح صلاحية تسجيل الإنتاج لمستخدم محدد على مكينة محددة
- **مشرف الإنتاج مقيّد فعليًا بالمكائن المخصصة له فقط** — أي محاولة تسجيل إنتاج لمكينة غير مخصصة له تُرفض (403)
- عند حفظ سجل إنتاج (الغرز، الفرشات، من اشتغل، مستلم المكينة)، يُرحَّل **تلقائيًا وبنفس التاريخ** إلى `hr_production_entries` ضمن نفس الـ Transaction
- تقرير إنتاج كامل للمدير مع فلاتر (مكينة/عامل/فترة)

### تشغيل مايجريشن المرحلة 4
```bash
npm run migrate
```

### نقاط النهاية (Endpoints) الجديدة
```
POST /production/machines        إضافة مكينة { name, code }         (admin فقط)
GET  /production/machines        قائمة كل المكائن                    (admin فقط)

POST /production/assign          منح صلاحية مكينة لمستخدم            (admin فقط)
     { machine_id, assigned_to_user_id, operator_name }

GET  /production/my-machines     المكائن المخصصة للمستخدم الحالي     (admin + production_supervisor)

POST /production/record          تسجيل إنتاج يومي (يترحل تلقائيًا لـ HR)
     { machine_id, operator_name, receiver_name, stitches_count, panels_count, work_date, shift }
     (admin + production_supervisor -- مقيّد بمكائنه المخصصة)

GET  /production/records         تقرير الإنتاج الكامل                (admin فقط)
     فلاتر اختيارية: ?machine_id=&operator_name=&from_date=&to_date=
```

### مثال اختبار سريع
```bash
# 1) المدير يضيف مكينة
curl -X POST http://localhost:4000/production/machines \
  -H "Authorization: Bearer <ADMIN_TOKEN>" -H "Content-Type: application/json" \
  -d '{"name":"مكينة تطريز 1","code":"M-01"}'

# 2) المدير يمنح صلاحيتها لمستخدم مشرف إنتاج
curl -X POST http://localhost:4000/production/assign \
  -H "Authorization: Bearer <ADMIN_TOKEN>" -H "Content-Type: application/json" \
  -d '{"machine_id":1,"assigned_to_user_id":5,"operator_name":"أحمد"}'

# 3) مشرف الإنتاج يسجل إنتاج اليوم
curl -X POST http://localhost:4000/production/record \
  -H "Authorization: Bearer <SUPERVISOR_TOKEN>" -H "Content-Type: application/json" \
  -d '{"machine_id":1,"operator_name":"أحمد","receiver_name":"سالم","stitches_count":15000,"panels_count":40}'
```

---

## المرحلة 5 (منجزة): التقارير الاحترافية PDF + الاختبار النهائي

### المحتوى
- جدول `company_settings`: اسم المعمل، الهاتف، العنوان، وشعار المعمل (مخزَّن base64 ليظهر في كل التقارير).
- توليد PDF عبر **Puppeteer** (يعرض محرك Chromium النص العربي RTL بدقة كاملة دون مشاكل تشكيل الحروف الشائعة مع مكتبات PDF الأخرى).
- 4 تقارير جاهزة بتصميم موحّد (ترويسة بالشعار، بطاقات ملخص، جدول، تذييل):
  1. **كشف حساب عميل** (بالتفصيل + الرصيد الحالي)
  2. **أعلى العملاء مديونية**
  3. **حركة مخزن المواد** (وارد/صادر باسم المستخدم)
  4. **تقرير الإنتاج** (غرز/فرشات لكل مكينة وعامل)

### تشغيل مايجريشن المرحلة 5
```bash
npm install    # لتثبيت puppeteer الجديدة
npm run migrate
```

### رفع شعار المعمل (مرة واحدة من المدير)
```bash
# حوّل صورة الشعار إلى base64 أولًا، ثم:
curl -X PUT http://localhost:4000/settings \
  -H "Authorization: Bearer <ADMIN_TOKEN>" -H "Content-Type: application/json" \
  -d '{"company_name":"معمل الدحشة للتطريز","phone":"7xxxxxxxx","logo_base64":"data:image/png;base64,iVBORw0K..."}'
```

### نقاط النهاية (Endpoints) الجديدة
```
GET /settings                                قراءة إعدادات المعمل (كل المستخدمين المسجّلين)
PUT /settings                                تعديل الاسم/الشعار/بيانات التواصل (admin فقط)

GET /reports/customer/:customerId/pdf        كشف حساب عميل PDF          (admin + sales)
GET /reports/top-debtors/pdf?limit=20        أعلى المديونيات PDF         (admin + sales)
GET /reports/materials-movement/pdf          حركة المخزن PDF             (admin فقط)
    ?material_id=&from_date=&to_date=
GET /reports/production/pdf                  تقرير الإنتاج PDF           (admin فقط)
    ?machine_id=&operator_name=&from_date=&to_date=
```

### ملاحظة نشر (Deployment) على Railway
Puppeteer يحتاج حزم Chromium إضافية على السيرفر. أضف إلى إعدادات Railway (Nixpacks) هذا المتغير لتفادي مشاكل التثبيت:
```
PUPPETEER_SKIP_DOWNLOAD=false
```
وتأكد أن خطة الاستضافة تسمح بحجم ذاكرة كافٍ (Chromium يحتاج ~200-300MB إضافية أثناء توليد كل تقرير).

---

## قائمة الاختبار النهائي الشامل (قبل الاستخدام الفعلي)

- [ ] تسجيل دخول بكل الأدوار الخمسة والتأكد أن كل دور يرى شاشاته فقط
- [ ] استلام قماش → بيع جزئي → التحقق من ظهور سجل "فارغة" بالفرق الصحيح
- [ ] بيع كامل الكمية → التأكد أن لا يُنشأ سجل فارغة
- [ ] محاولة بيع كمية أكبر من المتاح → يجب أن يُرفض بخطأ واضح
- [ ] دفع نقد/آجل/جزئي → التحقق من تحديث رصيد العميل بشكل صحيح في الحالات الثلاث
- [ ] سند قبض → التحقق من نقصان رصيد العميل بنفس القيمة
- [ ] مسؤول المخزن: توريد وصرف مواد، والتأكد أنه لا يرى أي شاشة مالية
- [ ] محاولة صرف مادة بكمية أكبر من الرصيد → رفض العملية
- [ ] مشرف إنتاج: تسجيل إنتاج لمكينته فقط، ومحاولة تسجيله لمكينة أخرى (يجب الرفض)
- [ ] التأكد أن سجل الإنتاج يظهر فورًا في `hr_production_entries` بنفس التاريخ
- [ ] طباعة كل التقارير الأربعة والتأكد من ظهور الشعار والنص العربي بشكل سليم RTL
- [ ] مراجعة `user_activity_log` والتأكد أن كل عملية حساسة مسجّلة باسم منفّذها

**بهذا تكتمل المراحل الخمس المخطط لها بالكامل.** الخطوة التالية المقترحة: البدء في ربط تطبيق فلاتر بهذه الـ APIs شاشة بشاشة، بنفس الترتيب.
