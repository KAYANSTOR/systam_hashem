-- المرحلة 3: مخزن مواد المعمل (خرز، خيط، زيت...)

CREATE TYPE material_unit AS ENUM ('kg', 'piece');
CREATE TYPE material_transaction_type AS ENUM ('in', 'out');

CREATE TABLE IF NOT EXISTS materials (
  id SERIAL PRIMARY KEY,
  name VARCHAR(150) UNIQUE NOT NULL,
  unit material_unit NOT NULL,
  current_quantity DECIMAL(10,2) NOT NULL DEFAULT 0,
  min_alert_qty DECIMAL(10,2) DEFAULT 0,
  created_by INTEGER REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS material_transactions (
  id SERIAL PRIMARY KEY,
  material_id INTEGER NOT NULL REFERENCES materials(id) ON DELETE RESTRICT,
  type material_transaction_type NOT NULL,
  quantity DECIMAL(10,2) NOT NULL,
  user_id INTEGER NOT NULL REFERENCES users(id),
  transaction_date DATE NOT NULL DEFAULT CURRENT_DATE,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_material_tx_material ON material_transactions(material_id);
CREATE INDEX IF NOT EXISTS idx_material_tx_user ON material_transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_material_tx_date ON material_transactions(transaction_date);
