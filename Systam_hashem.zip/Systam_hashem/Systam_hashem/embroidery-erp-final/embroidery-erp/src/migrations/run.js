/**
 * تشغيل ملفات SQL في هذا المجلد بالترتيب الأبجدي.
 * الاستخدام: npm run migrate
 */
const fs = require('fs');
const path = require('path');
const pool = require('../config/db');

async function runMigrations() {
  const dir = __dirname;
  const files = fs
    .readdirSync(dir)
    .filter((f) => f.endsWith('.sql'))
    .sort();

  for (const file of files) {
    const sql = fs.readFileSync(path.join(dir, file), 'utf8');
    console.log(`تنفيذ: ${file} ...`);
    try {
      await pool.query(sql);
      console.log(`✔ تم بنجاح: ${file}`);
    } catch (err) {
      console.error(`✘ فشل تنفيذ ${file}:`, err.message);
      process.exit(1);
    }
  }

  console.log('تم تنفيذ جميع ملفات المايجريشن.');
  await pool.end();
}

runMigrations();
