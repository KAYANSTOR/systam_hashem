-- المرحلة 4: الإنتاج (مكائن + سجلات إنتاج) + ترحيل تلقائي لنظام الموظفين

CREATE TABLE IF NOT EXISTS machines (
  id SERIAL PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  code VARCHAR(50) UNIQUE,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_by INTEGER REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- من يملك صلاحية تسجيل إنتاج مكينة معينة
CREATE TABLE IF NOT EXISTS machine_assignments (
  id SERIAL PRIMARY KEY,
  machine_id INTEGER NOT NULL REFERENCES machines(id) ON DELETE CASCADE,
  operator_name VARCHAR(150), -- اسم العامل المعتاد على المكينة (نصي، اختياري)
  assigned_to_user_id INTEGER NOT NULL REFERENCES users(id),
  assigned_by INTEGER REFERENCES users(id),
  assignment_date DATE NOT NULL DEFAULT CURRENT_DATE,
  is_active BOOLEAN NOT NULL DEFAULT true,
  UNIQUE (machine_id, assigned_to_user_id)
);

CREATE TABLE IF NOT EXISTS production_records (
  id SERIAL PRIMARY KEY,
  machine_id INTEGER NOT NULL REFERENCES machines(id),
  operator_name VARCHAR(150) NOT NULL,   -- من اشتغل على المكينة
  receiver_name VARCHAR(150) NOT NULL,   -- مستلم المكينة
  stitches_count INTEGER NOT NULL,        -- عدد الغرز
  panels_count INTEGER NOT NULL,          -- عدد الفرشات
  work_date DATE NOT NULL DEFAULT CURRENT_DATE,
  shift VARCHAR(30),
  created_by INTEGER NOT NULL REFERENCES users(id),
  posted_to_hr BOOLEAN NOT NULL DEFAULT false,
  hr_reference_id INTEGER,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- جدول استقبال بيانات الإنتاج في نظام الموظفين/الرواتب
CREATE TABLE IF NOT EXISTS hr_production_entries (
  id SERIAL PRIMARY KEY,
  production_record_id INTEGER NOT NULL REFERENCES production_records(id) ON DELETE CASCADE,
  employee_name VARCHAR(150) NOT NULL,
  stitches_count INTEGER NOT NULL,
  panels_count INTEGER NOT NULL,
  entry_date DATE NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_assignments_user ON machine_assignments(assigned_to_user_id);
CREATE INDEX IF NOT EXISTS idx_production_machine ON production_records(machine_id);
CREATE INDEX IF NOT EXISTS idx_production_date ON production_records(work_date);
CREATE INDEX IF NOT EXISTS idx_hr_entries_date ON hr_production_entries(entry_date);
