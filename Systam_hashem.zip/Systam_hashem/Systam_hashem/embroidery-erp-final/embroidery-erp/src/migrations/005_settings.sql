-- المرحلة 5: إعدادات المعمل المستخدمة في ترويسة التقارير (اسم، شعار، بيانات تواصل)

CREATE TABLE IF NOT EXISTS company_settings (
  id INTEGER PRIMARY KEY DEFAULT 1,
  company_name VARCHAR(200) NOT NULL DEFAULT 'معمل التطريز',
  phone VARCHAR(30),
  address VARCHAR(255),
  logo_base64 TEXT, -- صورة الشعار مُخزَّنة كـ base64 (data URL) لتضمينها مباشرة في التقارير
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT single_row CHECK (id = 1)
);

INSERT INTO company_settings (id, company_name)
VALUES (1, 'معمل التطريز')
ON CONFLICT (id) DO NOTHING;
