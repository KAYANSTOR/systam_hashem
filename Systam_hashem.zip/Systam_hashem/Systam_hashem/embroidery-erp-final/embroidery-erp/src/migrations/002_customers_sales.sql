-- المرحلة 2: العملاء + مخزون أقمشة الزبائن + إشعارات البيع + سندات القبض

CREATE TABLE IF NOT EXISTS customers (
  id SERIAL PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  phone VARCHAR(30),
  address VARCHAR(255),
  notes TEXT,
  balance DECIMAL(12,2) NOT NULL DEFAULT 0, -- موجب = دين على العميل
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS customer_fabrics (
  id SERIAL PRIMARY KEY,
  customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  fabric_type VARCHAR(150) NOT NULL,
  rolls_count INTEGER, -- عدد الطيقان
  total_yards DECIMAL(10,2) NOT NULL,
  remaining_yards DECIMAL(10,2) NOT NULL,
  is_leftover BOOLEAN NOT NULL DEFAULT false, -- قماش متبقي (فارغة)
  parent_fabric_id INTEGER REFERENCES customer_fabrics(id) ON DELETE SET NULL,
  received_date DATE NOT NULL DEFAULT CURRENT_DATE,
  received_by INTEGER REFERENCES users(id),
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TYPE payment_type AS ENUM ('cash', 'credit', 'partial');

CREATE TABLE IF NOT EXISTS sales_invoices (
  id SERIAL PRIMARY KEY,
  invoice_no VARCHAR(30) UNIQUE NOT NULL,
  customer_id INTEGER NOT NULL REFERENCES customers(id),
  fabric_id INTEGER NOT NULL REFERENCES customer_fabrics(id),
  yards_sold DECIMAL(10,2) NOT NULL,
  price_per_yard DECIMAL(10,2) NOT NULL,
  total_amount DECIMAL(12,2) NOT NULL,
  paid_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  remaining_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  payment_type payment_type NOT NULL,
  invoice_date DATE NOT NULL DEFAULT CURRENT_DATE,
  created_by INTEGER REFERENCES users(id),
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS receipts (
  id SERIAL PRIMARY KEY,
  receipt_no VARCHAR(30) UNIQUE NOT NULL,
  customer_id INTEGER NOT NULL REFERENCES customers(id),
  amount DECIMAL(12,2) NOT NULL,
  receipt_date DATE NOT NULL DEFAULT CURRENT_DATE,
  notes TEXT,
  created_by INTEGER REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TYPE transaction_type AS ENUM ('sale', 'receipt');

CREATE TABLE IF NOT EXISTS customer_transactions (
  id SERIAL PRIMARY KEY,
  customer_id INTEGER NOT NULL REFERENCES customers(id),
  type transaction_type NOT NULL,
  reference_id INTEGER NOT NULL, -- يشير لـ sales_invoices.id أو receipts.id حسب type
  amount DECIMAL(12,2) NOT NULL,
  balance_after DECIMAL(12,2) NOT NULL,
  notes TEXT,
  created_by INTEGER REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_fabrics_customer ON customer_fabrics(customer_id);
CREATE INDEX IF NOT EXISTS idx_invoices_customer ON sales_invoices(customer_id);
CREATE INDEX IF NOT EXISTS idx_receipts_customer ON receipts(customer_id);
CREATE INDEX IF NOT EXISTS idx_transactions_customer ON customer_transactions(customer_id);
