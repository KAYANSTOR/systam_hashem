const express = require('express');
const cors = require('cors');
const errorHandler = require('./middlewares/errorHandler');

const authRoutes = require('./modules/auth/auth.routes');
const usersRoutes = require('./modules/users/users.routes');
const customersRoutes = require('./modules/customers/customers.routes');
const fabricsRoutes = require('./modules/fabrics/fabrics.routes');
const salesRoutes = require('./modules/sales/sales.routes');
const receiptsRoutes = require('./modules/receipts/receipts.routes');
const materialsRoutes = require('./modules/materials/materials.routes');
const productionRoutes = require('./modules/production/production.routes');
const settingsRoutes = require('./modules/settings/settings.routes');
const reportsRoutes = require('./modules/reports/reports.routes');

const app = express();

app.use(cors());
app.use(express.json({ limit: '5mb' })); // limit أعلى لاستيعاب شعار المعمل كـ base64

app.get('/health', (req, res) => res.json({ status: 'ok' }));

app.use('/auth', authRoutes);
app.use('/users', usersRoutes);
app.use('/customers', customersRoutes);
app.use('/fabrics', fabricsRoutes);
app.use('/sales', salesRoutes);
app.use('/receipts', receiptsRoutes);
app.use('/materials', materialsRoutes);
app.use('/production', productionRoutes);
app.use('/settings', settingsRoutes);
app.use('/reports', reportsRoutes);

// معالج الأخطاء يجب أن يكون آخر middleware
app.use(errorHandler);

module.exports = app;
