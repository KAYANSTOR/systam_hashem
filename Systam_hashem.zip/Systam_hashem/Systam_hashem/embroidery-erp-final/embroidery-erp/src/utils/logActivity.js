const pool = require('../config/db');

/**
 * تسجيل عملية في سجل التدقيق (Audit Log)
 * @param {number} userId - معرف المستخدم المنفّذ
 * @param {string} action - مثال: 'create', 'update', 'delete', 'login'
 * @param {string} module - مثال: 'users', 'materials', 'sales'
 * @param {number|null} referenceId - معرف السجل المتأثر
 * @param {object} details - أي تفاصيل إضافية تُحفظ كـ JSON
 */
async function logActivity(userId, action, module, referenceId = null, details = {}) {
  await pool.query(
    `INSERT INTO user_activity_log (user_id, action, module, reference_id, details_json)
     VALUES ($1, $2, $3, $4, $5)`,
    [userId, action, module, referenceId, details]
  );
}

module.exports = logActivity;
