// يغلف أي دالة async ويمرر الأخطاء تلقائيًا إلى errorHandler
module.exports = (fn) => (req, res, next) => {
  Promise.resolve(fn(req, res, next)).catch(next);
};
