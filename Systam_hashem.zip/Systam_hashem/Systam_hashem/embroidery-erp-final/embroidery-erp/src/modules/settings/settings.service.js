const pool = require('../../config/db');

async function getSettings() {
  const { rows } = await pool.query(`SELECT * FROM company_settings WHERE id = 1`);
  return rows[0];
}

async function updateSettings({ company_name, phone, address, logo_base64 }) {
  const { rows } = await pool.query(
    `UPDATE company_settings SET
       company_name = COALESCE($1, company_name),
       phone = COALESCE($2, phone),
       address = COALESCE($3, address),
       logo_base64 = COALESCE($4, logo_base64),
       updated_at = now()
     WHERE id = 1
     RETURNING *`,
    [company_name, phone, address, logo_base64]
  );
  return rows[0];
}

module.exports = { getSettings, updateSettings };
