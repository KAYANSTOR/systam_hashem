const asyncHandler = require('../../utils/asyncHandler');
const logActivity = require('../../utils/logActivity');
const settingsService = require('./settings.service');

const getSettings = asyncHandler(async (req, res) => {
  const settings = await settingsService.getSettings();
  res.json(settings);
});

const updateSettings = asyncHandler(async (req, res) => {
  const { company_name, phone, address, logo_base64 } = req.body;
  const settings = await settingsService.updateSettings({ company_name, phone, address, logo_base64 });
  await logActivity(req.user.id, 'update', 'company_settings', 1);
  res.json(settings);
});

module.exports = { getSettings, updateSettings };
