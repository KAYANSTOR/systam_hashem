const express = require('express');
const authenticate = require('../../middlewares/auth');
const roleGuard = require('../../middlewares/roleGuard');
const { getSettings, updateSettings } = require('./settings.controller');

const router = express.Router();

router.use(authenticate);

// أي مستخدم مسجّل دخول يمكنه قراءة الإعدادات (لعرض الشعار في التطبيق)
router.get('/', getSettings);

// التعديل (اسم المعمل، الشعار، بيانات التواصل) للمدير فقط
router.put('/', roleGuard(['admin']), updateSettings);

module.exports = router;
