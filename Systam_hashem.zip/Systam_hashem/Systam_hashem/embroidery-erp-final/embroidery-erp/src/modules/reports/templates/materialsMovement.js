const { baseLayout } = require('./baseLayout');

function materialsMovementTemplate({ settings, movements, from_date, to_date }) {
  const totalIn = movements.filter((m) => m.type === 'in').reduce((s, m) => s + Number(m.quantity), 0);
  const totalOut = movements.filter((m) => m.type === 'out').reduce((s, m) => s + Number(m.quantity), 0);

  const rows = movements
    .map((m) => {
      const typeLabel = m.type === 'in' ? 'دخول (توريد)' : 'خروج (صرف)';
      const cls = m.type === 'in' ? 'credit' : 'debit';
      const date = new Date(m.transaction_date).toLocaleDateString('ar-EG');
      return `
        <tr>
          <td>${date}</td>
          <td>${m.material_name}</td>
          <td class="${cls}">${typeLabel}</td>
          <td>${Number(m.quantity).toLocaleString()} ${m.unit}</td>
          <td>${m.user_name}</td>
          <td>${m.notes || '-'}</td>
        </tr>`;
    })
    .join('');

  const period = from_date || to_date
    ? `الفترة: ${from_date || '...'} إلى ${to_date || '...'}`
    : 'كل الفترات';

  const bodyHtml = `
    <div class="summary-box">
      <div class="summary-card"><div class="label">إجمالي الوارد</div><div class="value credit">${totalIn.toLocaleString()}</div></div>
      <div class="summary-card"><div class="label">إجمالي الصادر</div><div class="value debit">${totalOut.toLocaleString()}</div></div>
      <div class="summary-card"><div class="label">عدد الحركات</div><div class="value">${movements.length}</div></div>
    </div>

    <table>
      <thead>
        <tr><th>التاريخ</th><th>المادة</th><th>نوع الحركة</th><th>الكمية</th><th>المستخدم</th><th>ملاحظات</th></tr>
      </thead>
      <tbody>
        ${rows || '<tr><td colspan="6">لا توجد حركات في هذه الفترة</td></tr>'}
      </tbody>
    </table>`;

  return baseLayout({
    settings,
    title: 'تقرير حركة مخزن المواد',
    subtitle: period,
    bodyHtml,
  });
}

module.exports = materialsMovementTemplate;
