const puppeteer = require('puppeteer');
const settingsService = require('../settings/settings.service');
const customersService = require('../customers/customers.service');
const materialsService = require('../materials/materials.service');
const productionService = require('../production/production.service');

const customerStatementTemplate = require('./templates/customerStatement');
const topDebtorsTemplate = require('./templates/topDebtors');
const materialsMovementTemplate = require('./templates/materialsMovement');
const productionReportTemplate = require('./templates/production');

/**
 * يحوّل أي HTML جاهز إلى PDF (Buffer) بصفحة A4.
 * Puppeteer يستخدم محرك Chromium فيعرض النص العربي RTL بشكل صحيح دون الحاجة لخطوط خاصة.
 */
async function htmlToPdfBuffer(html) {
  const browser = await puppeteer.launch({
    headless: 'new',
    args: ['--no-sandbox', '--disable-setuid-sandbox'],
  });

  try {
    const page = await browser.newPage();
    await page.setContent(html, { waitUntil: 'networkidle0' });
    const pdfBuffer = await page.pdf({
      format: 'A4',
      printBackground: true,
      margin: { top: '20px', bottom: '20px', left: '20px', right: '20px' },
    });
    return pdfBuffer;
  } finally {
    await browser.close();
  }
}

async function generateCustomerStatementPdf(customerId) {
  const settings = await settingsService.getSettings();
  const { customer, transactions } = await customersService.getCustomerStatement(customerId);
  const html = customerStatementTemplate({ settings, customer, transactions });
  return htmlToPdfBuffer(html);
}

async function generateTopDebtorsPdf(limit) {
  const settings = await settingsService.getSettings();
  const debtors = await customersService.listTopDebtors(limit);
  const html = topDebtorsTemplate({ settings, debtors });
  return htmlToPdfBuffer(html);
}

async function generateMaterialsMovementPdf({ material_id, from_date, to_date }) {
  const settings = await settingsService.getSettings();
  const movements = await materialsService.listMovements({ material_id, from_date, to_date });
  const html = materialsMovementTemplate({ settings, movements, from_date, to_date });
  return htmlToPdfBuffer(html);
}

async function generateProductionPdf({ machine_id, operator_name, from_date, to_date }) {
  const settings = await settingsService.getSettings();
  const records = await productionService.listProductionRecords({ machine_id, operator_name, from_date, to_date });
  const html = productionReportTemplate({ settings, records, from_date, to_date });
  return htmlToPdfBuffer(html);
}

module.exports = {
  generateCustomerStatementPdf,
  generateTopDebtorsPdf,
  generateMaterialsMovementPdf,
  generateProductionPdf,
};
