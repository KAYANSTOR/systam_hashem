const { baseLayout } = require('./baseLayout');

function customerStatementTemplate({ settings, customer, transactions }) {
  const rows = transactions
    .map((t) => {
      const typeLabel = t.type === 'sale' ? 'إشعار بيع' : 'سند قبض';
      const amountClass = t.type === 'sale' ? 'debit' : 'credit';
      const sign = t.type === 'sale' ? '+' : '-';
      const date = new Date(t.created_at).toLocaleDateString('ar-EG');
      return `
        <tr>
          <td>${date}</td>
          <td>${typeLabel}</td>
          <td>${t.notes || '-'}</td>
          <td class="${amountClass}">${sign}${Number(t.amount).toLocaleString()}</td>
          <td>${Number(t.balance_after).toLocaleString()}</td>
        </tr>`;
    })
    .join('');

  const bodyHtml = `
    <div class="summary-box">
      <div class="summary-card">
        <div class="label">اسم العميل</div>
        <div class="value">${customer.name}</div>
      </div>
      <div class="summary-card">
        <div class="label">الهاتف</div>
        <div class="value">${customer.phone || '-'}</div>
      </div>
      <div class="summary-card">
        <div class="label">الرصيد الحالي (المستحق)</div>
        <div class="value debit">${Number(customer.balance).toLocaleString()}</div>
      </div>
    </div>

    <table>
      <thead>
        <tr>
          <th>التاريخ</th>
          <th>نوع العملية</th>
          <th>البيان</th>
          <th>المبلغ</th>
          <th>الرصيد بعد العملية</th>
        </tr>
      </thead>
      <tbody>
        ${rows || '<tr><td colspan="5">لا توجد حركات مسجلة لهذا العميل</td></tr>'}
      </tbody>
    </table>`;

  return baseLayout({
    settings,
    title: 'كشف حساب عميل',
    subtitle: `تاريخ الإصدار: ${new Date().toLocaleDateString('ar-EG')}`,
    bodyHtml,
  });
}

module.exports = customerStatementTemplate;
