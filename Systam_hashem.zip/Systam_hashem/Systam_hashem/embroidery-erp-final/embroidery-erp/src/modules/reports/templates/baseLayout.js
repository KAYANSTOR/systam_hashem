/**
 * يبني الإطار العام (Layout) لأي تقرير: ترويسة بشعار المعمل + تذييل + أنماط CSS مشتركة.
 * كل تقرير يمرر عنوانه ومحتواه الداخلي (HTML) فقط.
 */
function baseLayout({ settings, title, subtitle, bodyHtml }) {
  const logoImg = settings?.logo_base64
    ? `<img src="${settings.logo_base64}" class="logo" />`
    : '';

  return `
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8" />
<style>
  * { box-sizing: border-box; }
  body {
    font-family: 'Segoe UI', Tahoma, Arial, sans-serif;
    direction: rtl;
    color: #1f2937;
    margin: 0;
    padding: 30px 40px;
  }
  .header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 3px solid #E31E24;
    padding-bottom: 14px;
    margin-bottom: 20px;
  }
  .company-info { text-align: right; }
  .company-name { font-size: 20px; font-weight: bold; color: #0F172A; margin: 0; }
  .company-meta { font-size: 11px; color: #6b7280; margin-top: 4px; }
  .logo { max-height: 60px; max-width: 140px; }
  .report-title { font-size: 17px; font-weight: bold; margin: 10px 0 2px; color: #0F172A; }
  .report-subtitle { font-size: 12px; color: #6b7280; margin-bottom: 16px; }
  table { width: 100%; border-collapse: collapse; font-size: 12px; margin-top: 8px; }
  th, td { border: 1px solid #e5e7eb; padding: 8px 10px; text-align: center; }
  th { background: #0F172A; color: #fff; font-weight: 600; }
  tr:nth-child(even) { background: #f8fafc; }
  .summary-box {
    display: flex; gap: 14px; margin: 16px 0; flex-wrap: wrap;
  }
  .summary-card {
    border: 1px solid #e5e7eb; border-radius: 8px; padding: 10px 16px;
    background: #f8fafc; min-width: 140px;
  }
  .summary-card .label { font-size: 11px; color: #6b7280; }
  .summary-card .value { font-size: 16px; font-weight: bold; color: #0F172A; }
  .debit { color: #E31E24; font-weight: 600; }
  .credit { color: #16a34a; font-weight: 600; }
  .footer {
    margin-top: 30px; padding-top: 10px; border-top: 1px solid #e5e7eb;
    font-size: 10px; color: #9ca3af; text-align: center;
  }
</style>
</head>
<body>
  <div class="header">
    <div class="company-info">
      <p class="company-name">${settings?.company_name || 'معمل التطريز'}</p>
      <p class="company-meta">${settings?.phone || ''} ${settings?.address ? ' - ' + settings.address : ''}</p>
    </div>
    ${logoImg}
  </div>

  <div class="report-title">${title}</div>
  ${subtitle ? `<div class="report-subtitle">${subtitle}</div>` : ''}

  ${bodyHtml}

  <div class="footer">تم إصدار هذا التقرير آليًا من نظام إدارة المعمل — ${new Date().toLocaleDateString('ar-EG')}</div>
</body>
</html>`;
}

module.exports = { baseLayout };
