const { baseLayout } = require('./baseLayout');

function topDebtorsTemplate({ settings, debtors }) {
  const totalDebt = debtors.reduce((sum, d) => sum + Number(d.balance), 0);

  const rows = debtors
    .map(
      (d, i) => `
        <tr>
          <td>${i + 1}</td>
          <td>${d.name}</td>
          <td>${d.phone || '-'}</td>
          <td class="debit">${Number(d.balance).toLocaleString()}</td>
        </tr>`
    )
    .join('');

  const bodyHtml = `
    <div class="summary-box">
      <div class="summary-card">
        <div class="label">عدد العملاء المدينين</div>
        <div class="value">${debtors.length}</div>
      </div>
      <div class="summary-card">
        <div class="label">إجمالي المديونيات</div>
        <div class="value debit">${totalDebt.toLocaleString()}</div>
      </div>
    </div>

    <table>
      <thead>
        <tr><th>#</th><th>اسم العميل</th><th>الهاتف</th><th>الرصيد المستحق</th></tr>
      </thead>
      <tbody>
        ${rows || '<tr><td colspan="4">لا يوجد عملاء عليهم مديونية حاليًا</td></tr>'}
      </tbody>
    </table>`;

  return baseLayout({
    settings,
    title: 'تقرير أعلى العملاء مديونية',
    subtitle: `تاريخ الإصدار: ${new Date().toLocaleDateString('ar-EG')}`,
    bodyHtml,
  });
}

module.exports = topDebtorsTemplate;
