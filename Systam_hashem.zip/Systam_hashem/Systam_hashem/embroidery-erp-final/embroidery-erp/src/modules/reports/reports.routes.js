const express = require('express');
const authenticate = require('../../middlewares/auth');
const roleGuard = require('../../middlewares/roleGuard');
const {
  customerStatementPdf, topDebtorsPdf, materialsMovementPdf, productionPdf,
} = require('./reports.controller');

const router = express.Router();

router.use(authenticate, roleGuard(['admin', 'sales']));

router.get('/customer/:customerId/pdf', customerStatementPdf);
router.get('/top-debtors/pdf', topDebtorsPdf);

// تقارير المخزون والإنتاج أدق ماليًا/تشغيليًا - نقيّدها للمدير فقط
router.get('/materials-movement/pdf', roleGuard(['admin']), materialsMovementPdf);
router.get('/production/pdf', roleGuard(['admin']), productionPdf);

module.exports = router;
