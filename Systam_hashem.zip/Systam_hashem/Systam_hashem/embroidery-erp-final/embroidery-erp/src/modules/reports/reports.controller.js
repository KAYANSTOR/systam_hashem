const asyncHandler = require('../../utils/asyncHandler');
const reportsService = require('./reports.service');

function sendPdf(res, buffer, filename) {
  res.set({
    'Content-Type': 'application/pdf',
    'Content-Disposition': `inline; filename="${filename}"`,
  });
  res.send(buffer);
}

const customerStatementPdf = asyncHandler(async (req, res) => {
  const buffer = await reportsService.generateCustomerStatementPdf(req.params.customerId);
  sendPdf(res, buffer, `customer-statement-${req.params.customerId}.pdf`);
});

const topDebtorsPdf = asyncHandler(async (req, res) => {
  const limit = parseInt(req.query.limit, 10) || 20;
  const buffer = await reportsService.generateTopDebtorsPdf(limit);
  sendPdf(res, buffer, 'top-debtors.pdf');
});

const materialsMovementPdf = asyncHandler(async (req, res) => {
  const { material_id, from_date, to_date } = req.query;
  const buffer = await reportsService.generateMaterialsMovementPdf({ material_id, from_date, to_date });
  sendPdf(res, buffer, 'materials-movement.pdf');
});

const productionPdf = asyncHandler(async (req, res) => {
  const { machine_id, operator_name, from_date, to_date } = req.query;
  const buffer = await reportsService.generateProductionPdf({ machine_id, operator_name, from_date, to_date });
  sendPdf(res, buffer, 'production-report.pdf');
});

module.exports = { customerStatementPdf, topDebtorsPdf, materialsMovementPdf, productionPdf };
