const { baseLayout } = require('./baseLayout');

function productionReportTemplate({ settings, records, from_date, to_date }) {
  const totalStitches = records.reduce((s, r) => s + Number(r.stitches_count), 0);
  const totalPanels = records.reduce((s, r) => s + Number(r.panels_count), 0);

  const rows = records
    .map((r) => {
      const date = new Date(r.work_date).toLocaleDateString('ar-EG');
      return `
        <tr>
          <td>${date}</td>
          <td>${r.machine_name}</td>
          <td>${r.operator_name}</td>
          <td>${r.receiver_name}</td>
          <td>${Number(r.stitches_count).toLocaleString()}</td>
          <td>${Number(r.panels_count).toLocaleString()}</td>
        </tr>`;
    })
    .join('');

  const period = from_date || to_date
    ? `الفترة: ${from_date || '...'} إلى ${to_date || '...'}`
    : 'كل الفترات';

  const bodyHtml = `
    <div class="summary-box">
      <div class="summary-card"><div class="label">إجمالي الغرز</div><div class="value">${totalStitches.toLocaleString()}</div></div>
      <div class="summary-card"><div class="label">إجمالي الفرشات</div><div class="value">${totalPanels.toLocaleString()}</div></div>
      <div class="summary-card"><div class="label">عدد السجلات</div><div class="value">${records.length}</div></div>
    </div>

    <table>
      <thead>
        <tr><th>التاريخ</th><th>المكينة</th><th>من اشتغل</th><th>مستلم المكينة</th><th>الغرز</th><th>الفرشات</th></tr>
      </thead>
      <tbody>
        ${rows || '<tr><td colspan="6">لا توجد سجلات إنتاج في هذه الفترة</td></tr>'}
      </tbody>
    </table>`;

  return baseLayout({
    settings,
    title: 'تقرير الإنتاج',
    subtitle: period,
    bodyHtml,
  });
}

module.exports = productionReportTemplate;
