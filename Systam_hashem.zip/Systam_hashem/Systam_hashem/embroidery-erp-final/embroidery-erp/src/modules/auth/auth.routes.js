const express = require('express');
const { loginHandler } = require('./auth.controller');

const router = express.Router();

// POST /auth/login
router.post('/login', loginHandler);

module.exports = router;
