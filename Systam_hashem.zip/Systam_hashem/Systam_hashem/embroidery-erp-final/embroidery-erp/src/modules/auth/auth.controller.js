const asyncHandler = require('../../utils/asyncHandler');
const logActivity = require('../../utils/logActivity');
const authService = require('./auth.service');

const loginHandler = asyncHandler(async (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ message: 'اسم المستخدم وكلمة المرور مطلوبان' });
  }

  const result = await authService.login(username, password);
  await logActivity(result.user.id, 'login', 'auth');

  res.json(result);
});

module.exports = { loginHandler };
