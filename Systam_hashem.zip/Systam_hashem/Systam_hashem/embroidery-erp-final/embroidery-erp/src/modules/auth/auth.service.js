const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const pool = require('../../config/db');
const env = require('../../config/env');

async function login(username, password) {
  const { rows } = await pool.query(
    `SELECT id, full_name, username, password_hash, role, is_active
     FROM users WHERE username = $1`,
    [username]
  );

  const user = rows[0];

  if (!user || !user.is_active) {
    const err = new Error('اسم المستخدم أو كلمة المرور غير صحيحة');
    err.statusCode = 401;
    throw err;
  }

  const isMatch = await bcrypt.compare(password, user.password_hash);
  if (!isMatch) {
    const err = new Error('اسم المستخدم أو كلمة المرور غير صحيحة');
    err.statusCode = 401;
    throw err;
  }

  const token = jwt.sign(
    { id: user.id, username: user.username, role: user.role },
    env.jwtSecret,
    { expiresIn: env.jwtExpiresIn }
  );

  return {
    token,
    user: {
      id: user.id,
      full_name: user.full_name,
      username: user.username,
      role: user.role,
    },
  };
}

module.exports = { login };
