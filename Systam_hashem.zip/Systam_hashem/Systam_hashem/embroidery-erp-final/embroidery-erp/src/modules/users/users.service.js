const bcrypt = require('bcrypt');
const pool = require('../../config/db');

const VALID_ROLES = [
  'admin',
  'sales',
  'materials_manager',
  'fabric_manager',
  'production_supervisor',
];

async function listUsers() {
  const { rows } = await pool.query(
    `SELECT id, full_name, username, phone, role, is_active, created_at
     FROM users ORDER BY created_at DESC`
  );
  return rows;
}

async function createUser({ full_name, username, password, phone, role }) {
  if (!VALID_ROLES.includes(role)) {
    const err = new Error('الدور المحدد غير صالح');
    err.statusCode = 400;
    throw err;
  }

  const password_hash = await bcrypt.hash(password, 10);

  const { rows } = await pool.query(
    `INSERT INTO users (full_name, username, password_hash, phone, role)
     VALUES ($1, $2, $3, $4, $5)
     RETURNING id, full_name, username, phone, role, is_active, created_at`,
    [full_name, username, password_hash, phone, role]
  );

  return rows[0];
}

async function setUserActive(id, is_active) {
  const { rows } = await pool.query(
    `UPDATE users SET is_active = $1 WHERE id = $2
     RETURNING id, full_name, username, phone, role, is_active`,
    [is_active, id]
  );

  if (!rows[0]) {
    const err = new Error('المستخدم غير موجود');
    err.statusCode = 404;
    throw err;
  }

  return rows[0];
}

module.exports = { listUsers, createUser, setUserActive, VALID_ROLES };
