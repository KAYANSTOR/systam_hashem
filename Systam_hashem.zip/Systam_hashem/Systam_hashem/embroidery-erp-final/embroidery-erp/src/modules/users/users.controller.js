const asyncHandler = require('../../utils/asyncHandler');
const logActivity = require('../../utils/logActivity');
const usersService = require('./users.service');

const getUsers = asyncHandler(async (req, res) => {
  const users = await usersService.listUsers();
  res.json(users);
});

const createUser = asyncHandler(async (req, res) => {
  const { full_name, username, password, phone, role } = req.body;

  if (!full_name || !username || !password || !role) {
    return res.status(400).json({ message: 'جميع الحقول (الاسم، اسم المستخدم، كلمة المرور، الدور) مطلوبة' });
  }

  const user = await usersService.createUser({ full_name, username, password, phone, role });
  await logActivity(req.user.id, 'create', 'users', user.id, { username: user.username, role: user.role });

  res.status(201).json(user);
});

const toggleUserActive = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { is_active } = req.body;

  const user = await usersService.setUserActive(id, is_active);
  await logActivity(req.user.id, is_active ? 'activate' : 'deactivate', 'users', user.id);

  res.json(user);
});

module.exports = { getUsers, createUser, toggleUserActive };
