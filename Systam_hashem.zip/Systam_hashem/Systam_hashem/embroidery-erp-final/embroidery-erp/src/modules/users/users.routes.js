const express = require('express');
const authenticate = require('../../middlewares/auth');
const roleGuard = require('../../middlewares/roleGuard');
const { getUsers, createUser, toggleUserActive } = require('./users.controller');

const router = express.Router();

// كل مسارات إدارة المستخدمين تتطلب تسجيل دخول + دور admin فقط
router.use(authenticate, roleGuard(['admin']));

router.get('/', getUsers);
router.post('/', createUser);
router.patch('/:id/status', toggleUserActive);

module.exports = router;
