const express = require('express');
const authenticate = require('../../middlewares/auth');
const roleGuard = require('../../middlewares/roleGuard');
const { createReceipt } = require('./receipts.controller');

const router = express.Router();

router.use(authenticate, roleGuard(['admin', 'sales']));

router.post('/', createReceipt);

module.exports = router;
