const asyncHandler = require('../../utils/asyncHandler');
const logActivity = require('../../utils/logActivity');
const receiptsService = require('./receipts.service');

const createReceipt = asyncHandler(async (req, res) => {
  const { customer_id, amount, receipt_date, notes } = req.body;

  if (!customer_id || !amount) {
    return res.status(400).json({ message: 'العميل والمبلغ مطلوبان' });
  }

  const result = await receiptsService.createReceipt({
    customer_id, amount, receipt_date, notes, created_by: req.user.id,
  });

  await logActivity(req.user.id, 'create', 'receipts', result.receipt.id, { customer_id, amount });

  res.status(201).json(result);
});

module.exports = { createReceipt };
