const pool = require('../../config/db');

async function createReceipt({ customer_id, amount, receipt_date, notes, created_by }) {
  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    const amountNum = Number(amount);
    if (amountNum <= 0) {
      const err = new Error('مبلغ السند يجب أن يكون أكبر من صفر');
      err.statusCode = 400;
      throw err;
    }

    // التحقق من وجود العميل وقفل صف الرصيد
    const customerRes = await client.query(
      `SELECT id, balance FROM customers WHERE id = $1 FOR UPDATE`,
      [customer_id]
    );
    if (!customerRes.rows[0]) {
      const err = new Error('العميل غير موجود');
      err.statusCode = 404;
      throw err;
    }

    const receiptNo = `RCT-${Date.now()}`;
    const receiptRes = await client.query(
      `INSERT INTO receipts (receipt_no, customer_id, amount, receipt_date, notes, created_by)
       VALUES ($1,$2,$3,COALESCE($4, CURRENT_DATE),$5,$6) RETURNING *`,
      [receiptNo, customer_id, amountNum, receipt_date, notes, created_by]
    );
    const receipt = receiptRes.rows[0];

    // تحديث رصيد العميل (ينقص الدين)
    const updatedRes = await client.query(
      `UPDATE customers SET balance = balance - $1 WHERE id = $2 RETURNING balance`,
      [amountNum, customer_id]
    );
    const newBalance = updatedRes.rows[0].balance;

    await client.query(
      `INSERT INTO customer_transactions (customer_id, type, reference_id, amount, balance_after, notes, created_by)
       VALUES ($1, 'receipt', $2, $3, $4, $5, $6)`,
      [customer_id, receipt.id, amountNum, newBalance, `سند قبض رقم ${receiptNo}`, created_by]
    );

    await client.query('COMMIT');
    return { receipt, newBalance };
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

module.exports = { createReceipt };
