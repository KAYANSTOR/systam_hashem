const asyncHandler = require('../../utils/asyncHandler');
const logActivity = require('../../utils/logActivity');
const fabricsService = require('./fabrics.service');

const receiveFabric = asyncHandler(async (req, res) => {
  const { customer_id, fabric_type, rolls_count, total_yards, received_date, notes } = req.body;

  if (!customer_id || !fabric_type || !total_yards) {
    return res.status(400).json({ message: 'العميل ونوع القماش وعدد الوارات مطلوبة' });
  }

  const fabric = await fabricsService.receiveFabric({
    customer_id,
    fabric_type,
    rolls_count,
    total_yards,
    received_date,
    notes,
    received_by: req.user.id,
  });

  await logActivity(req.user.id, 'receive_fabric', 'fabrics', fabric.id, {
    customer_id,
    total_yards,
  });

  res.status(201).json(fabric);
});

const getAvailableForCustomer = asyncHandler(async (req, res) => {
  const fabrics = await fabricsService.listAvailableFabricsForCustomer(req.params.customerId);
  res.json(fabrics);
});

module.exports = { receiveFabric, getAvailableForCustomer };
