const pool = require('../../config/db');

async function receiveFabric({ customer_id, fabric_type, rolls_count, total_yards, received_date, notes, received_by }) {
  const { rows } = await pool.query(
    `INSERT INTO customer_fabrics
      (customer_id, fabric_type, rolls_count, total_yards, remaining_yards, received_date, notes, received_by)
     VALUES ($1, $2, $3, $4, $4, COALESCE($5, CURRENT_DATE), $6, $7)
     RETURNING *`,
    [customer_id, fabric_type, rolls_count, total_yards, received_date, notes, received_by]
  );
  return rows[0];
}

/**
 * يعرض دفعات القماش المتاحة (رصيد متبقٍ > 0) لعميل معين
 * تُستخدم عند إصدار إشعار بيع لاختيار الدفعة
 */
async function listAvailableFabricsForCustomer(customerId) {
  const { rows } = await pool.query(
    `SELECT id, fabric_type, rolls_count, total_yards, remaining_yards,
            is_leftover, parent_fabric_id, received_date, notes
     FROM customer_fabrics
     WHERE customer_id = $1 AND remaining_yards > 0
     ORDER BY received_date ASC`,
    [customerId]
  );
  return rows;
}

async function getFabricById(id, client = pool) {
  const { rows } = await client.query(`SELECT * FROM customer_fabrics WHERE id = $1 FOR UPDATE`, [id]);
  if (!rows[0]) {
    const err = new Error('دفعة القماش غير موجودة');
    err.statusCode = 404;
    throw err;
  }
  return rows[0];
}

module.exports = { receiveFabric, listAvailableFabricsForCustomer, getFabricById };
