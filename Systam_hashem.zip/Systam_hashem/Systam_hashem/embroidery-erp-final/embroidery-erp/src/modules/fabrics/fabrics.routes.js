const express = require('express');
const authenticate = require('../../middlewares/auth');
const roleGuard = require('../../middlewares/roleGuard');
const { receiveFabric, getAvailableForCustomer } = require('./fabrics.controller');

const router = express.Router();

router.use(authenticate, roleGuard(['admin', 'sales', 'fabric_manager']));

router.post('/receive', receiveFabric);
router.get('/customer/:customerId', getAvailableForCustomer);

module.exports = router;
