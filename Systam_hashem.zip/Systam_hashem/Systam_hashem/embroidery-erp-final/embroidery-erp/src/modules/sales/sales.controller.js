const asyncHandler = require('../../utils/asyncHandler');
const logActivity = require('../../utils/logActivity');
const salesService = require('./sales.service');

const createInvoice = asyncHandler(async (req, res) => {
  const {
    customer_id, fabric_id, yards_sold, price_per_yard,
    payment_type, paid_amount, invoice_date, notes,
  } = req.body;

  if (!customer_id || !fabric_id || !yards_sold || !price_per_yard || !payment_type) {
    return res.status(400).json({
      message: 'العميل، دفعة القماش، عدد الوارات، سعر الوار، وطريقة الدفع كلها مطلوبة',
    });
  }

  const result = await salesService.createSalesInvoice({
    customer_id, fabric_id, yards_sold, price_per_yard,
    payment_type, paid_amount, invoice_date, notes,
    created_by: req.user.id,
  });

  await logActivity(req.user.id, 'create', 'sales_invoices', result.invoice.id, {
    customer_id, total_amount: result.invoice.total_amount,
  });

  res.status(201).json(result);
});

module.exports = { createInvoice };
