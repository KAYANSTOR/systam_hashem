const express = require('express');
const authenticate = require('../../middlewares/auth');
const roleGuard = require('../../middlewares/roleGuard');
const { createInvoice } = require('./sales.controller');

const router = express.Router();

router.use(authenticate, roleGuard(['admin', 'sales']));

router.post('/invoice', createInvoice);

module.exports = router;
