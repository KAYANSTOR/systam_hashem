const pool = require('../../config/db');

/**
 * إنشاء إشعار بيع:
 * 1) يقفل سجل دفعة القماش (FOR UPDATE) لمنع تعارض العمليات المتزامنة.
 * 2) يتحقق أن الوارات المطلوبة <= الرصيد المتاح.
 * 3) يخصم الكمية، وإن تبقّى رصيد ينشئ سجل قماش جديد بحالة "فارغة" (غير مشتغل عليها).
 * 4) يحسب المبلغ ويحدّث رصيد العميل حسب طريقة الدفع.
 * 5) يسجل حركة في customer_transactions.
 * كل ذلك ضمن Transaction واحدة لضمان تطابق الأرصدة.
 */
async function createSalesInvoice({
  customer_id,
  fabric_id,
  yards_sold,
  price_per_yard,
  payment_type, // 'cash' | 'credit' | 'partial'
  paid_amount = 0,
  invoice_date,
  notes,
  created_by,
}) {
  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    // 1) قفل دفعة القماش
    const fabricRes = await client.query(
      `SELECT * FROM customer_fabrics WHERE id = $1 AND customer_id = $2 FOR UPDATE`,
      [fabric_id, customer_id]
    );
    const fabric = fabricRes.rows[0];

    if (!fabric) {
      const err = new Error('دفعة القماش غير موجودة لهذا العميل');
      err.statusCode = 404;
      throw err;
    }

    const yardsSoldNum = Number(yards_sold);
    const remainingNum = Number(fabric.remaining_yards);

    if (yardsSoldNum <= 0) {
      const err = new Error('عدد الوارات يجب أن يكون أكبر من صفر');
      err.statusCode = 400;
      throw err;
    }

    if (yardsSoldNum > remainingNum) {
      const err = new Error(
        `الكمية المطلوبة (${yardsSoldNum}) أكبر من الرصيد المتاح (${remainingNum}) لهذه الدفعة`
      );
      err.statusCode = 400;
      throw err;
    }

    // 2) حساب المبلغ الإجمالي
    const totalAmount = Number((yardsSoldNum * Number(price_per_yard)).toFixed(2));

    let finalPaidAmount = 0;
    if (payment_type === 'cash') {
      finalPaidAmount = totalAmount;
    } else if (payment_type === 'credit') {
      finalPaidAmount = 0;
    } else if (payment_type === 'partial') {
      finalPaidAmount = Number(paid_amount) || 0;
      if (finalPaidAmount > totalAmount) {
        const err = new Error('المبلغ المدفوع لا يمكن أن يتجاوز إجمالي الفاتورة');
        err.statusCode = 400;
        throw err;
      }
    } else {
      const err = new Error('طريقة الدفع غير صالحة');
      err.statusCode = 400;
      throw err;
    }

    const remainingAmount = Number((totalAmount - finalPaidAmount).toFixed(2));

    // 3) خصم الكمية من دفعة القماش
    const newRemainingYards = Number((remainingNum - yardsSoldNum).toFixed(2));
    await client.query(
      `UPDATE customer_fabrics SET remaining_yards = $1 WHERE id = $2`,
      [newRemainingYards, fabric_id]
    );

    // 4) إن تبقّى رصيد من هذه الدفعة، أنشئ سجل قماش جديد "فارغة" غير محتسبة
    let leftoverFabric = null;
    if (newRemainingYards > 0) {
      const leftoverRes = await client.query(
        `INSERT INTO customer_fabrics
          (customer_id, fabric_type, rolls_count, total_yards, remaining_yards,
           is_leftover, parent_fabric_id, received_date, received_by, notes)
         VALUES ($1, $2, NULL, $3, $3, true, $4, CURRENT_DATE, $5, 'فارغة - قماش متبقٍ لم يُحتسب بعد')
         RETURNING *`,
        [customer_id, fabric.fabric_type, newRemainingYards, fabric.id, created_by]
      );
      leftoverFabric = leftoverRes.rows[0];
      // صفّر رصيد الدفعة الأصلية لأن المتبقي انتقل لسجل جديد مستقل
      await client.query(`UPDATE customer_fabrics SET remaining_yards = 0 WHERE id = $1`, [fabric_id]);
    }

    // 5) إنشاء رقم الفاتورة وحفظ إشعار البيع
    const invoiceNo = `INV-${Date.now()}`;
    const invoiceRes = await client.query(
      `INSERT INTO sales_invoices
        (invoice_no, customer_id, fabric_id, yards_sold, price_per_yard, total_amount,
         paid_amount, remaining_amount, payment_type, invoice_date, created_by, notes)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,COALESCE($10, CURRENT_DATE),$11,$12)
       RETURNING *`,
      [
        invoiceNo, customer_id, fabric_id, yardsSoldNum, price_per_yard, totalAmount,
        finalPaidAmount, remainingAmount, payment_type, invoice_date, created_by, notes,
      ]
    );
    const invoice = invoiceRes.rows[0];

    // 6) تحديث رصيد العميل (يزيد بمقدار المبلغ غير المدفوع)
    const customerRes = await client.query(
      `UPDATE customers SET balance = balance + $1 WHERE id = $2 RETURNING balance`,
      [remainingAmount, customer_id]
    );
    const newBalance = customerRes.rows[0].balance;

    // 7) تسجيل حركة في كشف حساب العميل
    await client.query(
      `INSERT INTO customer_transactions (customer_id, type, reference_id, amount, balance_after, notes, created_by)
       VALUES ($1, 'sale', $2, $3, $4, $5, $6)`,
      [customer_id, invoice.id, totalAmount, newBalance, `إشعار بيع رقم ${invoiceNo}`, created_by]
    );

    await client.query('COMMIT');

    return { invoice, leftoverFabric, newBalance };
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

module.exports = { createSalesInvoice };
