const express = require('express');
const authenticate = require('../../middlewares/auth');
const roleGuard = require('../../middlewares/roleGuard');
const {
  createMachine, getMachines, assignMachine, getMyMachines, createRecord, getRecords,
} = require('./production.controller');

const router = express.Router();

router.use(authenticate);

// إدارة المكائن - للمدير فقط
router.post('/machines', roleGuard(['admin']), createMachine);
router.get('/machines', roleGuard(['admin']), getMachines);

// منح صلاحية تسجيل إنتاج مكينة لمستخدم - للمدير فقط
router.post('/assign', roleGuard(['admin']), assignMachine);

// المكائن المخصصة للمستخدم الحالي (لمشرف الإنتاج)
router.get('/my-machines', roleGuard(['admin', 'production_supervisor']), getMyMachines);

// تسجيل إنتاج يومي - المدير أو مشرف الإنتاج (مقيّد بمكائنه فقط، يُتحقق داخل الكنترولر)
router.post('/record', roleGuard(['admin', 'production_supervisor']), createRecord);

// تقرير الإنتاج الكامل - للمدير فقط
router.get('/records', roleGuard(['admin']), getRecords);

module.exports = router;
