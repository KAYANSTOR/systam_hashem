const pool = require('../../config/db');

// ---------- المكائن ----------

async function createMachine({ name, code, created_by }) {
  const { rows } = await pool.query(
    `INSERT INTO machines (name, code, created_by) VALUES ($1, $2, $3) RETURNING *`,
    [name, code, created_by]
  );
  return rows[0];
}

async function listMachines() {
  const { rows } = await pool.query(`SELECT * FROM machines ORDER BY name ASC`);
  return rows;
}

// ---------- تخصيص المكائن للمستخدمين ----------

async function assignMachine({ machine_id, assigned_to_user_id, operator_name, assigned_by }) {
  const { rows } = await pool.query(
    `INSERT INTO machine_assignments (machine_id, assigned_to_user_id, operator_name, assigned_by)
     VALUES ($1, $2, $3, $4)
     ON CONFLICT (machine_id, assigned_to_user_id)
     DO UPDATE SET is_active = true, operator_name = EXCLUDED.operator_name
     RETURNING *`,
    [machine_id, assigned_to_user_id, operator_name, assigned_by]
  );
  return rows[0];
}

/**
 * المكائن التي يملك هذا المستخدم صلاحية تسجيل إنتاجها
 */
async function listMachinesForUser(userId) {
  const { rows } = await pool.query(
    `SELECT m.id, m.name, m.code
     FROM machine_assignments ma
     JOIN machines m ON m.id = ma.machine_id
     WHERE ma.assigned_to_user_id = $1 AND ma.is_active = true AND m.is_active = true`,
    [userId]
  );
  return rows;
}

async function userCanAccessMachine(userId, machineId) {
  const { rows } = await pool.query(
    `SELECT 1 FROM machine_assignments
     WHERE assigned_to_user_id = $1 AND machine_id = $2 AND is_active = true`,
    [userId, machineId]
  );
  return rows.length > 0;
}

// ---------- تسجيل الإنتاج + الترحيل التلقائي لنظام الموظفين ----------

async function createProductionRecord({
  machine_id, operator_name, receiver_name, stitches_count, panels_count,
  work_date, shift, created_by,
}) {
  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    const recordRes = await client.query(
      `INSERT INTO production_records
        (machine_id, operator_name, receiver_name, stitches_count, panels_count, work_date, shift, created_by)
       VALUES ($1,$2,$3,$4,$5,COALESCE($6, CURRENT_DATE),$7,$8)
       RETURNING *`,
      [machine_id, operator_name, receiver_name, stitches_count, panels_count, work_date, shift, created_by]
    );
    const record = recordRes.rows[0];

    // الترحيل التلقائي لنظام الموظفين بنفس تاريخ اليوم
    const hrRes = await client.query(
      `INSERT INTO hr_production_entries
        (production_record_id, employee_name, stitches_count, panels_count, entry_date)
       VALUES ($1,$2,$3,$4,$5)
       RETURNING *`,
      [record.id, operator_name, stitches_count, panels_count, record.work_date]
    );
    const hrEntry = hrRes.rows[0];

    await client.query(
      `UPDATE production_records SET posted_to_hr = true, hr_reference_id = $1 WHERE id = $2`,
      [hrEntry.id, record.id]
    );

    await client.query('COMMIT');
    return { record: { ...record, posted_to_hr: true, hr_reference_id: hrEntry.id }, hrEntry };
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

/**
 * تقرير الإنتاج الكامل - للمدير، مع فلاتر اختيارية
 */
async function listProductionRecords({ machine_id, operator_name, from_date, to_date } = {}) {
  const conditions = [];
  const values = [];
  let i = 1;

  if (machine_id) {
    conditions.push(`pr.machine_id = $${i++}`);
    values.push(machine_id);
  }
  if (operator_name) {
    conditions.push(`pr.operator_name ILIKE $${i++}`);
    values.push(`%${operator_name}%`);
  }
  if (from_date) {
    conditions.push(`pr.work_date >= $${i++}`);
    values.push(from_date);
  }
  if (to_date) {
    conditions.push(`pr.work_date <= $${i++}`);
    values.push(to_date);
  }

  const whereClause = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  const { rows } = await pool.query(
    `SELECT pr.*, m.name AS machine_name, u.full_name AS recorded_by_name
     FROM production_records pr
     JOIN machines m ON m.id = pr.machine_id
     JOIN users u ON u.id = pr.created_by
     ${whereClause}
     ORDER BY pr.work_date DESC, pr.created_at DESC`,
    values
  );
  return rows;
}

module.exports = {
  createMachine,
  listMachines,
  assignMachine,
  listMachinesForUser,
  userCanAccessMachine,
  createProductionRecord,
  listProductionRecords,
};
