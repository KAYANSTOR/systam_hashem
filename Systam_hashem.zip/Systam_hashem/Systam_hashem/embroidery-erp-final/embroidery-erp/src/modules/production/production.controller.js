const asyncHandler = require('../../utils/asyncHandler');
const logActivity = require('../../utils/logActivity');
const productionService = require('./production.service');

const createMachine = asyncHandler(async (req, res) => {
  const { name, code } = req.body;
  if (!name) return res.status(400).json({ message: 'اسم المكينة مطلوب' });

  const machine = await productionService.createMachine({ name, code, created_by: req.user.id });
  await logActivity(req.user.id, 'create', 'machines', machine.id, { name });

  res.status(201).json(machine);
});

const getMachines = asyncHandler(async (req, res) => {
  const machines = await productionService.listMachines();
  res.json(machines);
});

const assignMachine = asyncHandler(async (req, res) => {
  const { machine_id, assigned_to_user_id, operator_name } = req.body;

  if (!machine_id || !assigned_to_user_id) {
    return res.status(400).json({ message: 'المكينة والمستخدم المخصص له مطلوبان' });
  }

  const assignment = await productionService.assignMachine({
    machine_id, assigned_to_user_id, operator_name, assigned_by: req.user.id,
  });

  await logActivity(req.user.id, 'assign_machine', 'machine_assignments', assignment.id, {
    machine_id, assigned_to_user_id,
  });

  res.status(201).json(assignment);
});

const getMyMachines = asyncHandler(async (req, res) => {
  const machines = await productionService.listMachinesForUser(req.user.id);
  res.json(machines);
});

const createRecord = asyncHandler(async (req, res) => {
  const { machine_id, operator_name, receiver_name, stitches_count, panels_count, work_date, shift } = req.body;

  if (!machine_id || !operator_name || !receiver_name || !stitches_count || !panels_count) {
    return res.status(400).json({
      message: 'المكينة، اسم من اشتغل، مستلم المكينة، عدد الغرز وعدد الفرشات كلها مطلوبة',
    });
  }

  // مشرف الإنتاج مقيّد بالمكائن المخصصة له فقط؛ المدير غير مقيّد
  if (req.user.role === 'production_supervisor') {
    const allowed = await productionService.userCanAccessMachine(req.user.id, machine_id);
    if (!allowed) {
      return res.status(403).json({ message: 'ليست لديك صلاحية تسجيل إنتاج لهذه المكينة' });
    }
  }

  const result = await productionService.createProductionRecord({
    machine_id, operator_name, receiver_name, stitches_count, panels_count,
    work_date, shift, created_by: req.user.id,
  });

  await logActivity(req.user.id, 'create', 'production_records', result.record.id, {
    machine_id, stitches_count, panels_count,
  });

  res.status(201).json(result);
});

const getRecords = asyncHandler(async (req, res) => {
  const { machine_id, operator_name, from_date, to_date } = req.query;
  const records = await productionService.listProductionRecords({ machine_id, operator_name, from_date, to_date });
  res.json(records);
});

module.exports = {
  createMachine, getMachines, assignMachine, getMyMachines, createRecord, getRecords,
};
