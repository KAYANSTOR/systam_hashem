const pool = require('../../config/db');

async function listMaterials() {
  const { rows } = await pool.query(
    `SELECT id, name, unit, current_quantity, min_alert_qty,
            (current_quantity <= COALESCE(min_alert_qty, 0)) AS low_stock
     FROM materials ORDER BY name ASC`
  );
  return rows;
}

async function createMaterial({ name, unit, min_alert_qty, created_by }) {
  const { rows } = await pool.query(
    `INSERT INTO materials (name, unit, min_alert_qty, created_by)
     VALUES ($1, $2, $3, $4) RETURNING *`,
    [name, unit, min_alert_qty || 0, created_by]
  );
  return rows[0];
}

/**
 * تسجيل حركة دخول/خروج على مادة، ضمن Transaction لضمان دقة الرصيد.
 * يمنع الخروج بكمية أكبر من الرصيد المتاح.
 */
async function recordTransaction({ material_id, type, quantity, user_id, transaction_date, notes }) {
  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    const qtyNum = Number(quantity);
    if (qtyNum <= 0) {
      const err = new Error('الكمية يجب أن تكون أكبر من صفر');
      err.statusCode = 400;
      throw err;
    }

    const materialRes = await client.query(
      `SELECT * FROM materials WHERE id = $1 FOR UPDATE`,
      [material_id]
    );
    const material = materialRes.rows[0];
    if (!material) {
      const err = new Error('المادة غير موجودة');
      err.statusCode = 404;
      throw err;
    }

    let newQuantity;
    if (type === 'in') {
      newQuantity = Number(material.current_quantity) + qtyNum;
    } else if (type === 'out') {
      newQuantity = Number(material.current_quantity) - qtyNum;
      if (newQuantity < 0) {
        const err = new Error(`الكمية المطلوب صرفها أكبر من الرصيد المتاح (${material.current_quantity} ${material.unit})`);
        err.statusCode = 400;
        throw err;
      }
    } else {
      const err = new Error('نوع الحركة يجب أن يكون in أو out');
      err.statusCode = 400;
      throw err;
    }

    await client.query(`UPDATE materials SET current_quantity = $1 WHERE id = $2`, [newQuantity, material_id]);

    const txRes = await client.query(
      `INSERT INTO material_transactions (material_id, type, quantity, user_id, transaction_date, notes)
       VALUES ($1,$2,$3,$4,COALESCE($5, CURRENT_DATE),$6) RETURNING *`,
      [material_id, type, qtyNum, user_id, transaction_date, notes]
    );

    await client.query('COMMIT');
    return { transaction: txRes.rows[0], newQuantity };
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

/**
 * حركة المخزن الكاملة مع اسم المستخدم الذي نفّذ كل عملية - لعرضها للمدير
 */
async function listMovements({ material_id, from_date, to_date } = {}) {
  const conditions = [];
  const values = [];
  let i = 1;

  if (material_id) {
    conditions.push(`mt.material_id = $${i++}`);
    values.push(material_id);
  }
  if (from_date) {
    conditions.push(`mt.transaction_date >= $${i++}`);
    values.push(from_date);
  }
  if (to_date) {
    conditions.push(`mt.transaction_date <= $${i++}`);
    values.push(to_date);
  }

  const whereClause = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  const { rows } = await pool.query(
    `SELECT mt.id, m.name AS material_name, mt.type, mt.quantity, m.unit,
            u.full_name AS user_name, mt.transaction_date, mt.notes, mt.created_at
     FROM material_transactions mt
     JOIN materials m ON m.id = mt.material_id
     JOIN users u ON u.id = mt.user_id
     ${whereClause}
     ORDER BY mt.created_at DESC`,
    values
  );
  return rows;
}

module.exports = { listMaterials, createMaterial, recordTransaction, listMovements };
