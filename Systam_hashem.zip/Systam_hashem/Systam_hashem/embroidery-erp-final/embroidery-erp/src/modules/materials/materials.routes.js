const express = require('express');
const authenticate = require('../../middlewares/auth');
const roleGuard = require('../../middlewares/roleGuard');
const {
  getMaterials, createMaterial, materialIn, materialOut, getMovements,
} = require('./materials.controller');

const router = express.Router();

router.use(authenticate);

// عرض قائمة المواد (لاختيار المادة عند الإدخال/الإخراج) - متاح للمدير ومسؤول المخزن
router.get('/', roleGuard(['admin', 'materials_manager']), getMaterials);

// تعريف مادة جديدة - للمدير فقط
router.post('/', roleGuard(['admin']), createMaterial);

// دخول/خروج المواد - للمدير ومسؤول المخزن (هذه صلاحيته الوحيدة عمليًا)
router.post('/in', roleGuard(['admin', 'materials_manager']), materialIn);
router.post('/out', roleGuard(['admin', 'materials_manager']), materialOut);

// تقرير حركة المخزن الكامل مع اسم المستخدم - للمدير فقط
router.get('/movements', roleGuard(['admin']), getMovements);

module.exports = router;
