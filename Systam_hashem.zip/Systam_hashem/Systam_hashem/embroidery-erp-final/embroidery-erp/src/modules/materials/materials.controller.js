const asyncHandler = require('../../utils/asyncHandler');
const logActivity = require('../../utils/logActivity');
const materialsService = require('./materials.service');

const getMaterials = asyncHandler(async (req, res) => {
  const materials = await materialsService.listMaterials();
  res.json(materials);
});

const createMaterial = asyncHandler(async (req, res) => {
  const { name, unit, min_alert_qty } = req.body;

  if (!name || !unit) {
    return res.status(400).json({ message: 'اسم المادة والوحدة مطلوبان' });
  }
  if (!['kg', 'piece'].includes(unit)) {
    return res.status(400).json({ message: "الوحدة يجب أن تكون 'kg' أو 'piece'" });
  }

  const material = await materialsService.createMaterial({ name, unit, min_alert_qty, created_by: req.user.id });
  await logActivity(req.user.id, 'create', 'materials', material.id, { name });

  res.status(201).json(material);
});

const materialIn = asyncHandler(async (req, res) => {
  const { material_id, quantity, transaction_date, notes } = req.body;

  if (!material_id || !quantity) {
    return res.status(400).json({ message: 'المادة والكمية مطلوبتان' });
  }

  const result = await materialsService.recordTransaction({
    material_id, type: 'in', quantity, transaction_date, notes, user_id: req.user.id,
  });

  await logActivity(req.user.id, 'material_in', 'materials', material_id, { quantity });
  res.status(201).json(result);
});

const materialOut = asyncHandler(async (req, res) => {
  const { material_id, quantity, transaction_date, notes } = req.body;

  if (!material_id || !quantity) {
    return res.status(400).json({ message: 'المادة والكمية مطلوبتان' });
  }

  const result = await materialsService.recordTransaction({
    material_id, type: 'out', quantity, transaction_date, notes, user_id: req.user.id,
  });

  await logActivity(req.user.id, 'material_out', 'materials', material_id, { quantity });
  res.status(201).json(result);
});

const getMovements = asyncHandler(async (req, res) => {
  const { material_id, from_date, to_date } = req.query;
  const movements = await materialsService.listMovements({ material_id, from_date, to_date });
  res.json(movements);
});

module.exports = { getMaterials, createMaterial, materialIn, materialOut, getMovements };
