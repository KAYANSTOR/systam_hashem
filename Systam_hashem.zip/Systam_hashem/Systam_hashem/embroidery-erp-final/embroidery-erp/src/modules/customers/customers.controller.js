const asyncHandler = require('../../utils/asyncHandler');
const logActivity = require('../../utils/logActivity');
const customersService = require('./customers.service');

const getCustomers = asyncHandler(async (req, res) => {
  const customers = await customersService.listCustomers();
  res.json(customers);
});

const getCustomer = asyncHandler(async (req, res) => {
  const customer = await customersService.getCustomerById(req.params.id);
  res.json(customer);
});

const createCustomer = asyncHandler(async (req, res) => {
  const { name, phone, address, notes } = req.body;

  if (!name) {
    return res.status(400).json({ message: 'اسم العميل مطلوب' });
  }

  const customer = await customersService.createCustomer({ name, phone, address, notes });
  await logActivity(req.user.id, 'create', 'customers', customer.id);

  res.status(201).json(customer);
});

const getStatement = asyncHandler(async (req, res) => {
  const statement = await customersService.getCustomerStatement(req.params.id);
  res.json(statement);
});

const getTopDebtors = asyncHandler(async (req, res) => {
  const limit = parseInt(req.query.limit, 10) || 20;
  const debtors = await customersService.listTopDebtors(limit);
  res.json(debtors);
});

module.exports = { getCustomers, getCustomer, createCustomer, getStatement, getTopDebtors };
