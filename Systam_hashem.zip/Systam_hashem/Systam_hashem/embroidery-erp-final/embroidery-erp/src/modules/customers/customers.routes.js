const express = require('express');
const authenticate = require('../../middlewares/auth');
const roleGuard = require('../../middlewares/roleGuard');
const {
  getCustomers,
  getCustomer,
  createCustomer,
  getStatement,
  getTopDebtors,
} = require('./customers.controller');

const router = express.Router();

router.use(authenticate, roleGuard(['admin', 'sales']));

router.get('/', getCustomers);
router.post('/', createCustomer);
router.get('/top-debtors', getTopDebtors); // يجب أن تسبق /:id لتفادي التعارض
router.get('/:id', getCustomer);
router.get('/:id/statement', getStatement);

module.exports = router;
