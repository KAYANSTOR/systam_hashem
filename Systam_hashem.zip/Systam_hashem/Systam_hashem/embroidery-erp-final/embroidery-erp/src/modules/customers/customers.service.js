const pool = require('../../config/db');

async function listCustomers() {
  const { rows } = await pool.query(
    `SELECT id, name, phone, address, balance, created_at
     FROM customers ORDER BY created_at DESC`
  );
  return rows;
}

async function getCustomerById(id) {
  const { rows } = await pool.query(`SELECT * FROM customers WHERE id = $1`, [id]);
  if (!rows[0]) {
    const err = new Error('العميل غير موجود');
    err.statusCode = 404;
    throw err;
  }
  return rows[0];
}

async function createCustomer({ name, phone, address, notes }) {
  const { rows } = await pool.query(
    `INSERT INTO customers (name, phone, address, notes)
     VALUES ($1, $2, $3, $4) RETURNING *`,
    [name, phone, address, notes]
  );
  return rows[0];
}

/**
 * كشف حساب العميل: يجمع كل إشعارات البيع وسندات القبض بالتسلسل الزمني
 */
async function getCustomerStatement(customerId) {
  const customer = await getCustomerById(customerId);

  const { rows } = await pool.query(
    `SELECT id, type, reference_id, amount, balance_after, notes, created_at
     FROM customer_transactions
     WHERE customer_id = $1
     ORDER BY created_at ASC`,
    [customerId]
  );

  return { customer, transactions: rows };
}

async function listTopDebtors(limit = 20) {
  const { rows } = await pool.query(
    `SELECT id, name, phone, balance
     FROM customers
     WHERE balance > 0
     ORDER BY balance DESC
     LIMIT $1`,
    [limit]
  );
  return rows;
}

module.exports = {
  listCustomers,
  getCustomerById,
  createCustomer,
  getCustomerStatement,
  listTopDebtors,
};
