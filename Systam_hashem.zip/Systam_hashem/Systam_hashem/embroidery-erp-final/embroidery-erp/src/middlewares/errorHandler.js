module.exports = (err, req, res, next) => {
  console.error(err);

  // خطأ تكرار مفتاح فريد (مثال: username مكرر)
  if (err.code === '23505') {
    return res.status(409).json({ message: 'القيمة مستخدمة مسبقًا (مكررة)' });
  }

  const status = err.statusCode || 500;
  const message = err.message || 'حدث خطأ غير متوقع في الخادم';

  res.status(status).json({ message });
};
