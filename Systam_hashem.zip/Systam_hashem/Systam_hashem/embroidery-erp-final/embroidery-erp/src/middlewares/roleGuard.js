/**
 * يسمح فقط للأدوار المحددة بالوصول للـ route
 * الاستخدام: roleGuard(['admin', 'sales'])
 */
function roleGuard(allowedRoles = []) {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ message: 'يجب تسجيل الدخول أولًا' });
    }

    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({ message: 'ليست لديك صلاحية للوصول لهذه العملية' });
    }

    next();
  };
}

module.exports = roleGuard;
