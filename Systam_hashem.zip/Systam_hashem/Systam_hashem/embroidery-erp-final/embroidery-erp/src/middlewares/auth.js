const jwt = require('jsonwebtoken');
const env = require('../config/env');

function authenticate(req, res, next) {
  const header = req.headers.authorization;

  if (!header || !header.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'يجب تسجيل الدخول للوصول لهذا المورد' });
  }

  const token = header.split(' ')[1];

  try {
    const payload = jwt.verify(token, env.jwtSecret);
    req.user = payload; // { id, role, username }
    next();
  } catch (err) {
    return res.status(401).json({ message: 'جلسة الدخول غير صالحة أو منتهية' });
  }
}

module.exports = authenticate;
