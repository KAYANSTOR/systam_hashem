# دراسة وهيكلة متكاملة لنظام إدارة معمل التطريز (Embroidery ERP)

> نظام داخلي خاص بالمؤسسة — Backend: Node.js + PostgreSQL | Frontend: Flutter | ربط عبر REST API

---

## 1. نظرة عامة على النظام

النظام يخدم معمل تطريز، ويغطي دورة العمل الكاملة:

1. استلام قماش من الزبون (باليارده/الوار) وتسجيله كمخزون خاص بالزبون.
2. تنفيذ التطريز/النقشات على القماش.
3. إصدار **إشعار بيع** يخصم من رصيد القماش المتبقي للزبون ويحسب المبلغ المستحق.
4. تسجيل **سندات قبض** (نقد/دفعات) وتحديث حساب الزبون (آجل/رصيد متبقي).
5. إدارة **مخزن المواد الخام** (خرز، خيط، زيت...) بصلاحيات مستقلة لمدير المخزن.
6. إدارة **الإنتاج**: مكائن، عمال، غرز، فرشات — يترحّل تلقائيًا إلى نظام الموظفين/الرواتب.
7. **صلاحيات مستخدمين** متعددة الأدوار.
8. **تقارير احترافية** (كشف حساب عميل، أعلى المديونيات، حركة المخزون، الإنتاج) مع دعم شعار المعمل.

---

## 2. الأدوار والصلاحيات

| الدور | الصلاحيات |
|---|---|
| **مدير (Admin)** | كل الصلاحيات + إدارة المستخدمين، المكائن، التقارير، الإعدادات |
| **مبيعات/محاسب** | إدارة العملاء، إشعارات البيع، سندات القبض، تقارير العملاء |
| **مسؤول مخزن المواد** | إدخال/إخراج مواد المعمل فقط (لا يرى الحسابات المالية) |
| **مسؤول مخزن أقمشة الزبائن** | تسجيل استلام قماش الزبون فقط |
| **مشرف إنتاج** | تسجيل بيانات الإنتاج للمكينة المخصصة له فقط |

---

## 3. هيكلة قاعدة البيانات (PostgreSQL)

### 3.1 المستخدمون والصلاحيات
```sql
users (
  id, full_name, username, password_hash, phone,
  role ENUM('admin','sales','materials_manager','fabric_manager','production_supervisor'),
  is_active, created_at
)

user_activity_log (
  id, user_id, action, module, reference_id, details_json, created_at
)
```

### 3.2 العملاء وحساباتهم
```sql
customers (
  id, name, phone, address, notes,
  balance DECIMAL DEFAULT 0,   -- موجب = عليه دين
  created_at
)

customer_transactions (
  id, customer_id, type ENUM('sale','receipt'),
  reference_id, amount, balance_after, notes, created_by, created_at
)
```

### 3.3 مخزون أقمشة الزبائن
```sql
customer_fabrics (
  id, customer_id, fabric_type, rolls_count,
  total_yards, remaining_yards,
  is_leftover BOOLEAN DEFAULT false,
  parent_fabric_id,
  received_date, received_by, notes
)
```

### 3.4 إشعارات البيع وسندات القبض
```sql
sales_invoices (
  id, invoice_no, customer_id, fabric_id,
  yards_sold, price_per_yard, total_amount,
  paid_amount, remaining_amount,
  payment_type ENUM('cash','credit','partial'),
  invoice_date, created_by, notes
)

receipts (
  id, receipt_no, customer_id, amount,
  receipt_date, notes, created_by
)
```

### 3.5 مخزن مواد المعمل
```sql
materials (
  id, name, unit ENUM('kg','piece'), current_quantity, min_alert_qty
)

material_transactions (
  id, material_id, type ENUM('in','out'),
  quantity, unit, user_id, transaction_date, notes
)
```

### 3.6 الإنتاج
```sql
machines (id, name, code, is_active, created_by)

machine_assignments (
  id, machine_id, operator_name, assigned_to_user_id,
  assigned_by, assignment_date
)

production_records (
  id, machine_id, operator_name, receiver_name,
  stitches_count, panels_count,
  work_date, shift, created_by,
  posted_to_hr BOOLEAN DEFAULT false, hr_reference_id
)
```

---

## 4. خطة العمل المقترحة (5 مراحل)

| المرحلة | المحتوى | الحالة |
|---|---|---|
| 1 | قاعدة البيانات + Auth + إدارة المستخدمين والصلاحيات | ✅ مكتمل |
| 2 | العملاء + مخزون أقمشة الزبائن + إشعارات البيع + سندات القبض | ✅ مكتمل |
| 3 | مخزن المواد الخام + شاشات مدير المخزن في فلاتر | ✅ مكتمل |
| 4 | وحدة الإنتاج + الترحيل لنظام الموظفين | ✅ مكتمل |
| 5 | التقارير الاحترافية (PDF + شعار) | ✅ مكتمل |

---

## 5. ملاحظات تقنية مهمة

- استخدم **Decimal/Numeric** لكل حقول الوار والمبالغ المالية (تجنب float).
- كل عملية بيع أو قبض تمر عبر **Transaction واحدة** في قاعدة البيانات.
- فعّل **Audit Log** على كل جدول حساس (مواد، مبيعات، إنتاج).
- اجعل شعار المعمل ومعلومات المؤسسة في جدول `settings` يُستخدم في كل التقارير.
