# 📚 وثائق نظام إدارة معمل التطريز

هذا المجلد يحتوي على الوثائق الهندسية الكاملة للنظام.

---

## 📂 فهرس الوثائق

| الملف | الوصف |
|-------|-------|
| [01_SYSTEM_STUDY.md](./01_SYSTEM_STUDY.md) | دراسة وهيكلة النظام (نظرة عامة، قاعدة البيانات، خطة العمل) |
| [02_REQUIREMENTS_ANALYSIS.md](./02_REQUIREMENTS_ANALYSIS.md) | وثيقة تحليل المتطلبات SRS (وظيفية وغير وظيفية) |
| [03_WORKFLOW.md](./03_WORKFLOW.md) | وثيقة سير العمل (Workflow) — خطوات كل عملية بالتفصيل |
| [04_ERD.mermaid](./04_ERD.mermaid) | مخطط علاقات قاعدة البيانات (ERD) |
| [05_ENGINEERING_DOCUMENT.md](./05_ENGINEERING_DOCUMENT.md) | الوثيقة الهندسية الشاملة (API + هيكل + مبادئ التصميم) |

---

## 🏗️ هيكل المشروع

```
embroidery-erp/
├── src/
│   ├── config/          ← إعدادات قاعدة البيانات والمتغيرات
│   ├── middlewares/     ← JWT، الصلاحيات، معالجة الأخطاء
│   ├── modules/         ← 10 وحدات وظيفية (auth, users, customers, ...)
│   ├── utils/           ← asyncHandler، logActivity
│   ├── migrations/      ← ملفات SQL لإنشاء الجداول
│   ├── app.js           ← إعداد Express
│   └── server.js        ← نقطة الدخول
├── docs/                ← هذا المجلد
├── .env.example
├── package.json
└── README.md
```

---

## ⚡ تشغيل سريع

```bash
npm install
cp .env.example .env   # عدّل DATABASE_URL و JWT_SECRET
npm run migrate        # إنشاء جداول قاعدة البيانات
npm run dev            # تشغيل محلي
```
