# 📋 وثيقة هندسية شاملة — نظام إدارة معمل التطريز (Embroidery ERP)

> **الإصدار:** 1.0.0 | **التاريخ:** 2026-07-05 | **البيئة:** Node.js + PostgreSQL + Flutter

---

## 1. نظرة عامة على النظام

نظام ERP داخلي يدير دورة العمل الكاملة لمعمل التطريز:

| الجانب | التقنية |
|--------|---------|
| Backend API | Node.js (Express) |
| قاعدة البيانات | PostgreSQL |
| تطبيق الجوال | Flutter |
| مصادقة | JWT (JSON Web Tokens) |
| توليد PDF | Puppeteer (Chromium) |
| ORM/Query | node-postgres (`pg`) |

---

## 2. هيكل الملفات الرسمي

```
embroidery-erp/
├── 📁 src/
│   ├── 📁 config/
│   │   ├── db.js              # اتصال PostgreSQL (Pool)
│   │   └── env.js             # متغيرات البيئة
│   │
│   ├── 📁 middlewares/
│   │   ├── auth.js            # التحقق من JWT
│   │   ├── roleGuard.js       # حراسة الصلاحيات
│   │   └── errorHandler.js    # معالج الأخطاء العام
│   │
│   ├── 📁 modules/
│   │   ├── 📁 auth/           (تسجيل الدخول)
│   │   ├── 📁 users/          (إدارة المستخدمين)
│   │   ├── 📁 customers/      (العملاء + كشف الحساب)
│   │   ├── 📁 fabrics/        (مخزون أقمشة الزبائن)
│   │   ├── 📁 sales/          (إشعارات البيع + خصم تلقائي)
│   │   ├── 📁 receipts/       (سندات القبض)
│   │   ├── 📁 materials/      (مخزن المواد الخام)
│   │   ├── 📁 production/     (المكائن + الإنتاج + ترحيل HR)
│   │   ├── 📁 reports/        (PDF بشعار المعمل)
│   │   │   └── 📁 templates/  (قوالب HTML للتقارير)
│   │   └── 📁 settings/       (إعدادات المعمل + الشعار)
│   │
│   ├── 📁 utils/
│   │   ├── asyncHandler.js
│   │   └── logActivity.js     # Audit Log
│   │
│   ├── 📁 migrations/
│   │   ├── 001_create_users.sql
│   │   ├── 002_customers_sales.sql
│   │   ├── 003_materials.sql
│   │   ├── 004_production.sql
│   │   ├── 005_settings.sql
│   │   └── run.js
│   │
│   ├── app.js
│   └── server.js
│
├── 📁 docs/                   ← الوثائق الهندسية
│   ├── 01_SYSTEM_STUDY.md
│   ├── 02_REQUIREMENTS_ANALYSIS.md
│   ├── 03_WORKFLOW.md
│   ├── 04_ERD.mermaid
│   └── 05_ENGINEERING_DOCUMENT.md  ← هذه الوثيقة
│
├── .env.example
├── .gitignore
├── package.json
└── README.md
```

---

## 3. الأدوار والصلاحيات

| الدور | الرمز | الصلاحيات |
|-------|-------|-----------|
| مدير | `admin` | كامل الصلاحيات + إعدادات + مستخدمين |
| مبيعات / محاسب | `sales` | العملاء، البيع، القبض، تقارير العملاء |
| مسؤول مخزن المواد | `materials_manager` | دخول/خروج المواد فقط — لا يرى بيانات مالية |
| مسؤول مخزن الأقمشة | `fabric_manager` | استلام قماش الزبون فقط |
| مشرف إنتاج | `production_supervisor` | تسجيل إنتاج مكائنه المخصصة فقط |

---

## 4. قاعدة البيانات — مخطط الجداول

### 4.1 المستخدمون والتدقيق
```sql
users (
  id SERIAL PRIMARY KEY,
  full_name VARCHAR(150), username VARCHAR(50) UNIQUE,
  password_hash TEXT, phone VARCHAR(30),
  role ENUM('admin','sales','materials_manager','fabric_manager','production_supervisor'),
  is_active BOOLEAN DEFAULT true, created_at TIMESTAMPTZ DEFAULT now()
)

user_activity_log (
  id, user_id → users, action, module,
  reference_id, details_json, created_at
)
```

### 4.2 العملاء والمعاملات
```sql
customers (
  id, name, phone, address, notes,
  balance DECIMAL(12,2) DEFAULT 0,  -- موجب = دين على العميل
  created_at
)

customer_transactions (
  id, customer_id → customers,
  type ENUM('sale','receipt'),
  reference_id, amount, balance_after,
  notes, created_by → users, created_at
)
```

### 4.3 مخزون أقمشة الزبائن
```sql
customer_fabrics (
  id, customer_id → customers,
  fabric_type, rolls_count INTEGER,
  total_yards DECIMAL(10,2), remaining_yards DECIMAL(10,2),
  is_leftover BOOLEAN DEFAULT false,    -- قماش "فارغة"
  parent_fabric_id → customer_fabrics,  -- يرتبط بالدفعة الأصلية
  received_date, received_by → users, notes, created_at
)
```

### 4.4 المبيعات والقبض
```sql
sales_invoices (
  id, invoice_no UNIQUE, customer_id → customers, fabric_id → customer_fabrics,
  yards_sold, price_per_yard, total_amount, paid_amount, remaining_amount,
  payment_type ENUM('cash','credit','partial'),
  invoice_date, created_by → users, notes, created_at
)

receipts (
  id, receipt_no UNIQUE, customer_id → customers,
  amount DECIMAL(12,2), receipt_date,
  notes, created_by → users, created_at
)
```

### 4.5 مخزن المواد
```sql
materials (
  id, name VARCHAR(150),
  unit ENUM('kg','piece'),
  current_quantity DECIMAL(10,3) DEFAULT 0,
  min_alert_qty DECIMAL(10,3) DEFAULT 0
)

material_transactions (
  id, material_id → materials, type ENUM('in','out'),
  quantity, unit, user_id → users,
  transaction_date, notes, created_at
)
```

### 4.6 الإنتاج والمكائن
```sql
machines (id, name, code UNIQUE, is_active, created_by → users)

machine_assignments (
  id, machine_id → machines, operator_name,
  assigned_to_user_id → users, assigned_by → users, assignment_date
)

production_records (
  id, machine_id → machines, operator_name, receiver_name,
  stitches_count INTEGER, panels_count INTEGER,
  work_date DATE, shift VARCHAR(20), created_by → users,
  posted_to_hr BOOLEAN DEFAULT false, hr_reference_id INTEGER
)

hr_production_entries (
  id, production_record_id → production_records,
  machine_code, operator_name, stitches_count, panels_count,
  work_date, posted_at
)
```

### 4.7 إعدادات المعمل
```sql
company_settings (
  id, company_name, phone, address,
  logo_base64 TEXT,  -- شعار المعمل لتضمينه في كل التقارير
  updated_at
)
```

---

## 5. مخطط العلاقات (ERD)

```mermaid
erDiagram
    users ||--o{ user_activity_log : "يسجّل"
    users ||--o{ customer_fabrics : "received_by"
    users ||--o{ sales_invoices : "created_by"
    users ||--o{ receipts : "created_by"
    users ||--o{ material_transactions : "user_id"
    users ||--o{ production_records : "created_by"
    users ||--o{ machine_assignments : "assigned_to"

    customers ||--o{ customer_fabrics : "يملك"
    customers ||--o{ sales_invoices : "فاتورة"
    customers ||--o{ receipts : "سند قبض"
    customers ||--o{ customer_transactions : "حركة"

    customer_fabrics ||--o{ sales_invoices : "fabric_id"
    customer_fabrics ||--o{ customer_fabrics : "فارغة parent"

    materials ||--o{ material_transactions : "حركة"
    machines ||--o{ machine_assignments : "مخصصة"
    machines ||--o{ production_records : "سجل إنتاج"
    production_records ||--|| hr_production_entries : "ترحيل HR"
```

---

## 6. واجهة برمجة التطبيقات (REST API)

### المصادقة
| Method | Path | Description | Role |
|--------|------|-------------|------|
| POST | `/auth/login` | تسجيل الدخول | عام |

### المستخدمون
| Method | Path | Description | Role |
|--------|------|-------------|------|
| GET | `/users` | قائمة المستخدمين | admin |
| POST | `/users` | إضافة مستخدم | admin |
| PATCH | `/users/:id/toggle` | تفعيل/تعطيل | admin |

### العملاء
| Method | Path | Description | Role |
|--------|------|-------------|------|
| GET | `/customers` | قائمة العملاء | admin, sales |
| POST | `/customers` | إضافة عميل | admin, sales |
| GET | `/customers/:id` | بيانات عميل | admin, sales |
| GET | `/customers/:id/statement` | كشف الحساب | admin, sales |
| GET | `/customers/top-debtors` | أعلى مديونية | admin, sales |

### الأقمشة
| Method | Path | Description | Role |
|--------|------|-------------|------|
| POST | `/fabrics/receive` | استلام قماش | admin, fabric_manager |
| GET | `/fabrics/customer/:id` | أقمشة عميل | admin, sales |

### المبيعات والقبض
| Method | Path | Description | Role |
|--------|------|-------------|------|
| POST | `/sales/invoice` | إشعار بيع (يخصم تلقائياً + فارغة) | admin, sales |
| POST | `/receipts` | سند قبض | admin, sales |

### المواد
| Method | Path | Description | Role |
|--------|------|-------------|------|
| GET | `/materials` | قائمة المواد | admin, materials_manager |
| POST | `/materials` | تعريف مادة | admin |
| POST | `/materials/in` | توريد | admin, materials_manager |
| POST | `/materials/out` | صرف | admin, materials_manager |
| GET | `/materials/movements` | سجل الحركات | admin |

### الإنتاج
| Method | Path | Description | Role |
|--------|------|-------------|------|
| POST | `/production/machines` | إضافة مكينة | admin |
| GET | `/production/machines` | قائمة المكائن | admin |
| POST | `/production/assign` | تخصيص مكينة لمستخدم | admin |
| GET | `/production/my-machines` | مكائني المخصصة | admin, production_supervisor |
| POST | `/production/record` | تسجيل إنتاج يومي | admin, production_supervisor |
| GET | `/production/records` | تقرير الإنتاج الكامل | admin |

### التقارير PDF
| Method | Path | Description | Role |
|--------|------|-------------|------|
| GET | `/reports/customer/:id/pdf` | كشف حساب عميل | admin, sales |
| GET | `/reports/top-debtors/pdf?limit=20` | أعلى المديونيات | admin, sales |
| GET | `/reports/materials-movement/pdf` | حركة المخزن | admin |
| GET | `/reports/production/pdf` | تقرير الإنتاج | admin |

### الإعدادات
| Method | Path | Description | Role |
|--------|------|-------------|------|
| GET | `/settings` | قراءة إعدادات المعمل | جميع المسجلين |
| PUT | `/settings` | تعديل (اسم + شعار + بيانات تواصل) | admin |

---

## 7. التدفق الوظيفي الأساسي

### دورة إشعار البيع
```
استلام قماش من العميل
        ↓
اختيار الدفعة (customer_fabrics) + عدد الوارات
        ↓
التحقق: yards_sold <= remaining_yards  [FOR UPDATE]
        ↓ نعم
خصم الكمية + إنشاء "فارغة" إن تبقّى رصيد
        ↓
حساب total_amount + تحديث balance العميل
        ↓
تسجيل حركة customer_transactions
        ↓
COMMIT  ←─── كل ذلك داخل Transaction واحدة
```

### دورة تسجيل الإنتاج
```
مشرف يختار مكينته → يدخل البيانات
        ↓
التحقق: المكينة مخصصة له (machine_assignments)
        ↓ نعم
حفظ production_records
        ↓
ترحيل فوري → hr_production_entries  [نفس الـ Transaction]
        ↓
COMMIT (posted_to_hr = true)
```

---

## 8. مبادئ التصميم الهندسي

### فصل المسؤوليات
| الطبقة | المسؤولية |
|--------|----------|
| **Route** | تعريف المسارات + تطبيق الـ Middlewares |
| **Controller** | استقبال الطلب + التحقق من المدخلات + إرسال الرد |
| **Service** | منطق الأعمال + تعاملات قاعدة البيانات |
| **Middleware** | المصادقة + الصلاحيات + معالجة الأخطاء |

### ضمانات سلامة البيانات
- ✅ كل عملية متعددة الجداول داخل **Database Transaction** (ACID)
- ✅ قفل الصفوف الحساسة بـ `FOR UPDATE` (منع Race Conditions)
- ✅ `DECIMAL/NUMERIC` لكل الأرقام المالية (لا `float`)
- ✅ `FOR UPDATE` على `customer_fabrics` و`materials` قبل أي تعديل

### الأمان
- ✅ كل مسار محمي بـ `authenticate` (JWT) + `roleGuard([...roles])`
- ✅ كلمات المرور: `bcrypt` (salt rounds = 10)
- ✅ Audit Trail: كل عملية حساسة في `user_activity_log`

---

## 9. بيئة التشغيل والنشر

### ملف `.env`
```env
DATABASE_URL=postgresql://user:password@host:5432/embroidery_erp
JWT_SECRET=your_secret_min_32_chars
PORT=4000
NODE_ENV=production
```

### أوامر التشغيل
```bash
npm install       # تثبيت الاعتماديات
npm run migrate   # إنشاء جداول قاعدة البيانات
npm run dev       # تشغيل محلي (nodemon)
npm start         # تشغيل إنتاجي
```

### إنشاء أول مدير (مرة واحدة)
```bash
node -e "console.log(require('bcrypt').hashSync('كلمة_المرور', 10))"
# ثم أدخل الهاش في قاعدة البيانات:
```
```sql
INSERT INTO users (full_name, username, password_hash, role)
VALUES ('اسم المدير', 'admin', '<الهاش>', 'admin');
```

### ملاحظة Puppeteer على السيرفر
```
PUPPETEER_SKIP_DOWNLOAD=false
```
> تأكد أن خطة الاستضافة تسمح بـ **300-500 MB ذاكرة إضافية** لـ Chromium

---

## 10. حالة المشروع

| المرحلة | المحتوى | الحالة |
|---------|---------|--------|
| 1 | قاعدة البيانات + Auth + إدارة المستخدمين | ✅ مكتمل |
| 2 | العملاء + الأقمشة + البيع + القبض | ✅ مكتمل |
| 3 | مخزن المواد الخام | ✅ مكتمل |
| 4 | الإنتاج + الترحيل لـ HR | ✅ مكتمل |
| 5 | التقارير PDF + شعار المعمل | ✅ مكتمل |
| **التالي** | **ربط Flutter بالـ APIs** | 🔜 قادم |

---

## 11. قائمة الاختبار الشامل

- [ ] تسجيل دخول بكل الأدوار الخمسة + التحقق من عزل الصلاحيات
- [ ] استلام قماش → بيع جزئي → ظهور سجل "فارغة" بالفرق الصحيح
- [ ] بيع كامل الكمية → لا ينشأ سجل فارغة
- [ ] محاولة بيع أكثر من المتاح → رفض (400)
- [ ] دفع نقد/آجل/جزئي → تحديث رصيد العميل بشكل صحيح في الثلاث حالات
- [ ] سند قبض → نقصان رصيد العميل بنفس القيمة
- [ ] مسؤول المخزن: لا يرى أي شاشة مالية، صرف أكبر من الرصيد → رفض
- [ ] مشرف إنتاج: رفض تسجيل لمكينة غير مخصصة (403)
- [ ] سجل الإنتاج يظهر في `hr_production_entries` فور الحفظ بنفس التاريخ
- [ ] التقارير الأربعة PDF: شعار + نص عربي RTL سليم
- [ ] `user_activity_log` يسجل كل عملية باسم منفّذها

---

*نظام إدارة معمل التطريز v1.0 — Backend مكتمل بالكامل*
