# نظام إدارة معمل التطريز - Backend

## المرحلة 1 (منجزة): قاعدة البيانات + المصادقة + إدارة المستخدمين والصلاحيات

### المحتوى
- جدول `users` بالأدوار الخمسة: admin, sales, materials_manager, fabric_manager, production_supervisor
- جدول `user_activity_log` لسجل التدقيق
- تسجيل دخول عبر JWT (`POST /auth/login`)
- إدارة المستخدمين (إضافة/عرض/تفعيل-تعطيل) — للمدير فقط
- Middlewares: `authenticate` (التحقق من الجلسة) و `roleGuard` (التحقق من الصلاحية)

### خطوات التشغيل
```bash
npm install
cp .env.example .env      # عدّل DATABASE_URL و JWT_SECRET
npm run migrate           # ينشئ الجداول في قاعدة البيانات
npm run dev                # تشغيل محلي مع nodemon
```

### إنشاء أول مستخدم مدير (يدويًا عبر SQL لأول مرة فقط)
```sql
-- شغّل هذا الكود في Node لتوليد الهاش:
-- node -e "console.log(require('bcrypt').hashSync('كلمة_المرور', 10))"

INSERT INTO users (full_name, username, password_hash, role)
VALUES ('اسم المدير', 'admin', '<الهاش الناتج>', 'admin');
```

### اختبار سريع (بعد التشغيل)
```bash
# تسجيل الدخول
curl -X POST http://localhost:4000/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"كلمة_المرور"}'

# إنشاء مستخدم جديد (باستخدام التوكن الناتج)
curl -X POST http://localhost:4000/users \
  -H "Authorization: Bearer <TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{"full_name":"محمد المخزن","username":"materials1","password":"123456","role":"materials_manager"}'
```

---

## المرحلة 2 (منجزة): العملاء + مخزون أقمشة الزبائن + إشعارات البيع + سندات القبض

### المحتوى
- جداول: `customers`, `customer_fabrics`, `sales_invoices`, `receipts`, `customer_transactions`
- منطق "الفارغة": عند بيع كمية أقل من رصيد دفعة القماش، ينشئ النظام تلقائيًا سجل قماش جديد بالفرق بحالة `is_leftover = true` مرتبط بالدفعة الأصلية عبر `parent_fabric_id`
- كل عملية بيع/قبض تُنفَّذ ضمن **Database Transaction** واحدة مع قفل الصفوف (`FOR UPDATE`) لمنع تعارض العمليات المتزامنة وضمان دقة الأرصدة
- تحديث رصيد العميل تلقائيًا + تسجيل كل حركة في `customer_transactions` (كشف الحساب)

### تشغيل مايجريشن المرحلة 2
```bash
npm run migrate
```

### نقاط النهاية (Endpoints) الجديدة
```
GET  /customers                      قائمة العملاء
POST /customers                      إضافة عميل { name, phone, address, notes }
GET  /customers/top-debtors          أعلى العملاء مديونية
GET  /customers/:id                  بيانات عميل
GET  /customers/:id/statement        كشف حساب العميل

POST /fabrics/receive                استلام قماش من عميل
     { customer_id, fabric_type, rolls_count, total_yards, received_date, notes }
GET  /fabrics/customer/:customerId   دفعات القماش المتاحة لعميل (رصيد > 0)

POST /sales/invoice                  إشعار بيع (يخصم تلقائيًا وينشئ "فارغة" عند الحاجة)
     { customer_id, fabric_id, yards_sold, price_per_yard,
       payment_type: "cash"|"credit"|"partial", paid_amount, invoice_date, notes }

POST /receipts                       سند قبض { customer_id, amount, receipt_date, notes }
```

### مثال اختبار سريع (سيناريو "الفارغة")
```bash
# 1) استلام 300 وار من عميل
curl -X POST http://localhost:4000/fabrics/receive \
  -H "Authorization: Bearer <TOKEN>" -H "Content-Type: application/json" \
  -d '{"customer_id":1,"fabric_type":"قطن مطرز","rolls_count":3,"total_yards":300}'

# 2) بيع 298 وار فقط -> يبقى 2 وار في سجل جديد "فارغة"
curl -X POST http://localhost:4000/sales/invoice \
  -H "Authorization: Bearer <TOKEN>" -H "Content-Type: application/json" \
  -d '{"customer_id":1,"fabric_id":1,"yards_sold":298,"price_per_yard":500,"payment_type":"partial","paid_amount":100000}'
```

### الخطوات التالية (المرحلة 3)
مخزن مواد المعمل (خرز، خيط، زيت...) بصلاحيات مستقلة لمدير المخزن — دخول/خروج فقط.
