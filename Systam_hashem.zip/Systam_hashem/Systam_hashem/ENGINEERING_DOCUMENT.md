# 📋 وثيقة هندسية شاملة — نظام إدارة معمل التطريز (Embroidery ERP)

> **الإصدار:** 1.0.0 | **التاريخ:** 2026-07-05 | **البيئة:** Node.js + PostgreSQL + Flutter

---

## 1. نظرة عامة على النظام

نظام ERP داخلي يدير دورة العمل الكاملة لمعمل التطريز:

| الجانب | التقنية |
|--------|---------|
| Backend API | Node.js (Express) |
| قاعدة البيانات | PostgreSQL |
| تطبيق الجوال | Flutter |
| مصادقة | JWT (JSON Web Tokens) |
| توليد PDF | Puppeteer (Chromium) |
| ORM/Query | node-postgres (`pg`) |

---

## 2. هيكل الملفات الموصى به

```
embroidery-erp/
├── 📁 src/
│   ├── 📁 config/
│   │   ├── db.js              # اتصال PostgreSQL (Pool)
│   │   └── env.js             # متغيرات البيئة
│   │
│   ├── 📁 middlewares/
│   │   ├── auth.js            # التحقق من JWT
│   │   ├── roleGuard.js       # حراسة الصلاحيات
│   │   └── errorHandler.js    # معالج الأخطاء العام
│   │
│   ├── 📁 modules/
│   │   ├── 📁 auth/
│   │   │   ├── auth.routes.js
│   │   │   ├── auth.controller.js
│   │   │   └── auth.service.js
│   │   │
│   │   ├── 📁 users/
│   │   │   ├── users.routes.js
│   │   │   ├── users.controller.js
│   │   │   └── users.service.js
│   │   │
│   │   ├── 📁 customers/
│   │   │   ├── customers.routes.js
│   │   │   ├── customers.controller.js
│   │   │   └── customers.service.js
│   │   │
│   │   ├── 📁 fabrics/
│   │   │   ├── fabrics.routes.js
│   │   │   ├── fabrics.controller.js
│   │   │   └── fabrics.service.js
│   │   │
│   │   ├── 📁 sales/
│   │   │   ├── sales.routes.js
│   │   │   ├── sales.controller.js
│   │   │   └── sales.service.js
│   │   │
│   │   ├── 📁 receipts/
│   │   │   ├── receipts.routes.js
│   │   │   ├── receipts.controller.js
│   │   │   └── receipts.service.js
│   │   │
│   │   ├── 📁 materials/
│   │   │   ├── materials.routes.js
│   │   │   ├── materials.controller.js
│   │   │   └── materials.service.js
│   │   │
│   │   ├── 📁 production/
│   │   │   ├── production.routes.js
│   │   │   ├── production.controller.js
│   │   │   └── production.service.js
│   │   │
│   │   ├── 📁 reports/
│   │   │   ├── reports.routes.js
│   │   │   ├── reports.controller.js
│   │   │   ├── reports.service.js
│   │   │   └── 📁 templates/
│   │   │       ├── baseLayout.js
│   │   │       ├── customerStatement.js
│   │   │       ├── topDebtors.js
│   │   │       ├── materialsMovement.js
│   │   │       └── production.js
│   │   │
│   │   └── 📁 settings/
│   │       ├── settings.routes.js
│   │       ├── settings.controller.js
│   │       └── settings.service.js
│   │
│   ├── 📁 utils/
│   │   ├── asyncHandler.js    # Wrapper لدوال async/await
│   │   └── logActivity.js     # تسجيل نشاط المستخدم (Audit Log)
│   │
│   ├── 📁 migrations/
│   │   ├── 001_create_users.sql
│   │   ├── 002_customers_sales.sql
│   │   ├── 003_materials.sql
│   │   ├── 004_production.sql
│   │   ├── 005_settings.sql
│   │   └── run.js             # سكريبت تشغيل المايجريشن
│   │
│   ├── app.js                 # إعداد Express + تسجيل الروابط
│   └── server.js              # نقطة الدخول — يشغّل المنفذ
│
├── 📁 docs/                   # الوثائق الهندسية
│   ├── ENGINEERING_DOCUMENT.md  ← هذه الوثيقة
│   ├── ERD.mermaid
│   └── API_REFERENCE.md
│
├── .env.example
├── .gitignore
├── package.json
└── README.md
```

---

## 3. الأدوار والصلاحيات

| الدور | الرمز | الصلاحيات |
|-------|-------|-----------|
| مدير | `admin` | كامل الصلاحيات |
| مبيعات / محاسب | `sales` | العملاء، البيع، القبض، تقارير العملاء |
| مسؤول مخزن المواد | `materials_manager` | دخول/خروج المواد فقط |
| مسؤول مخزن الأقمشة | `fabric_manager` | استلام قماش الزبون فقط |
| مشرف إنتاج | `production_supervisor` | تسجيل إنتاج مكائنه المخصصة فقط |

---

## 4. قاعدة البيانات — مخطط الجداول

### 4.1 المستخدمون

```sql
users (
  id SERIAL PRIMARY KEY,
  full_name VARCHAR(150),
  username VARCHAR(50) UNIQUE,
  password_hash TEXT,
  phone VARCHAR(30),
  role ENUM('admin','sales','materials_manager','fabric_manager','production_supervisor'),
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now()
)

user_activity_log (
  id, user_id → users, action, module,
  reference_id, details_json, created_at
)
```

### 4.2 العملاء والمعاملات

```sql
customers (
  id, name, phone, address, notes,
  balance DECIMAL(12,2) DEFAULT 0,  -- موجب = دين على العميل
  created_at
)

customer_transactions (
  id, customer_id → customers,
  type ENUM('sale','receipt'),
  reference_id, amount, balance_after,
  notes, created_by → users, created_at
)
```

### 4.3 مخزون أقمشة الزبائن

```sql
customer_fabrics (
  id, customer_id → customers,
  fabric_type VARCHAR(150),
  rolls_count INTEGER,
  total_yards DECIMAL(10,2),
  remaining_yards DECIMAL(10,2),
  is_leftover BOOLEAN DEFAULT false,    -- قماش متبقي "فارغة"
  parent_fabric_id → customer_fabrics,  -- يرتبط بالدفعة الأصلية
  received_date DATE, received_by → users,
  notes, created_at
)
```

### 4.4 المبيعات والقبض

```sql
sales_invoices (
  id, invoice_no UNIQUE,
  customer_id → customers,
  fabric_id → customer_fabrics,
  yards_sold, price_per_yard,
  total_amount, paid_amount, remaining_amount,
  payment_type ENUM('cash','credit','partial'),
  invoice_date, created_by → users, notes, created_at
)

receipts (
  id, receipt_no UNIQUE,
  customer_id → customers,
  amount DECIMAL(12,2),
  receipt_date, notes,
  created_by → users, created_at
)
```

### 4.5 مخزن المواد

```sql
materials (
  id, name VARCHAR(150),
  unit ENUM('kg','piece'),
  current_quantity DECIMAL(10,3) DEFAULT 0,
  min_alert_qty DECIMAL(10,3) DEFAULT 0
)

material_transactions (
  id, material_id → materials,
  type ENUM('in','out'),
  quantity, unit,
  user_id → users,
  transaction_date, notes, created_at
)
```

### 4.6 الإنتاج

```sql
machines (id, name, code UNIQUE, is_active, created_by → users)

machine_assignments (
  id, machine_id → machines,
  operator_name, assigned_to_user_id → users,
  assigned_by → users, assignment_date
)

production_records (
  id, machine_id → machines,
  operator_name, receiver_name,
  stitches_count INTEGER,
  panels_count INTEGER,
  work_date DATE, shift VARCHAR(20),
  created_by → users,
  posted_to_hr BOOLEAN DEFAULT false,
  hr_reference_id INTEGER
)

hr_production_entries (
  id, production_record_id → production_records,
  machine_code, operator_name,
  stitches_count, panels_count,
  work_date, posted_at
)
```

### 4.7 إعدادات المعمل

```sql
company_settings (
  id, company_name, phone, address,
  logo_base64 TEXT,   -- شعار المعمل لتضمينه في التقارير
  updated_at
)
```

---

## 5. مخطط العلاقات (ERD)

```mermaid
erDiagram
    users ||--o{ user_activity_log : "يسجّل"
    users ||--o{ customer_fabrics : "received_by"
    users ||--o{ sales_invoices : "created_by"
    users ||--o{ receipts : "created_by"
    users ||--o{ material_transactions : "user_id"
    users ||--o{ production_records : "created_by"
    users ||--o{ machine_assignments : "assigned_to"

    customers ||--o{ customer_fabrics : "يملك"
    customers ||--o{ sales_invoices : "فاتورة"
    customers ||--o{ receipts : "سند قبض"
    customers ||--o{ customer_transactions : "حركة"

    customer_fabrics ||--o{ sales_invoices : "fabric_id"
    customer_fabrics ||--o{ customer_fabrics : "parent (فارغة)"

    materials ||--o{ material_transactions : "حركة"

    machines ||--o{ machine_assignments : "مخصصة لـ"
    machines ||--o{ production_records : "سجل إنتاج"
    production_records ||--|| hr_production_entries : "ترحيل HR"
```

---

## 6. واجهة برمجة التطبيقات (API Reference)

### 6.1 المصادقة
| الطريقة | المسار | الوصف | الصلاحية |
|---------|--------|-------|---------|
| POST | `/auth/login` | تسجيل الدخول | عام |

### 6.2 المستخدمون
| الطريقة | المسار | الوصف | الصلاحية |
|---------|--------|-------|---------|
| GET | `/users` | قائمة المستخدمين | admin |
| POST | `/users` | إضافة مستخدم | admin |
| PATCH | `/users/:id/toggle` | تفعيل/تعطيل | admin |

### 6.3 العملاء
| الطريقة | المسار | الوصف | الصلاحية |
|---------|--------|-------|---------|
| GET | `/customers` | قائمة العملاء | admin, sales |
| POST | `/customers` | إضافة عميل | admin, sales |
| GET | `/customers/:id` | بيانات عميل | admin, sales |
| GET | `/customers/:id/statement` | كشف الحساب | admin, sales |
| GET | `/customers/top-debtors` | أعلى مديونية | admin, sales |

### 6.4 مخزون الأقمشة
| الطريقة | المسار | الوصف | الصلاحية |
|---------|--------|-------|---------|
| POST | `/fabrics/receive` | استلام قماش | admin, fabric_manager |
| GET | `/fabrics/customer/:id` | أقمشة عميل | admin, sales |

### 6.5 المبيعات والقبض
| الطريقة | المسار | الوصف | الصلاحية |
|---------|--------|-------|---------|
| POST | `/sales/invoice` | إشعار بيع (يخصم تلقائياً) | admin, sales |
| POST | `/receipts` | سند قبض | admin, sales |

### 6.6 المواد
| الطريقة | المسار | الوصف | الصلاحية |
|---------|--------|-------|---------|
| GET | `/materials` | قائمة المواد | admin, materials_manager |
| POST | `/materials` | تعريف مادة | admin |
| POST | `/materials/in` | توريد | admin, materials_manager |
| POST | `/materials/out` | صرف | admin, materials_manager |
| GET | `/materials/movements` | سجل الحركات | admin |

### 6.7 الإنتاج
| الطريقة | المسار | الوصف | الصلاحية |
|---------|--------|-------|---------|
| POST | `/production/machines` | إضافة مكينة | admin |
| GET | `/production/machines` | قائمة المكائن | admin |
| POST | `/production/assign` | تخصيص مكينة | admin |
| GET | `/production/my-machines` | مكائني | admin, production_supervisor |
| POST | `/production/record` | تسجيل إنتاج | admin, production_supervisor |
| GET | `/production/records` | تقرير الإنتاج | admin |

### 6.8 التقارير PDF
| الطريقة | المسار | الوصف | الصلاحية |
|---------|--------|-------|---------|
| GET | `/reports/customer/:id/pdf` | كشف حساب | admin, sales |
| GET | `/reports/top-debtors/pdf` | أعلى مديونيات | admin, sales |
| GET | `/reports/materials-movement/pdf` | حركة المخزن | admin |
| GET | `/reports/production/pdf` | تقرير الإنتاج | admin |

### 6.9 الإعدادات
| الطريقة | المسار | الوصف | الصلاحية |
|---------|--------|-------|---------|
| GET | `/settings` | قراءة الإعدادات | جميع المسجلين |
| PUT | `/settings` | تعديل الإعدادات | admin |

---

## 7. التدفق الوظيفي الرئيسي

### 7.1 دورة إشعار البيع (Business Logic)
```
1. اختيار العميل → اختيار دفعة القماش
2. تحديد عدد الوارات المطلوبة
3. النظام يتحقق: yards_sold <= remaining_yards (مع قفل الصف FOR UPDATE)
4. خصم الكمية من customer_fabrics
5. إن تبقّى رصيد → إنشاء سجل قماش جديد (is_leftover = true)
6. حساب total_amount = yards_sold × price_per_yard
7. تحديث balance العميل (يزيد بمقدار remaining_amount)
8. تسجيل حركة في customer_transactions
9. كل هذا ضمن Database Transaction واحدة (ACID)
```

### 7.2 دورة تسجيل الإنتاج
```
1. مشرف الإنتاج يسجل: مكينته + العامل + المستلم + الغرز + الفرشات
2. النظام يتحقق: المكينة مخصصة لهذا المشرف (machine_assignments)
3. حفظ production_records
4. ترحيل فوري إلى hr_production_entries (نفس الـ Transaction)
5. تحديث posted_to_hr = true
```

---

## 8. مبادئ التصميم الهندسي

### 8.1 فصل المسؤوليات (SoC)
```
Controller  → استقبال الطلب + التحقق من المدخلات + إرسال الرد
Service     → منطق الأعمال (Business Logic) + تعاملات قاعدة البيانات
Middleware  → المصادقة + الصلاحيات + معالجة الأخطاء
```

### 8.2 ضمان سلامة البيانات
- كل عملية تمس أكثر من جدول → داخل **Database Transaction** (BEGIN/COMMIT/ROLLBACK)
- قفل الصفوف الحساسة بـ `FOR UPDATE` لمنع Race Conditions
- استخدام `DECIMAL/NUMERIC` لجميع الأرقام المالية والكميات (لا `float`)

### 8.3 الأمان
- كل مسار محمي بـ `authenticate` (JWT) + `roleGuard([...roles])`
- كلمات المرور مشفّرة بـ `bcrypt` (salt rounds = 10)
- كل عملية حساسة مسجّلة في `user_activity_log` (Audit Trail)

---

## 9. بيئة التشغيل والنشر

### المتغيرات المطلوبة (`.env`)
```env
DATABASE_URL=postgresql://user:password@host:5432/embroidery_erp
JWT_SECRET=your_very_long_secret_key_here
PORT=4000
NODE_ENV=development
```

### أوامر التشغيل
```bash
npm install              # تثبيت الاعتماديات
npm run migrate          # إنشاء جداول قاعدة البيانات
npm run dev              # تشغيل محلي (nodemon)
npm start                # تشغيل إنتاجي
```

### ملاحظة نشر Puppeteer
```env
# Railway / Render / VPS
PUPPETEER_SKIP_DOWNLOAD=false
```
> تأكد أن الخطة تسمح بـ 300-500 MB ذاكرة إضافية لـ Chromium

---

## 10. خطة المراحل (المُنجَز)

| المرحلة | المحتوى | الحالة |
|---------|---------|--------|
| 1 | قاعدة البيانات + Auth + إدارة المستخدمين | ✅ منجز |
| 2 | العملاء + الأقمشة + البيع + القبض | ✅ منجز |
| 3 | مخزن المواد الخام | ✅ منجز |
| 4 | الإنتاج + الترحيل لـ HR | ✅ منجز |
| 5 | التقارير PDF + شعار المعمل | ✅ منجز |

### الخطوة التالية المقترحة
- ربط تطبيق Flutter بالـ APIs شاشة بشاشة
- إضافة Flutter frontend بنفس هيكل `features/` (auth, customers, fabrics, sales, receipts, materials, production, reports)

---

## 11. قائمة الاختبار الشامل

- [ ] تسجيل دخول بكل الأدوار الخمسة
- [ ] استلام قماش → بيع جزئي → ظهور سجل "فارغة" بالفرق الصحيح
- [ ] بيع كامل الكمية → لا يُنشأ سجل فارغة
- [ ] محاولة بيع أكثر من المتاح → رفض بخطأ 400
- [ ] دفع نقد/آجل/جزئي → تحديث رصيد العميل بشكل صحيح
- [ ] سند قبض → نقصان رصيد العميل
- [ ] مسؤول المخزن: لا يرى أي شاشة مالية
- [ ] صرف مادة بكمية أكبر من الرصيد → رفض
- [ ] مشرف إنتاج: رفض تسجيل إنتاج لمكينة غير مخصصة له (403)
- [ ] سجل الإنتاج يظهر في `hr_production_entries` بنفس التاريخ
- [ ] التقارير الأربعة PDF تعرض الشعار والنص العربي RTL بشكل صحيح
- [ ] `user_activity_log` يسجل كل عملية باسم منفّذها

---

*آخر تحديث: 2026-07-05 | النظام: نظام إدارة معمل التطريز v1.0*
