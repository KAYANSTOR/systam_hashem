# نظام إدارة معمل التطريز - Backend

## المرحلة 1 (منجزة): قاعدة البيانات + المصادقة + إدارة المستخدمين والصلاحيات

### المحتوى
- جدول `users` بالأدوار الخمسة: admin, sales, materials_manager, fabric_manager, production_supervisor
- جدول `user_activity_log` لسجل التدقيق
- تسجيل دخول عبر JWT (`POST /auth/login`)
- إدارة المستخدمين (إضافة/عرض/تفعيل-تعطيل) — للمدير فقط
- Middlewares: `authenticate` (التحقق من الجلسة) و `roleGuard` (التحقق من الصلاحية)

### خطوات التشغيل
```bash
npm install
cp .env.example .env      # عدّل DATABASE_URL و JWT_SECRET
npm run migrate           # ينشئ الجداول في قاعدة البيانات
npm run dev                # تشغيل محلي مع nodemon
```

### إنشاء أول مستخدم مدير (يدويًا عبر SQL لأول مرة فقط)
```sql
-- شغّل هذا الكود في Node لتوليد الهاش:
-- node -e "console.log(require('bcrypt').hashSync('كلمة_المرور', 10))"

INSERT INTO users (full_name, username, password_hash, role)
VALUES ('اسم المدير', 'admin', '<الهاش الناتج>', 'admin');
```

### اختبار سريع (بعد التشغيل)
```bash
# تسجيل الدخول
curl -X POST http://localhost:4000/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"كلمة_المرور"}'

# إنشاء مستخدم جديد (باستخدام التوكن الناتج)
curl -X POST http://localhost:4000/users \
  -H "Authorization: Bearer <TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{"full_name":"محمد المخزن","username":"materials1","password":"123456","role":"materials_manager"}'
```

### الخطوات التالية (المرحلة 2)
العملاء + مخزون أقمشة الزبائن + إشعارات البيع (مع منطق "الفارغة") + سندات القبض.
